import{a as e,c as t,d as n,f as r,h as i,i as a,l as o,m as s,n as c,o as l,p as u,r as d,s as f,t as p,u as m}from"./index-DuInCppw.js";function h(e){if(Array.isArray(e))return e.flatMap(e=>h(e));if(typeof e!=`string`)return[];let t=[],n=0,r,i,a,o,s,c=()=>{for(;n<e.length&&/\s/.test(e.charAt(n));)n+=1;return n<e.length},l=()=>(i=e.charAt(n),i!==`=`&&i!==`;`&&i!==`,`);for(;n<e.length;){for(r=n,s=!1;c();)if(i=e.charAt(n),i===`,`){for(a=n,n+=1,c(),o=n;n<e.length&&l();)n+=1;n<e.length&&e.charAt(n)===`=`?(s=!0,n=o,t.push(e.slice(r,a)),r=n):n=a+1}else n+=1;(!s||n>=e.length)&&t.push(e.slice(r))}return t}function g(e){return e instanceof Headers?e:Array.isArray(e)||typeof e==`object`?new Headers(e):null}function _(...e){return e.reduce((e,t)=>{let n=g(t);if(!n)return e;for(let[t,r]of n.entries())t===`set-cookie`?h(r).forEach(t=>e.append(`set-cookie`,t)):e.set(t,r);return e},new Headers)}var ee=f(`clapperboard`,[[`path`,{d:`M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.5-4c1.1-.3 2.2.3 2.5 1.3Z`,key:`1tn4o7`}],[`path`,{d:`m6.2 5.3 3.1 3.9`,key:`iuk76l`}],[`path`,{d:`m12.4 3.4 3.1 4`,key:`6hsd6n`}],[`path`,{d:`M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z`,key:`ltgou9`}]]),te=f(`factory`,[[`path`,{d:`M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z`,key:`159hny`}],[`path`,{d:`M17 18h1`,key:`uldtlt`}],[`path`,{d:`M12 18h1`,key:`s9uhes`}],[`path`,{d:`M7 18h1`,key:`1neino`}]]),ne=f(`message-circle`,[[`path`,{d:`M7.9 20A9 9 0 1 0 4 16.1L2 22Z`,key:`vv11sd`}]]),re=f(`mic`,[[`path`,{d:`M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z`,key:`131961`}],[`path`,{d:`M19 10v2a7 7 0 0 1-14 0v-2`,key:`1vc78b`}],[`line`,{x1:`12`,x2:`12`,y1:`19`,y2:`22`,key:`x3vr5v`}]]),ie=f(`scroll-text`,[[`path`,{d:`M15 12h-5`,key:`r7krc0`}],[`path`,{d:`M15 8h-5`,key:`1khuty`}],[`path`,{d:`M19 17V5a2 2 0 0 0-2-2H4`,key:`zz82l3`}],[`path`,{d:`M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3`,key:`1ph1d7`}]]),ae=f(`settings`,[[`path`,{d:`M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z`,key:`1qme2f`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),oe=f(`sparkles`,[[`path`,{d:`M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z`,key:`4pj2yx`}],[`path`,{d:`M20 3v4`,key:`1olli1`}],[`path`,{d:`M22 5h-4`,key:`1gvqau`}],[`path`,{d:`M4 17v2`,key:`vumght`}],[`path`,{d:`M5 18H3`,key:`zchphs`}]]),se=f(`youtube`,[[`path`,{d:`M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17`,key:`1q2vi4`}],[`path`,{d:`m10 15 5-3-5-3z`,key:`1jp15x`}]]);function v(e){return e!==`__proto__`&&e!==`constructor`&&e!==`prototype`}function y(e,t){let n=Object.create(null);if(e)for(let t of Object.keys(e))v(t)&&(n[t]=e[t]);if(t&&typeof t==`object`)for(let e of Object.keys(t))v(e)&&(n[e]=t[e]);return n}function b(e){if(!e)return Object.create(null);let t=Object.create(null);for(let n of Object.keys(e))v(n)&&(t[n]=e[n]);return t}var ce=()=>{throw Error(`createServerOnlyFn() functions can only be called on the server!`)},x=(e,t)=>{let r=t||e||{};r.method===void 0&&(r.method=`GET`);let i=e=>x(void 0,{...r,validator:e,inputValidator:e});return Object.assign(e=>x(void 0,{...r,...e}),{options:r,middleware:e=>{let t=[...r.middleware||[]];e.forEach(e=>{u in e?e.options.middleware&&t.push(...e.options.middleware):t.push(e)});let n=x(void 0,{...r,middleware:t});return n[u]=!0,n},validator:i,inputValidator:i,handler:(...e)=>{let[t,i]=e,a={...r,extractedFn:t,serverFn:i},o=[...a.middleware||[],de(a)];return t.method=r.method,Object.assign(async e=>{let r=await le(o,`client`,{...t,...a,data:e?.data,headers:e?.headers,signal:e?.signal,fetch:e?.fetch,context:b()}),i=n(r.error);if(i)throw i;if(r.error)throw r.error;return r.result},{...t,method:r.method,__executeServer:async e=>{let n=ce(),i=n.contextAfterGlobalMiddlewares;return await le(o,`server`,{...t,data:e.data,method:e.method??r.method,serverFnMeta:t.serverFnMeta,context:y(e.context,i),request:n.request}).then(e=>({result:e.result,error:e.error,context:e.sendContext}))}})}})};async function le(e,t,n){let i=S([...r()?.functionMiddleware||[],...e]);if(t===`server`){let e=ce({throwIfNotFound:!1});e?.executedRequestMiddlewares&&(i=i.filter(t=>!e.executedRequestMiddlewares.has(t)))}let a=async e=>{let n=i.shift();if(!n)return e;try{let r=`validator`in n.options?n.options.validator:void 0;!r&&`inputValidator`in n.options&&(r=n.options.inputValidator),r&&t===`server`&&(e.data=await ue(r,e.data));let i;if(t===`client`?`client`in n.options&&(i=n.options.client):`server`in n.options&&(i=n.options.server),i){let t=async(t={})=>{let n=await a({...e,...t,context:y(e.context,t.context),sendContext:y(e.sendContext,t.sendContext),headers:_(e.headers,t.headers),_callSiteFetch:e._callSiteFetch,fetch:e._callSiteFetch??t.fetch??e.fetch,result:t.result===void 0?t instanceof Response?t:e.result:t.result,error:t.error??e.error});if(n.error)throw n.error;return n},n=await i({...e,next:t});if(m(n))return{...e,error:n};if(n instanceof Response)return{...e,result:n};if(!n)throw Error(`User middleware returned undefined. You must call next() or return a result in your middlewares.`);return n}return a(e)}catch(t){return{...e,error:t}}};return a({...n,headers:n.headers||{},sendContext:n.sendContext||{},context:n.context||b(),_callSiteFetch:n.fetch})}function S(e,t=100){let n=new Set,r=[],i=(e,a)=>{if(a>t)throw Error(`Middleware nesting depth exceeded maximum of ${t}. Check for circular references.`);e.forEach(e=>{e.options.middleware&&i(e.options.middleware,a+1),n.has(e)||(n.add(e),r.push(e))})};return i(e,0),r}async function ue(e,t){if(e==null)return{};if(`~standard`in e){let n=await e[`~standard`].validate(t);if(n.issues)throw Error(JSON.stringify(n.issues,void 0,2));return n.value}if(`parse`in e)return e.parse(t);if(typeof e==`function`)return e(t);throw Error(`Invalid validator type!`)}function de(e){return{"~types":void 0,options:{inputValidator:e.validator??e.inputValidator,client:async({next:t,sendContext:n,fetch:r,...i})=>{let a={...i,context:n,fetch:r};return t(await e.extractedFn?.(a))},server:async({next:t,...n})=>{let r=await e.serverFn?.(n);return t({...n,result:r})}}}}var C=i(s(),1),fe={zai:{label:`GLM-5.2 / GLM-4-Flash Free (Z.ai)`,hint:`https://open.bigmodel.cn/api/paas/v4`,models:[{id:`glm-5.2`,label:`glm-5.2`},{id:`glm-5-turbo`,label:`glm-5-turbo`},{id:`glm-4-flash`,label:`glm-4-flash (free)`}],allowCustomModel:!1},openrouter:{label:`OpenRouter Free Tier`,hint:`https://openrouter.ai/api/v1`,models:[{id:`z-ai/glm-5.2:free`,label:`z-ai/glm-5.2:free`},{id:`deepseek/deepseek-chat:free`,label:`deepseek/deepseek-chat:free`},{id:`qwen/qwen-2.5-7b-instruct:free`,label:`qwen/qwen-2.5-7b-instruct:free`}],allowCustomModel:!0},github:{label:`GitHub Models Free API`,hint:`https://models.inference.ai.azure.com`,models:[{id:`gpt-4o`,label:`gpt-4o`},{id:`gpt-4o-mini`,label:`gpt-4o-mini`},{id:`Meta-Llama-3.1-405B-Instruct`,label:`Llama 3.1 405B`},{id:`Mistral-large-2411`,label:`Mistral Large`}],allowCustomModel:!0},gemini:{label:`Google Gemini Free`,hint:`gemini-2.5-flash`,models:[{id:`gemini-2.5-flash`,label:`gemini-2.5-flash`}],allowCustomModel:!1},groq:{label:`Groq`,hint:`llama-3.3-70b-versatile`,models:[{id:`llama-3.3-70b-versatile`,label:`llama-3.3-70b-versatile`}],allowCustomModel:!0},openai:{label:`OpenAI`,hint:`https://api.openai.com/v1`,models:[{id:`gpt-4o-mini`,label:`gpt-4o-mini`},{id:`gpt-4o`,label:`gpt-4o`}],allowCustomModel:!0},deepseek:{label:`DeepSeek`,hint:`https://api.deepseek.com`,models:[{id:`deepseek-chat`,label:`deepseek-chat`},{id:`deepseek-reasoner`,label:`deepseek-reasoner`}],allowCustomModel:!1},custom:{label:`Custom OpenAI-compatible URL`,hint:`Any /v1 base URL`,models:[],allowCustomModel:!0}},pe=[{id:`gguf`,label:`GLM-5.2 4-Bit GGUF / Distill (Ollama / llama.cpp)`},{id:`airllm`,label:`GLM-5.2 AirLLM layer-wise (low VRAM)`},{id:`fast`,label:`Fast local fallback (GLM-4-9B / Qwen2.5-14B)`}],me={hi:`hi-IN-MadhurNeural`,en:`en-US-ChristopherNeural`};function he(e){return fe[e].models[0]?.id??``}function ge(e,t){if(!t.startsWith(`/api/v1/`)||t.includes(`..`)||t.includes(`//`))throw Error(`That worker path is not valid.`);let n=e.trim();if(!n)throw Error(`Add the worker URL first.`);let r;try{r=new URL(/^https?:\/\//i.test(n)?n:`https://${n}`)}catch{throw Error(`That worker URL is not valid.`)}if(r.protocol!==`http:`&&r.protocol!==`https:`)throw Error(`Only http and https workers.`);let i=r.pathname.replace(/\/+$/,``);i.endsWith(`/api/v1/health`)?i=i.slice(0,-14):i.endsWith(`/api/v1/jobs`)?i=i.slice(0,-12):i.endsWith(`/api/v1`)&&(i=i.slice(0,-7));let a=new URL(r.origin);return a.pathname=`${i}${t}`.replace(/\/{2,}/g,`/`),a}var _e=x({method:`POST`}).handler(o(`563099b809b2a51691b9f6a5d6c33f7e68ad08e1f397f41329e1d93a5d96f2ed`)),ve=x({method:`POST`}).handler(o(`fb35a5929aeb382cfa404066c94369172b0a468056c7ce98b53e69b645a0941b`)),ye=x({method:`POST`}).handler(o(`c2f0841c7549228172cf44a94d57bc6fe6617883157ac8877ca13b3cd14e776d`)),be=x({method:`POST`}).handler(o(`7797f3a0eac382d040e1aeb5a02dc9bdd2b747691bd8bcb4b611aca40449ed00`)),xe=x({method:`POST`}).handler(o(`d2a6b2a19797d69c5b0f8b3d8580fdfdf17003521da123e437d08bf40052abb6`)),Se=x({method:`POST`}).handler(o(`43a434a06dbf29ff3543b713d534cb31f6aa0cdec6e5bd64d4f82ca5bfba06cf`)),Ce=x({method:`POST`}).handler(o(`2b4c3398c432f7c57717b4b27f3354ccead6a03c2c78a584a8e48580a0f312be`)),we=x({method:`POST`}).handler(o(`ef33f39ce09d4830db33acbc9b501f8bb3ee230c73513250a73d48a2693754a6`)),Te=x({method:`POST`}).handler(o(`09a063287da321971bf1e2e5ddeff28a007c98885c01cc5edf05f991690f4cd9`)),Ee=x({method:`POST`}).handler(o(`dda5ac0a6423b8a1b16e067a52b457002d6f430cdce082076b56f01019813444`)),De=x({method:`POST`}).handler(o(`1f0cfaf2cfb7db3fc62b33bf8cc6df12890914679a47e6591994d357a4a7e591`)),Oe=x({method:`POST`}).handler(o(`df700042e2b5a64c50059fb5c12effaaa337b2d36bbd1fbda7c247f351791d52`)),ke=x({method:`POST`}).handler(o(`0ac02964e89d85f31604cd870fdf5c0c5055a92cb471bdc2ab52b076f55ca0a1`)),Ae=x({method:`POST`}).handler(o(`7e57028f6fb2d7224fa93966b01dee72ba28d8b1c9a68bacb107f1c2e626dd10`)),je=x({method:`POST`}).handler(o(`b337bb6b6aae62e28d13fa7c64dcaab68f11dbb7970b86d5149f9a8545412300`)),Me=x({method:`POST`}).handler(o(`8ebf86c5fb42b3069035a5d461771576917679cb3d33929db611b8c62527eb7b`));function Ne(e,t,n){if(!n||!e?.length)return t.trim();let r=t.trim(),i=[...e].filter(e=>e.chapter>0&&e.outfit.trim()).sort((e,t)=>e.chapter-t.chapter);for(let e of i)e.chapter<=n&&(r=e.outfit.trim());return r}function Pe(e,t){let n=Ne(e.outfits,e.outfit||``,t),r=[e.age?.trim(),e.body?.trim(),e.face?.trim()?`face: ${e.face.trim()}`:``,e.hair?.trim()?`hair: ${e.hair.trim()}`:``,e.eyes?.trim()?`eyes: ${e.eyes.trim()}`:``,e.scars?.trim()?`scars: ${e.scars.trim()}`:``,n?`outfit: ${n}`:``].filter(Boolean);if(!r.length)return e.look.trim();let i=r.join(`, `);return e.look.trim()&&!i.includes(e.look.trim())?`${i}. ${e.look.trim()}`:i}function Fe(e){return e.map(e=>{let t=(e.outfits??[]).filter(e=>e.chapter>0&&e.outfit.trim()).map(e=>`chapter ${e.chapter}: ${e.outfit.trim()}`).join(`; `);return[`${e.name}`,`face: ${e.face?.trim()||`—`}`,`hair: ${e.hair?.trim()||`—`}`,`age: ${e.age?.trim()||`—`}`,`scars: ${e.scars?.trim()||`—`}`,`eyes: ${e.eyes?.trim()||`—`}`,`body: ${e.body?.trim()||`—`}`,`outfit: ${e.outfit?.trim()||e.look.trim()||`—`}`,t?`outfit changes: ${t}`:``].filter(Boolean).join(`; `)}).join(`
`)}function Ie(e){let t=[];for(let n of e.split(/\n+/)){let e=n.trim().match(/^(?:chapter\s*)?(\d+)\s*[:\-]\s*(.+)$/i);if(!e?.[1]||!e[2])continue;let r=Number(e[1]),i=e[2].trim();r>0&&r<1e5&&i&&t.push({chapter:r,outfit:i.slice(0,180)})}return t}function Le(e){return(e??[]).map(e=>`${e.chapter}: ${e.outfit}`).join(`
`)}function Re(e){return e.filter(e=>!e.locked&&!e.promptLocked).map(e=>e.id)}function ze(e,t){let n=[e.caption,e.dialogue,e.speaker,e.imagePrompt].join(`
`),r=t.filter(e=>e.name&&n.includes(e.name));return(r.length?r:t.slice(0,4)).map(t=>`${t.name}: ${Pe(t,e.chapter)}`).filter(e=>!e.endsWith(`: `)).join(`
`)}function Be(e,t){let n=[e.caption,e.dialogue,e.speaker,e.imagePrompt].join(`
`),r=t.find(e=>e.faceUrl&&e.name&&n.includes(e.name));return r?.faceUrl?r.faceUrl:t.length===1&&t[0]?.faceUrl?t[0].faceUrl:``}var Ve=[`face`,`hair`,`age`,`scars`,`eyes`,`body`,`outfit`];function He(e,t){let n={...e,outfits:e.outfits?[...e.outfits]:[]};for(let e of Ve){let r=t[e]?.trim();r&&(n[e]=r.slice(0,180))}if(t.chapter&&t.chapter>0&&t.outfit?.trim()){let e=t.outfit.trim().slice(0,180),r=(n.outfits??[]).filter(e=>e.chapter!==t.chapter);r.push({chapter:t.chapter,outfit:e}),n.outfits=r,n.outfit=e}return n.look=Pe(n),n.vessel=n.outfit||n.vessel,n}function w(e,t){return t.test(e)?e.replace(/\s+/g,` `).trim().slice(0,180):``}function Ue(e,t=[]){let n=e.replace(/\s+/g,` `).split(/(?<=[.!?])\s+/).map(e=>e.trim()).filter(e=>e.length>20&&e.length<280),r=new Map;for(let e of t)r.set(e.name.toLowerCase(),{...e,outfits:e.outfits?[...e.outfits]:[]});let i=e.match(/\b[A-Z][a-z]{2,}(?:\s[A-Z][a-z]+)?\b/g)??[];for(let e of i)[`The`,`Rain`,`Across`,`Between`,`Lightning`,`Your`,`Chapter`].includes(e)||r.has(e.toLowerCase())||r.set(e.toLowerCase(),{id:e.toLowerCase().replace(/[^a-z0-9]+/g,`-`)||`figure`,name:e,soul:`Named in the source. Identity stays on this name.`,vessel:``,look:``,outfits:[]});for(let e of n){let t=Number(e.match(/chapter\s+(\d+)/i)?.[1]??``);for(let n of r.values()){if(!e.includes(n.name))continue;n.face=n.face||w(e,/face|jaw|brow/i),n.hair=n.hair||w(e,/hair/i),n.eyes=n.eyes||w(e,/eyes?/i),n.scars=n.scars||w(e,/scar/i),n.age=n.age||w(e,/\bage\b|young|old|teen/i),n.body=n.body||w(e,/tall|slim|body|broad/i);let r=w(e,/robe|armor|dress|cloak|outfit|sleeve|uniform|boots/i);if(r&&t>0){let e=n.outfits??[];e.some(e=>e.chapter===t)||e.push({chapter:t,outfit:r}),n.outfits=e}else r&&!n.outfit&&(n.outfit=r)}}return[...r.values()].map(e=>(e.look=Pe(e)||e.look||`Body not described yet.`,e.vessel=e.outfit||e.look,e))}function We(e,t){let n=e.map(e=>({...e}));for(let e of t){let t=e.name.trim().toLowerCase(),r=n.findIndex(e=>e.name.trim().toLowerCase()===t);if(r<0){n.push(e);continue}let i=n[r];n[r]={...i,face:e.face||i.face,hair:e.hair||i.hair,age:e.age||i.age,scars:e.scars||i.scars,eyes:e.eyes||i.eyes,body:e.body||i.body,outfit:e.outfit||i.outfit,outfits:e.outfits?.length?e.outfits:i.outfits,look:e.look||i.look,soul:i.soul||e.soul,vessel:e.vessel||i.vessel,faceUrl:i.faceUrl||e.faceUrl}}return n}function Ge(e,t){let n=t===`hi`?e.captionHi:e.captionEn,r=t===`hi`?e.dialogueHi:e.dialogueEn;return n===void 0&&r===void 0?null:{caption:n??``,dialogue:r??``}}function T(e,t){let n=t===`hi`?e.lineHi:e.lineEn;if(n?.trim())return n.trim();let r=Ge(e,t);if(r&&(r.caption.trim()||r.dialogue.trim()))return[r.caption,r.dialogue].filter(Boolean).join(` `).trim();let i=t===`hi`?e.lineEn:e.lineHi,a=Ge(e,t===`hi`?`en`:`hi`);return i?.trim()||a&&(a.caption.trim()||a.dialogue.trim())?``:[e.caption,e.dialogue].filter(Boolean).join(` `).trim()}function Ke(e,t){return e.scenes.filter(e=>!T(e,t)).map(e=>e.id)}function qe(e,t){let n=e.scenes.map(e=>{let n=Ge(e,t);return n?{...e,caption:n.caption,dialogue:n.dialogue,imageUrl:e.imageUrl,imagePrompt:e.imagePrompt}:e}),r=t===`hi`?e.narrationHi:e.narrationEn,i=t===`hi`?e.seoHi:e.seoEn,a=i?{...i,privacy:e.seo.privacy}:e.seo;return{...e,language:t,scenes:n,narration:r?.trim()||n.map(e=>T(e,t)).filter(Boolean).join(` `),seo:a}}function E(e,t){let n=e.scenes.map(e=>{let n=[e.caption,e.dialogue].filter(Boolean).join(` `).trim();return t===`hi`?{...e,captionHi:e.caption,dialogueHi:e.dialogue,lineHi:e.lineHi?.trim()||n}:{...e,captionEn:e.caption,dialogueEn:e.dialogue,lineEn:e.lineEn?.trim()||n}});return t===`hi`?{...e,scenes:n,narrationHi:e.narration,seoHi:{...e.seo,privacy:void 0}}:{...e,scenes:n,narrationEn:e.narration,seoEn:{...e.seo,privacy:void 0}}}function Je(e,t,n){let r=new Map(n.map(e=>[e.id,e])),i=e.scenes.map(e=>{let n=r.get(e.id);if(!n)return e;let i=[n.caption,n.dialogue].filter(Boolean).join(` `).trim();return t===`hi`?{...e,captionHi:n.caption,dialogueHi:n.dialogue,lineHi:i}:{...e,captionEn:n.caption,dialogueEn:n.dialogue,lineEn:i}});return{...e,scenes:i}}var Ye=/hair|robe|scar|eye|armor|face|beard|cloak|dress|outfit|sleeve|boots|blood|skin|brow|knot|spear|sword|pendant|jade/i;function Xe(e){let t=e.replace(/\s+/g,` `).split(/(?<=[.!?])\s+/).map(e=>e.trim()).filter(e=>e.length>24&&e.length<280&&Ye.test(e)),n=[],r=new Set;for(let e of t){let t=e.toLowerCase();if(!r.has(t)&&(r.add(t),n.push(e),n.length>=14))break}return n.join(` `)}function Ze(e){let t=Math.max(0,e),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=Math.floor(t%60),a=Math.round((t-Math.floor(t))*1e3),o=(e,t=2)=>String(e).padStart(t,`0`);return`${o(n)}:${o(r)}:${o(i)},${o(a,3)}`}function Qe(e,t){let n=0;return e.scenes.map((e,r)=>{let i=T(e,t)||` `,a=e.holdSec&&e.holdSec>0?e.holdSec:Math.min(18,Math.max(1.6,i.length/14)),o=n;return n+=a,`${r+1}\n${Ze(o)} --> ${Ze(n)}\n${i}\n`}).join(`
`)}var $e=/male|\bguy\b|david|ravi|prabhat|madhur|daniel|fred|rishi|arthur|aaron|alex|george|charon|hindi india/i,et=/female|woman|zira|samantha|veena|heera|eva|susan|salli|victoria|fiona|lekha|neerja|google हिन्दी/i;function tt(){if(typeof window<`u`&&window.speechSynthesis)try{window.speechSynthesis.resume();let e=new SpeechSynthesisUtterance(`​`);e.volume=0,e.rate=1,window.speechSynthesis.speak(e)}catch{}}function nt(e=900){if(typeof window>`u`||!window.speechSynthesis)return Promise.resolve([]);let t=window.speechSynthesis,n=t.getVoices();return n.length?Promise.resolve(n):new Promise(n=>{let r=!1,i=()=>{r||(r=!0,t.removeEventListener(`voiceschanged`,i),n(t.getVoices()))};t.addEventListener(`voiceschanged`,i);try{t.getVoices(),t.resume()}catch{}window.setTimeout(i,e)})}function rt(e,t){let n=`${e.lang} ${e.name}`,r=0;return(t?/^hi/i.test(e.lang):/^(en|hi)/i.test(e.lang))&&(r+=4),$e.test(n)&&!et.test(n)&&(r+=3),e.default&&(r+=1),e.localService&&(r+=1),et.test(n)&&(r-=2),r}function it(e,t){if(!e.length)return null;let n=/[\u0900-\u097F]/.test(t);return[...e].sort((e,t)=>rt(t,n)-rt(e,n))[0]??null}function at(e){let t=e.replace(/\s+/g,` `).trim();if(!t)return[];if(t.length<=180)return[t];let n=[],r=t;for(;r.length>180;){let e=r.lastIndexOf(`. `,180);e<50&&(e=r.lastIndexOf(`, `,180)),e<40&&(e=r.lastIndexOf(` `,180)),e<20&&(e=180);let t=r.slice(0,e+1).trim();t&&n.push(t),r=r.slice(e+1).trim()}return r&&n.push(r),n.slice(0,80)}function ot(e,t){if(typeof window>`u`||!window.speechSynthesis)return Promise.reject(Error(`This phone has no speech engine.`));let n=at(e);if(!n.length)return Promise.resolve();let r=window.speechSynthesis,i=/[\u0900-\u097F]/.test(e);return new Promise((e,a)=>{let o=0,s=!1,c=!1,l=()=>{s||(s=!0,e())},u=e=>{s||(s=!0,a(Error(e)))},d=e=>{let a=new SpeechSynthesisUtterance(n[o]??``);!e&&t?(a.voice=t,t.lang&&(a.lang=t.lang)):!e&&i&&(a.lang=`hi-IN`),a.rate=.96,a.onend=()=>{o+=1,o>=n.length?l():d(!1)},a.onerror=e=>{let t=e.error;t===`interrupted`||t===`canceled`?l():!c&&(t===`synthesis-failed`||t===`voice-unavailable`||t===`language-unavailable`||t===`not-allowed`||t===`audio-busy`)?(c=!0,window.setTimeout(()=>d(!0),60)):u(`This phone stopped the reading.`)};try{r.resume(),r.speak(a)}catch{u(`This phone stopped the reading.`)}};d(!1)})}function D(e){let t={amp:`&`,lt:`<`,gt:`>`,quot:`"`,apos:`'`,nbsp:` `};return e.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi,(e,n)=>{let r=n.toLowerCase();if(r.startsWith(`#x`)){let t=Number.parseInt(r.slice(2),16);return Number.isFinite(t)&&t>0&&t<1114112?String.fromCodePoint(t):e}if(r.startsWith(`#`)){let t=Number.parseInt(r.slice(1),10);return Number.isFinite(t)&&t>0&&t<1114112?String.fromCodePoint(t):e}return Object.prototype.hasOwnProperty.call(t,r)?t[r]:e})}function st(e){return e.replace(/wtr-?lab/gi,` `).replace(/ch\.\s*\d+\s*\/\s*\d+/gi,` `).replace(/\d+(?:\.\d+)?%\s*web/gi,` `).replace(/#\d+\s*chapter/gi,` `).replace(/\b(?:next|previous)\s+chapter\b/gi,` `).replace(/\bhome\s*\|\s*novels\s*\|\s*library\s*\|\s*ranking\b/gi,` `).replace(/\s+/g,` `).trim()}var ct=/^(novel|novels|web|mtl|machine translation|next chapter|previous chapter|library|ranking|home|comments?|login|sign in)$/i;function O(e){return D(e).split(/\n+/).map(e=>st(e)).filter(e=>e.length>0&&!ct.test(e)&&!/^[\d.%\s/#+-]+$/.test(e)).join(`
`).trim()}var k=`text, letters, logos, watermark, speech bubbles, signature, extra limbs, deformed hands`,lt={hi:`hi-IN-MadhurNeural`,en:`en-US-ChristopherNeural`},ut=p([`hi`,`en`]),dt=e({prompt:l().min(1),negative:l(),characters:c(l()),vessel_id:l()}),A=e({speaker:l(),text:l()}),ft=e({id:l().min(1),caption:l(),sfx:l(),state:l(),bubble:A,image_url:l().max(12e5).optional(),hold_sec:a().positive().max(180).optional(),reference:l().max(5e5).optional(),tiles:c(dt).min(1)}),j=e({id:l().min(1),name:l().min(1),soul:l(),vessel:l(),vessel_id:l()}),pt=e({index:a().int().positive(),title:l().min(1),source_url:l().nullable(),narration:l(),characters:c(j),scenes:c(ft).min(1)}),mt=e({title:l(),description:l(),tags:c(l())}),ht=e({version:d(2),language:ut,voice:l().min(1),title:l().min(1),aspect:p([`16:9`,`9:16`]).default(`16:9`),local_model:p([`gguf`,`airllm`,`fast`]).default(`gguf`),hook:l().default(``),pass:p([`assemble`,`revoice`]).default(`assemble`),chapters:c(pt).min(1),seo:mt,image_repo:l().max(200).optional(),note:l()});function gt(e){return/[\u0900-\u097F]/.test(e)?`hi`:`en`}function _t(e,t){return t?.trim()||lt[e]}var vt=`# Aether Manhua Explanation Factory
# Colab T4 (15GB) or Kaggle T4x2 (30GB). Paste the whole cell and run.
# Printed Worker URL goes into the phone Settings. Nothing here is saved back to the phone.

import os, sys, json, uuid, time, shutil, threading, subprocess, base64, re
from pathlib import Path

PORT = 8787
ROOT = Path("/kaggle/working" if Path("/kaggle/working").exists() else "/content")
ROOT.mkdir(parents=True, exist_ok=True)
MODELS = ROOT / "models"
MODELS.mkdir(exist_ok=True)
OUT = ROOT / "aether_out"
OUT.mkdir(exist_ok=True)
TOKEN = os.environ.get("AETHER_TOKEN", "")
JOBS = {}
LATEST = {"preview": None, "mp4": None}
PANEL_CACHE = {}
PANEL_DIR = OUT / "panels"
VOICE_DIR = OUT / "voices"
CLIP_DIR = OUT / "clips"
for _folder in (PANEL_DIR, VOICE_DIR, CLIP_DIR):
    _folder.mkdir(exist_ok=True)
TIMING_PATH = OUT / "timing.json"
PAINTER = {"pipe": None, "img2img": None, "kind": "", "name": ""}
VISION = {"model": None}
OCR = {"reader": None}
FETCH_JOBS = {}
LLM = {"obj": None, "mode": "", "name": ""}

def pip_try(args):
    subprocess.call([sys.executable, "-m", "pip", "install", "-q", *args])

pip_try(["fastapi", "uvicorn", "edge-tts", "pillow", "requests", "huggingface_hub"])
try:
    import torch
    GPU_COUNT = torch.cuda.device_count() if torch.cuda.is_available() else 0
    GPU_NAMES = [torch.cuda.get_device_name(i) for i in range(GPU_COUNT)]
except Exception:
    torch = None
    GPU_COUNT = 0
    GPU_NAMES = []
print("GPUs", GPU_COUNT, GPU_NAMES, flush=True)
print("Image checkpoint", os.environ.get("AETHER_IMAGE_REPO", "cagliostrolab/animagine-xl-3.1"), flush=True)
print("Set AETHER_IMAGE_REPO to a Flux repo or a manhwa checkpoint before this cell if you do not want Animagine XL. Pollinations is only the fallback when that model cannot load.", flush=True)
print("Full GLM-5.2 4-bit GGUF is about 466GB and will not fit Colab T4 or Kaggle T4x2. gguf mode loads a 4-bit distill (default GLM-4-9B Q4) unless AETHER_GGUF_REPO is set. Flagship GLM-5.2 stays on the cloud key (Z.ai / OpenRouter / GitHub Models).", flush=True)
if shutil.which("ffmpeg") is None or shutil.which("ffprobe") is None:
    subprocess.call(["apt-get", "update", "-qq"])
    subprocess.call(["apt-get", "install", "-y", "-qq", "ffmpeg"])

def sh(args, **kw):
    subprocess.check_call(args, **kw)

def allowed(headers, token=""):
    if not TOKEN:
        return True
    presented = headers.get("x-aether-token", "") or token
    return presented == TOKEN

def han(text):
    return any("\\u4e00" <= ch <= "\\u9fff" for ch in text)

def load_llm(mode):
    if LLM["obj"] is not None and LLM["mode"] == mode:
        return LLM
    if mode == "gguf":
        # CUDA wheel first so Kaggle T4x2 / Colab T4 actually offload layers. CPU wheel is the fallback.
        cuda = subprocess.call([sys.executable, "-m", "pip", "install", "-q", "llama-cpp-python", "--extra-index-url", "https://abetlen.github.io/llama-cpp-python/whl/cu124"])
        if cuda != 0:
            os.environ["CMAKE_ARGS"] = "-DGGML_CUDA=on"
            os.environ["FORCE_CMAKE"] = "1"
            pip_try(["llama-cpp-python"])
        from llama_cpp import Llama
        gguf = next(MODELS.glob("*.gguf"), None)
        if gguf is None:
            from huggingface_hub import hf_hub_download
            repo = os.environ.get("AETHER_GGUF_REPO", "bartowski/glm-4-9b-chat-GGUF")
            name = os.environ.get("AETHER_GGUF_FILE", "glm-4-9b-chat-Q4_K_M.gguf")
            path = hf_hub_download(repo_id=repo, filename=name, local_dir=str(MODELS))
            gguf = Path(path)
        kwargs = {"model_path": str(gguf), "n_gpu_layers": -1, "n_ctx": 4096, "verbose": False}
        if GPU_COUNT >= 2:
            kwargs["tensor_split"] = [1.0 / GPU_COUNT] * GPU_COUNT
        llm = Llama(**kwargs)
        LLM.update(obj=llm, mode=mode, name=gguf.name)
        return LLM
    if mode == "airllm":
        pip_try(["airllm"])
        from airllm import AutoModel
        repo = os.environ.get("AETHER_AIR_REPO", "Qwen/Qwen2.5-14B-Instruct")
        model = AutoModel.from_pretrained(repo)
        LLM.update(obj=model, mode=mode, name=repo)
        return LLM
    pip_try(["transformers", "accelerate", "bitsandbytes"])
    from transformers import AutoModelForCausalLM, AutoTokenizer
    repo = os.environ.get("AETHER_FAST_REPO", "Qwen/Qwen2.5-14B-Instruct")
    tok = AutoTokenizer.from_pretrained(repo)
    model = AutoModelForCausalLM.from_pretrained(repo, device_map="auto", torch_dtype="auto")
    LLM.update(obj=(tok, model), mode="fast", name=repo)
    return LLM

def complete(mode, system, prompt):
    bundle = load_llm(mode if mode in ("gguf", "airllm", "fast") else "fast")
    user = system + "\\n\\n" + prompt
    if bundle["mode"] == "gguf":
        out = bundle["obj"].create_chat_completion(messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}], max_tokens=4096, temperature=0.4)
        return out["choices"][0]["message"]["content"]
    if bundle["mode"] == "airllm":
        model = bundle["obj"]
        tokens = model.tokenizer([user], return_tensors="pt")
        ids = tokens["input_ids"]
        if torch is not None and GPU_COUNT:
            ids = ids.cuda()
        gen = model.generate(ids, max_new_tokens=1200)
        return model.tokenizer.decode(gen[0], skip_special_tokens=True)
    tok, model = bundle["obj"]
    messages = [{"role": "system", "content": system}, {"role": "user", "content": prompt}]
    text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    batch = tok(text, return_tensors="pt").to(model.device)
    gen = model.generate(**batch, max_new_tokens=1200, do_sample=False)
    return tok.decode(gen[0][batch["input_ids"].shape[1]:], skip_special_tokens=True)

def ink_panel(prompt, dest, size):
    from PIL import Image, ImageDraw
    seed = abs(hash(prompt or "panel")) % 9973
    w, h = size
    im = Image.new("RGB", (w, h), (16, 12, 14))
    draw = ImageDraw.Draw(im, "RGBA")
    for band in range(16):
        y0 = int(h * band / 16)
        y1 = int(h * (band + 1) / 16) + 1
        shade = 20 + band * 6 + (seed % 18)
        draw.rectangle([0, y0, w, y1], fill=(shade, 16 + band * 2, 22 + (seed % 10), 255))
    moon = 64 + (seed % 48)
    mx = int(w * (0.58 + (seed % 17) / 100))
    my = int(h * 0.08)
    draw.ellipse([mx, my, mx + moon * 2, my + moon * 2], fill=(236, 220, 186, 235))
    ridge = int(h * (0.58 + (seed % 8) / 100))
    draw.polygon([(0, ridge + 80), (int(w * 0.35), ridge), (int(w * 0.62), ridge + 46), (w, ridge - 10), (w, h), (0, h)], fill=(12, 10, 14, 255))
    cx = int(w * (0.28 + (seed % 40) / 100))
    cy = int(h * 0.62)
    robe = (120 + (seed % 90), 36, 28, 255)
    draw.polygon([(cx - 46, cy + 220), (cx, cy + 36), (cx + 46, cy + 220)], fill=robe)
    draw.ellipse([cx - 22, cy - 10, cx + 22, cy + 36], fill=(232, 214, 190, 255))
    if seed % 2 == 0:
        draw.line([(cx + 30, cy + 20), (cx + 150, cy - 80)], fill=(210, 210, 220, 255), width=6)
    im.convert("RGB").save(dest)
    return dest

def fetch_image(raw, dest):
    if isinstance(raw, str) and raw.startswith("data:"):
        b64 = raw.split(",", 1)[-1]
        dest.write_bytes(base64.b64decode(b64))
        return True
    if isinstance(raw, str) and raw.startswith("http"):
        import requests
        res = requests.get(raw, timeout=40)
        res.raise_for_status()
        if len(res.content) < 64:
            return False
        dest.write_bytes(res.content)
        return True
    return False

def safe_id(value):
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "", str(value or "panel"))[:80]
    return cleaned or "panel"

def load_timing():
    if TIMING_PATH.exists():
        try:
            data = json.loads(TIMING_PATH.read_text())
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}

def save_timing(data):
    TIMING_PATH.write_text(json.dumps(data))

def load_painter():
    if PAINTER["pipe"] is not None:
        return PAINTER
    if GPU_COUNT < 1 or torch is None:
        raise RuntimeError("no GPU for the manhwa checkpoint")
    pip_try(["diffusers", "transformers", "accelerate", "safetensors", "sentencepiece", "protobuf"])
    repo = os.environ.get("AETHER_IMAGE_REPO", "cagliostrolab/animagine-xl-3.1")
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if "flux" in repo.lower():
        from diffusers import FluxPipeline
        pipe = FluxPipeline.from_pretrained(repo, torch_dtype=torch.bfloat16, token=token)
        pipe.enable_model_cpu_offload()
        img2img = None
        try:
            from diffusers import FluxImg2ImgPipeline
            img2img = FluxImg2ImgPipeline(**pipe.components)
        except Exception as exc:
            print("flux img2img unavailable", exc, flush=True)
        PAINTER.update(pipe=pipe, img2img=img2img, kind="flux", name=repo)
        return PAINTER
    from diffusers import StableDiffusionXLPipeline, StableDiffusionXLImg2ImgPipeline
    try:
        pipe = StableDiffusionXLPipeline.from_pretrained(repo, torch_dtype=torch.float16, variant="fp16", use_safetensors=True, token=token)
    except Exception:
        pipe = StableDiffusionXLPipeline.from_pretrained(repo, torch_dtype=torch.float16, use_safetensors=True, token=token)
    pipe.enable_model_cpu_offload()
    img2img = StableDiffusionXLImg2ImgPipeline(**pipe.components)
    PAINTER.update(pipe=pipe, img2img=img2img, kind="sdxl", name=repo)
    return PAINTER

def paint_local(prompt, dest, size, reference):
    from PIL import Image
    bundle = load_painter()
    w = max(512, (min(size[0], 832) // 64) * 64)
    h = max(768, (min(size[1], 1216) // 64) * 64)
    if bundle["kind"] == "flux":
        if reference and bundle.get("img2img") is not None:
            ref = Image.open(reference).convert("RGB").resize((w, h))
            image = bundle["img2img"](prompt=prompt, image=ref, strength=0.4, guidance_scale=3.5, num_inference_steps=4, height=h, width=w, max_sequence_length=256).images[0]
        else:
            image = bundle["pipe"](prompt, height=h, width=w, guidance_scale=3.5, num_inference_steps=4, max_sequence_length=256).images[0]
    elif reference and bundle.get("img2img") is not None:
        ref = Image.open(reference).convert("RGB").resize((w, h))
        image = bundle["img2img"](prompt=prompt, image=ref, strength=0.42, num_inference_steps=28, guidance_scale=6.5, height=h, width=w).images[0]
    else:
        image = bundle["pipe"](prompt=prompt, num_inference_steps=28, guidance_scale=6.5, height=h, width=w).images[0]
    image.convert("RGB").save(dest)
    return bundle["kind"] + ("+ref" if reference else "")

def paint_prompt(prompt, dest, size, reference=None):
    import requests, urllib.parse
    locked = "Vertical colored manhwa, clean ink, dramatic lighting, consistent character, no text, no letters, no watermark, no speech bubbles. " + (prompt or "panel")
    try:
        kind = paint_local(locked, dest, size, reference)
        print("checkpoint panel", kind, flush=True)
        return kind
    except Exception as exc:
        print("checkpoint skipped", exc, flush=True)
    try:
        url = "https://image.pollinations.ai/prompt/" + urllib.parse.quote(locked[:480]) + "?width=%d&height=%d&nologo=true&model=flux" % (min(size[0], 768), min(size[1], 1152))
        res = requests.get(url, timeout=90)
        kind = res.headers.get("content-type", "")
        if res.ok and kind.startswith("image") and len(res.content) > 1000:
            dest.write_bytes(res.content)
            print("pollinations panel — faces can drift", flush=True)
            return "pollinations"
    except Exception as exc:
        print("pollinations skipped", exc, flush=True)
    ink_panel(prompt, dest, size)
    return "ink"

def materialize_reference(payload):
    dest = OUT / "ref-face.png"
    raw_b64 = payload.get("referenceBase64") or ""
    raw = payload.get("reference") or ""
    try:
        if isinstance(raw_b64, str) and len(raw_b64) > 80:
            dest.write_bytes(base64.b64decode(raw_b64))
            return dest
        if isinstance(raw, str) and (raw.startswith("http") or raw.startswith("data:")) and fetch_image(raw, dest):
            return dest
    except Exception as exc:
        print("reference skipped", exc, flush=True)
    return None

def ensure_panel(scene, dest, size, revoice):
    sid = safe_id(scene.get("id") or dest.stem)
    stable = PANEL_DIR / f"{sid}.png"
    raw = scene.get("image_url") or ""
    def take_remote():
        if isinstance(raw, str) and (raw.startswith("http") or raw.startswith("data:")):
            try:
                if fetch_image(raw, stable):
                    shutil.copy(stable, dest)
                    PANEL_CACHE[sid] = str(stable)
                    return True
            except Exception as exc:
                print("panel fetch failed", exc, flush=True)
        return False
    if not revoice and take_remote():
        return "fetched"
    if stable.exists() and stable.stat().st_size > 64:
        shutil.copy(stable, dest)
        PANEL_CACHE[sid] = str(stable)
        return "kept"
    if take_remote():
        return "fetched"
    cached = PANEL_CACHE.get(sid)
    if cached and Path(cached).exists():
        shutil.copy(cached, stable)
        shutil.copy(stable, dest)
        return "cache"
    if revoice:
        raise RuntimeError("Picture missing for %s. Re-voice will not draw a new one." % sid)
    tiles = scene.get("tiles") or [{}]
    prompt = tiles[0].get("prompt") if tiles and isinstance(tiles[0], dict) else ""
    reference = materialize_reference({"reference": scene.get("reference") or ""})
    paint_prompt(prompt or "panel", stable, size, reference)
    shutil.copy(stable, dest)
    PANEL_CACHE[sid] = str(stable)
    return "painted"

def voice_file_name(sid, lang, voice):
    slug = re.sub(r"[^A-Za-z0-9]", "", str(voice or ""))[:32] or "male"
    return f"{safe_id(sid)}_{lang}_{slug}.mp3"

def speak_to(text, voice, dest):
    import edge_tts, asyncio
    last = "edge refused"
    for attempt in range(3):
        try:
            asyncio.run(edge_tts.Communicate((text or " ")[:700], voice).save(str(dest)))
            if dest.exists() and dest.stat().st_size > 200:
                return "edge"
        except Exception as exc:
            last = str(exc)
            print("edge retry", attempt, exc, flush=True)
            time.sleep(1.2)
    espeak = shutil.which("espeak-ng") or shutil.which("espeak")
    if not espeak:
        subprocess.call(["apt-get", "install", "-y", "-qq", "espeak-ng"])
        espeak = shutil.which("espeak-ng") or shutil.which("espeak")
    if not espeak:
        raise RuntimeError("Edge TTS refused and no local voice was available. " + last[:180])
    wav = dest.with_suffix(".wav")
    code = "hi" if str(voice).startswith("hi-") else "en"
    sh([espeak, "-v", code, "-w", str(wav), (text or " ")[:500]])
    sh(["ffmpeg", "-y", "-i", str(wav), "-c:a", "libmp3lame", "-q:a", "4", str(dest)])
    print("local voice fallback", code, flush=True)
    return "espeak"

def panel_clip(sid, img, hold, size, sfx, revoice=False):
    W, H = size
    meta_path = CLIP_DIR / f"{sid}.json"
    dest = CLIP_DIR / f"{sid}.mp4"
    prev = None
    if meta_path.exists():
        try:
            prev = json.loads(meta_path.read_text())
        except Exception:
            prev = None
    old = float(prev.get("hold") or 0) if isinstance(prev, dict) else 0
    if prev and dest.exists() and hold <= old + 0.08:
        return dest
    if revoice and prev and dest.exists() and hold > old:
        extra = max(hold - old, 0.04)
        extended = CLIP_DIR / f"{sid}-hold.mp4"
        sh(["ffmpeg", "-y", "-i", str(dest), "-vf", f"tpad=stop_mode=clone:stop_duration={extra:.3f}", "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(extended)])
        shutil.move(str(extended), str(dest))
        meta_path.write_text(json.dumps({"hold": round(hold, 3)}))
        print("extended hold only", sid, flush=True)
        return dest
    frames = max(int(hold * 30), 36)
    shake = "shake" in (sfx or "").lower() or sfx in ("CRACK", "BOOM", "SHING")
    vf = f"scale={W*2}:{H*2}:force_original_aspect_ratio=increase,crop={W*2}:{H*2},zoompan=z='min(1.0+0.0012*on,1.22)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)+on*0.45':d={frames}:s={W}x{H}:fps=30"
    if shake:
        vf += f",crop=iw-24:ih-24:12+8*sin(n*2):12+6*cos(n*3),scale={W}:{H}"
    vf += ",fade=t=in:st=0:d=0.18,format=yuv420p"
    sh(["ffmpeg", "-y", "-loop", "1", "-i", str(img), "-vf", vf, "-t", str(round(hold, 3)), "-c:v", "libx264", "-pix_fmt", "yuv420p", str(dest)])
    meta_path.write_text(json.dumps({"hold": round(hold, 3)}))
    return dest

def vision_check(prompt, image_path):
    from PIL import Image
    image = Image.open(image_path).convert("RGB")
    try:
        if VISION["model"] is None:
            pip_try(["transformers", "accelerate", "einops", "pyvips"])
            repo = os.environ.get("AETHER_VISION_REPO", "vikhyatk/moondream2")
            from transformers import AutoModelForCausalLM
            dtype = torch.float16 if GPU_COUNT and torch is not None else None
            model = AutoModelForCausalLM.from_pretrained(repo, trust_remote_code=True, torch_dtype=dtype)
            if GPU_COUNT and torch is not None:
                model = model.to("cuda")
            VISION["model"] = model
        model = VISION["model"]
        question = "Look at the face, hair, outfit, and scene. Does this image match the description? First word yes or no, then one sentence. Description: " + (prompt or "")[:700]
        if hasattr(model, "query"):
            answer = model.query(image, question)
            text = answer.get("answer") if isinstance(answer, dict) else str(answer)
        else:
            encoded = model.encode_image(image)
            tok = getattr(model, "tokenizer", None)
            text = str(model.answer_question(encoded, question, tok))
        cleaned = text.strip()
        match = cleaned.lower().startswith("yes")
        return {"match": bool(match), "note": cleaned[:240]}
    except Exception as exc:
        print("vision model skipped", exc, flush=True)
    try:
        pip_try(["transformers"])
        from transformers import CLIPModel, CLIPProcessor
        clip_id = "openai/clip-vit-base-patch32"
        if VISION.get("clip") is None:
            VISION["clip"] = (
                CLIPModel.from_pretrained(clip_id),
                CLIPProcessor.from_pretrained(clip_id),
            )
        model, processor = VISION["clip"]
        inputs = processor(text=[(prompt or "manhwa panel")[:300], "an empty wall"], images=image, return_tensors="pt", padding=True)
        score = float(model(**inputs).logits_per_image.softmax(dim=1)[0, 0])
        return {"match": score >= 0.24, "note": "CLIP score %.2f. The face model did not load, so this is a weak check." % score}
    except Exception as exc:
        return {"match": "skipped", "note": ("Vision did not load. " + str(exc))[:240]}

def read_bubbles(path):
    try:
        if OCR["reader"] is None:
            pip_try(["easyocr"])
            import easyocr
            OCR["reader"] = easyocr.Reader(["ch_sim", "en"], gpu=GPU_COUNT > 0)
        rows = OCR["reader"].readtext(str(path))
    except Exception as exc:
        print("ocr skipped", exc, flush=True)
        return "", ""
    from PIL import Image
    height = Image.open(path).size[1] or 1
    bubbles = []
    asides = []
    for box, text, conf in rows:
        if conf < 0.35 or not str(text).strip():
            continue
        ys = [point[1] for point in box]
        cy = sum(ys) / max(len(ys), 1) / height
        line = str(text).strip()
        if cy < 0.72 and len(line) <= 80:
            bubbles.append(line)
        else:
            asides.append(line)
    return " ".join(bubbles)[:400], " ".join(asides)[:400]

def extract_html(html, page):
    import urllib.parse
    title_m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    title = re.sub("<[^>]+>", " ", title_m.group(1) if title_m else "")
    title = re.sub(r"\\s+", " ", title).strip()[:180]
    body = re.sub(r"<script[\\s\\S]*?<\/script>", " ", html, flags=re.I)
    body = re.sub(r"<style[\\s\\S]*?</style>", " ", body, flags=re.I)
    panels = []
    for match in re.finditer(r"<img\\b[^>]*>", body, re.I):
        tag = match.group(0)
        src_m = re.search(r"(?:data-src|data-original|src)=[\\"']([^\\"']+)[\\"']", tag, re.I)
        if not src_m:
            continue
        src = src_m.group(1).strip()
        if src.startswith("data:") or re.search(r"logo|icon|sprite|avatar|banner|ads?", src, re.I):
            continue
        src = urllib.parse.urljoin(page, src)
        alt_m = re.search(r"alt=[\\"']([^\\"']*)[\\"']", tag, re.I)
        alt = alt_m.group(1).strip() if alt_m else ""
        after = re.sub("<[^>]+>", " ", body[match.end(): match.end() + 500])
        after = re.sub(r"\\s+", " ", after).strip()[:400]
        panels.append({"src": src, "bubble": alt[:180], "aside": after, "text": (alt + " " + after).strip()[:500]})
        if len(panels) >= 80:
            break
    text = re.sub("<[^>]+>", "\\n", body)
    lines = []
    for line in text.splitlines():
        clean = re.sub(r"\\s+", " ", line).strip()
        if not clean or re.search(r"next chapter|previous chapter|wtr-lab|sign in", clean, re.I):
            continue
        lines.append(clean)
    return title, "\\n".join(lines)[:20000], panels

def run_fetch(job_id, urls, cookie):
    import requests
    row = FETCH_JOBS[job_id]
    headers = {"User-Agent": "Mozilla/5.0"}
    if cookie:
        headers["Cookie"] = cookie
    pages = []
    try:
        for index, url in enumerate(urls, 1):
            row.update(label="Fetching %d of %d" % (index, len(urls)), progress=int(100 * index / len(urls)))
            try:
                res = requests.get(url, headers=headers, timeout=40)
                res.raise_for_status()
                title, text, panels = extract_html(res.text, url)
                pages.append({"url": url, "ok": True, "title": title, "text": text, "panels": panels})
            except Exception as exc:
                pages.append({"url": url, "ok": False, "error": str(exc)[:200], "title": "", "text": "", "panels": []})
            row["pages"] = pages
        row.update(status="done", progress=100, label="Fetch ready", error="")
    except Exception as exc:
        row.update(status="error", error=str(exc)[:300])

def place_panel(scene, dest, size, revoice):
    ensure_panel(scene, dest, size, revoice)


def save_image(raw, dest, size=(1920, 1080)):
    try:
        if fetch_image(raw, dest):
            return dest
    except Exception as exc:
        print("panel fetch failed", exc, flush=True)
    paint_prompt(raw if isinstance(raw, str) else "", dest, size)
    return dest

def render_job(job_id, packet):
    row = JOBS[job_id]
    try:
        aspect = packet.get("aspect") or "9:16"
        vertical = aspect != "16:9"
        W, H = (1080, 1920) if vertical else (1920, 1080)
        revoice = packet.get("pass") == "revoice"
        voice_id = (packet.get("voice") or "").strip() or ("hi-IN-MadhurNeural" if packet.get("language") == "hi" else "en-US-ChristopherNeural")
        chapters = packet.get("chapters") or []
        scenes = []
        for chapter in chapters:
            for scene in chapter.get("scenes") or []:
                scenes.append(scene)
        if not scenes:
            raise RuntimeError("Job packet has no scenes.")
        row.update(progress=8, label="Re-voicing" if revoice else "Voice")
        repo = packet.get("image_repo") or ""
        if isinstance(repo, str) and repo.strip() and not revoice:
            os.environ["AETHER_IMAGE_REPO"] = repo.strip()[:200]
        timing = load_timing()
        audio_parts = []
        clips = []
        cues = []
        voices = {}
        cursor = 0.0
        lang = packet.get("language") or "en"
        for index, scene in enumerate(scenes, 1):
            bubble = scene.get("bubble") or {}
            spoken = " ".join(part for part in [scene.get("caption") or "", bubble.get("text") or ""] if part).strip() or " "
            sid = safe_id(scene.get("id") or ("p%d" % index))
            voice = VOICE_DIR / voice_file_name(sid, lang, voice_id)
            if not (voice.exists() and voice.stat().st_size > 200):
                speak_to(spoken[:700], voice_id, voice)
            voices[sid] = "/api/v1/voices/" + voice.name
            trimmed = OUT / f"{job_id}-v{index}.trim.mp3"
            sh(["ffmpeg", "-y", "-i", str(voice), "-af", "silenceremove=start_periods=1:start_silence=0.02:start_threshold=-45dB:stop_periods=0,apad=pad_dur=0.12", str(trimmed)])
            probe = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(trimmed)], text=True).strip()
            audio_hold = max(float(probe or "1.4"), 1.2)
            saved = timing.get(sid)
            try:
                packet_hold = float(scene.get("hold_sec") or 0)
            except Exception:
                packet_hold = 0
            base = float(saved) if saved is not None else (packet_hold if packet_hold > 0 else audio_hold)
            hold = max(base, audio_hold)
            if saved is None or hold > float(saved) + 0.05:
                timing[sid] = round(float(hold), 3)
                save_timing(timing)
            audio_parts.append(trimmed)
            img = OUT / f"{job_id}-p{index}.png"
            ensure_panel(scene, img, (W, H), revoice)
            clip = panel_clip(sid, img, hold, (W, H), scene.get("sfx") or "", revoice)
            clips.append(clip)
            cues.append((cursor, cursor + hold, spoken))
            cursor += hold
            row.update(progress=10 + int(70 * index / len(scenes)), label=("Re-voicing" if revoice else f"Panel {index}"), timing=timing, voices=voices)
        alist = OUT / f"{job_id}-alist.txt"
        alist.write_text("".join(f"file '{part.resolve()}'\\n" for part in audio_parts))
        voice = OUT / f"{job_id}-voice.mp3"
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(alist), "-c:a", "libmp3lame", "-q:a", "4", str(voice)])
        duration = max(cursor, 1.2)
        lst = OUT / f"{job_id}-list.txt"
        lst.write_text("".join(f"file '{c.resolve()}'\\n" for c in clips))
        silent = OUT / f"{job_id}-silent.mp4"
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(silent)])
        def ts(sec):
            h = int(sec // 3600); m = int((sec % 3600) // 60); s = sec % 60
            return f"{h}:{m:02d}:{s:05.2f}"
        events = []
        srt = []
        for i, (a, b, phrase) in enumerate(cues, 1):
            safe = phrase.replace("{", "(").replace("}", ")").replace("\\n", " ")
            events.append("Dialogue: 0,%s,%s,Default,,0,0,0,,%s" % (ts(a), ts(b), safe))
            def srt_ts(sec):
                ms = int(round((sec - int(sec)) * 1000))
                return f"{int(sec // 3600):02d}:{int((sec % 3600) // 60):02d}:{int(sec % 60):02d},{ms:03d}"
            srt.append(f"{i}\\n{srt_ts(a)} --> {srt_ts(b)}\\n{safe}\\n")
        (OUT / f"{job_id}.srt").write_text("\\n".join(srt))
        align = 2
        margin = 220 if vertical else 80
        ass = OUT / f"{job_id}.ass"
        ass.write_text("\\n".join([
            "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "",
            "[V4+ Styles]",
            "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
            f"Style: Default,Arial,{48 if vertical else 36},&H00F3EADB,&H0014110F,&H8014110F,-1,0,3,8,0,{align},48,48,{margin},1",
            "", "[Events]",
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
            *events, "",
        ]))
        bgm = OUT / f"{job_id}-bgm.wav"
        dur = duration + 0.4
        sh(["ffmpeg", "-y", "-f", "lavfi", "-i", f"sine=frequency=55:duration={dur}", "-f", "lavfi", "-i", f"sine=frequency=82.5:duration={dur}", "-f", "lavfi", "-i", f"sine=frequency=110:duration={dur}:sample_rate=44100", "-filter_complex", f"[0:a]volume=0.35[a];[1:a]volume=0.16[b];[2:a]volume=0.08[c];[a][b][c]amix=inputs=3:normalize=0,lowpass=f=240,volume=0.22,afade=t=in:st=0:d=0.4,afade=t=out:st={max(dur-0.6,0.2)}:d=0.5", str(bgm)])
        mastered = OUT / f"{job_id}-mix.m4a"
        sh(["ffmpeg", "-y", "-i", str(voice), "-i", str(bgm), "-filter_complex", "[1:a]volume=0.18[b];[0:a][b]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=280[duck];[0:a][duck]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95", "-c:a", "aac", str(mastered)])
        final = OUT / f"{job_id}.mp4"
        sub = str(ass).replace(":", "\\\\:").replace("'", "\\\\'")
        sh(["ffmpeg", "-y", "-i", str(silent), "-i", str(mastered), "-vf", f"ass={sub}", "-c:v", "libx264", "-c:a", "aac", "-shortest", "-movflags", "+faststart", str(final)])
        preview = OUT / f"{job_id}-preview.mp4"
        sh(["ffmpeg", "-y", "-i", str(final), "-t", "6", "-c:v", "libx264", "-c:a", "aac", "-movflags", "+faststart", str(preview)])
        lang = packet.get("language") or "en"
        stable = OUT / f"master_{lang}.mp4"
        shutil.copy(final, stable)
        srt_stable = OUT / f"captions_{lang}.srt"
        shutil.copy(OUT / f"{job_id}.srt", srt_stable)
        LATEST["preview"] = preview
        LATEST["mp4"] = str(stable)
        LATEST[f"master_{lang}"] = str(stable)
        LATEST[f"srt_{lang}"] = str(srt_stable)
        row.update(status="done", progress=100, label="Ready", mp4=str(stable), preview=str(preview), error="", timing=timing, voices=voices)
    except Exception as exc:
        row.update(status="error", error=str(exc)[:500], label="Re-voicing" if packet.get("pass") == "revoice" else "")

def youtube_upload(token, path, meta):
    import requests
    size = os.path.getsize(path)
    body = {
        "snippet": {
            "title": (meta.get("title") or "Manhua explanation")[:100],
            "description": (meta.get("description") or "")[:5000],
            "tags": list(meta.get("tags") or [])[:15],
            "categoryId": "24",
        },
        "status": {"privacyStatus": meta.get("privacy") or "private", "selfDeclaredMadeForKids": False},
    }
    init = requests.post(
        "https://www.googleapis.com/upload/youtube/v3/videos",
        params={"uploadType": "resumable", "part": "snippet,status"},
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=UTF-8",
            "X-Upload-Content-Type": "video/mp4",
            "X-Upload-Content-Length": str(size),
        },
        json=body, timeout=60,
    )
    init.raise_for_status()
    loc = init.headers["Location"]
    chunk_size = 8 * 1024 * 1024
    offset = 0
    video_id = None
    with open(path, "rb") as handle:
        while offset < size:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            end = offset + len(chunk) - 1
            put = requests.put(
                loc,
                data=chunk,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "video/mp4",
                    "Content-Length": str(len(chunk)),
                    "Content-Range": f"bytes {offset}-{end}/{size}",
                },
                timeout=180,
            )
            if put.status_code not in (200, 201, 308):
                put.raise_for_status()
            offset = end + 1
            if put.status_code in (200, 201):
                video_id = put.json().get("id")
    if not video_id:
        raise RuntimeError("YouTube did not return a video id.")
    return video_id

def youtube_captions(token, video_id, srt_path, language):
    import requests
    meta = {"snippet": {"videoId": video_id, "language": language, "name": "English" if language == "en" else "Hindi", "isDraft": False}}
    with open(srt_path, "rb") as handle:
        files = {
            "snippet": ("snippet.json", json.dumps(meta), "application/json"),
            "file": (f"captions-{language}.srt", handle, "application/octet-stream"),
        }
        res = requests.post(
            "https://www.googleapis.com/upload/youtube/v3/captions",
            params={"part": "snippet", "uploadType": "multipart"},
            headers={"Authorization": f"Bearer {token}"},
            files=files,
            timeout=90,
        )
    if res.status_code >= 400:
        print("captions skipped", res.status_code, res.text[:180], flush=True)

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/api/v1/health")
def health():
    return {"ok": True, "gpus": GPU_COUNT, "names": GPU_NAMES, "engine": "aether-manhua", "local_ai": True}

@app.post("/api/v1/llm")
async def llm(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    mode = payload.get("model_mode") or "gguf"
    text = complete(mode, payload.get("system") or "", payload.get("prompt") or "")
    return {"text": text, "model": LLM.get("name"), "mode": mode}

@app.post("/api/v1/direct")
async def direct(request: Request):
    return await llm(request)

@app.post("/api/v1/jobs")
async def create_job(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    packet = await request.json()
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"id": job_id, "status": "running", "progress": 5, "label": "Queued", "error": "", "mp4": None, "preview": None}
    threading.Thread(target=render_job, args=(job_id, packet), daemon=True).start()
    return {"id": job_id, "status": "queued"}

@app.get("/api/v1/jobs/{job_id}")
def job_status(job_id: str):
    row = JOBS.get(job_id)
    if not row:
        raise HTTPException(404, "missing job")
    return {"id": job_id, "status": row["status"], "progress": row["progress"], "label": row["label"], "error": row["error"], "mp4_url": f"/api/v1/jobs/{job_id}/mp4" if row["status"] == "done" else None, "timing": row.get("timing") or {}, "voices": row.get("voices") or {}}

@app.get("/api/v1/jobs/{job_id}/mp4")
def job_mp4(job_id: str):
    row = JOBS.get(job_id)
    if not row or not row.get("mp4"):
        raise HTTPException(404, "mp4 not ready")
    return FileResponse(row["mp4"], media_type="video/mp4")

@app.get("/api/v1/preview.mp4")
def preview():
    path = LATEST.get("preview")
    if not path or not Path(path).exists():
        raise HTTPException(404, "preview not ready")
    return FileResponse(path, media_type="video/mp4")

@app.get("/api/v1/masters/{lang}.mp4")
def master_file(lang: str, request: Request):
    if lang not in ("en", "hi"):
        raise HTTPException(404, "language")
    if not allowed(request.headers, request.query_params.get("token", "")):
        raise HTTPException(401, "token")
    path = LATEST.get(f"master_{lang}")
    if not path or not Path(path).exists():
        raise HTTPException(404, "that language master is not ready")
    return FileResponse(path, media_type="video/mp4", filename=f"master_{lang}.mp4")

@app.post("/api/v1/check")
async def check_panel(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    dest = OUT / "check-once.png"
    raw = payload.get("imageBase64") or ""
    try:
        if isinstance(raw, str) and len(raw) > 80:
            dest.write_bytes(base64.b64decode(raw))
        elif not fetch_image(payload.get("imageUrl") or "", dest):
            return {"match": "skipped", "note": "No picture reached the checker."}
    except Exception as exc:
        return {"match": "skipped", "note": str(exc)[:180]}
    verdict = vision_check(payload.get("prompt") or "", dest)
    if verdict["match"] is True:
        return {"match": "yes", "note": verdict["note"]}
    if verdict["match"] is False:
        return {"match": "no", "note": verdict["note"]}
    return {"match": "skipped", "note": verdict["note"]}

@app.post("/api/v1/paint")
async def paint(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    repo = (payload.get("repo") or "").strip()
    if repo:
        wanted = repo[:200]
        if PAINTER.get("name") != wanted:
            PAINTER.update(pipe=None, img2img=None, kind="", name="")
        os.environ["AETHER_IMAGE_REPO"] = wanted
    dest = OUT / "paint-once.png"
    reference = materialize_reference(payload)
    mode = paint_prompt(payload.get("prompt") or "panel", dest, (832, 1216), reference)
    return {"imageBase64": base64.b64encode(dest.read_bytes()).decode(), "mimeType": "image/png", "fallback": mode == "pollinations", "engine": mode, "referenceUsed": bool(reference)}

@app.post("/api/v1/speak")
async def speak(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    text = (payload.get("text") or " ")[:700]
    lang = "hi" if payload.get("language") == "hi" else "en"
    voice = payload.get("voice") or ("hi-IN-MadhurNeural" if lang == "hi" else "en-US-ChristopherNeural")
    sid = safe_id(payload.get("sceneId") or "line")
    dest = VOICE_DIR / voice_file_name(sid, lang, voice)
    if not (dest.exists() and dest.stat().st_size > 200 and not payload.get("force")):
        speak_to(text, voice, dest)
    data = dest.read_bytes()
    encoded = base64.b64encode(data).decode() if len(data) < 1_500_000 else ""
    return {"url": "/api/v1/voices/" + dest.name, "audioBase64": encoded, "mimeType": "audio/mpeg"}

@app.get("/api/v1/voices/{name}")
def voice_file(name: str, request: Request):
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,120}", name):
        raise HTTPException(404, "voice")
    if not allowed(request.headers, request.query_params.get("token", "")):
        raise HTTPException(401, "token")
    path = VOICE_DIR / name
    if not path.exists():
        raise HTTPException(404, "voice not saved")
    return FileResponse(path, media_type="audio/mpeg")

@app.post("/api/v1/fetch")
async def start_fetch(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    urls = []
    for item in payload.get("urls") or []:
        if isinstance(item, str) and item.startswith("http") and len(urls) < 220:
            urls.append(item[:500])
    if not urls:
        raise HTTPException(400, "no urls")
    job_id = uuid.uuid4().hex[:12]
    FETCH_JOBS[job_id] = {"id": job_id, "status": "running", "progress": 1, "label": "Fetching", "error": "", "pages": []}
    threading.Thread(target=run_fetch, args=(job_id, urls, str(payload.get("cookie") or "")[:4000]), daemon=True).start()
    return {"id": job_id, "status": "queued"}

@app.get("/api/v1/fetch/{job_id}")
def fetch_status(job_id: str):
    if not re.fullmatch(r"[A-Za-z0-9]{6,32}", job_id):
        raise HTTPException(404, "missing fetch")
    row = FETCH_JOBS.get(job_id)
    if not row:
        raise HTTPException(404, "missing fetch")
    return {"id": job_id, "status": row["status"], "progress": row["progress"], "label": row["label"], "error": row["error"], "pages": row.get("pages") or []}

@app.post("/api/v1/ocr")
async def ocr(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    panels = []
    for item in (payload.get("images") or [])[:8]:
        if not isinstance(item, dict):
            continue
        dest = OUT / f"ocr-{len(panels)}.png"
        url = item.get("url") or ""
        raw_b64 = item.get("imageBase64") or ""
        try:
            if isinstance(raw_b64, str) and len(raw_b64) > 80:
                dest.write_bytes(base64.b64decode(raw_b64))
            elif not isinstance(url, str) or not fetch_image(url, dest):
                panels.append({"id": str(item.get("id") or ""), "bubble": "", "aside": "", "error": "image did not load"})
                continue
        except Exception as exc:
            panels.append({"id": str(item.get("id") or ""), "bubble": "", "aside": "", "error": str(exc)[:120]})
            continue
        bubble, aside = read_bubbles(dest)
        panels.append({"id": str(item.get("id") or ""), "bubble": bubble, "aside": aside})
    return {"panels": panels}

@app.post("/api/v1/youtube-upload")
async def upload(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    job_id = payload.get("jobId") or ""
    row = JOBS.get(job_id) or {}
    path = row.get("mp4") or LATEST.get(f"master_{payload.get('language') or 'en'}") or LATEST.get("mp4")
    if not path:
        raise HTTPException(404, "render the video first")
    video_id = youtube_upload(payload.get("accessToken") or "", path, payload)
    lang = payload.get("language") or "en"
    srt = LATEST.get(f"srt_{lang}")
    if srt and Path(srt).exists():
        try:
            youtube_captions(payload.get("accessToken") or "", video_id, srt, lang)
        except Exception as exc:
            print("captions skipped", exc, flush=True)
    return {"watchUrl": f"https://www.youtube.com/watch?v={video_id}"}

def boot():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")

threading.Thread(target=boot, daemon=True).start()
time.sleep(1.5)
bin_path = shutil.which("cloudflared")
if not bin_path:
    dest = Path("/tmp/cloudflared")
    subprocess.check_call(["curl", "-fsSL", "-o", str(dest), "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"])
    dest.chmod(0o755)
    bin_path = str(dest)
log = ROOT / "tunnel.log"
proc = subprocess.Popen([bin_path, "tunnel", "--url", f"http://127.0.0.1:{PORT}", "--no-autoupdate"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
url = ""
for _ in range(80):
    line = proc.stdout.readline() if proc.stdout else ""
    if not line:
        time.sleep(0.2)
        continue
    log.write_text(log.read_text() + line if log.exists() else line)
    if "trycloudflare.com" in line:
        start = line.find("https://")
        if start >= 0:
            url = line[start:].strip().split()[0]
            break
print("WORKER_URL", url or "tunnel not ready yet — read aether tunnel log", flush=True)
print("Connection Done — paste WORKER_URL into the phone. Keys stay on the phone.", flush=True)`;function yt(e){let t=e.dialogue.trim(),n=e.speaker.trim();if(!t||!n)return t;let r=n.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);return t.replace(RegExp(`^${r}\\s*[:\\-—–]\\s*`,`i`),``).trim()||t}function bt(e){return e===`public`||e===`unlisted`||e===`private`?e:`private`}var M=`The Lantern Debt

Rain argued with the lanterns on Old Bridge. Ren wore a torn saffron robe over black, a thin scar on his left cheek, and he would not look at the water.

Ren: The pendant cracked because I paid the wrong debt.

He opened his hands. A pale-green jade glowed, and blood threaded his thumb. The glow remembered a name he had tried to forget.

Across the cedar mist, Shao waited with her spear. Silver hair knotted high, black armor, a calm that made the fog step aside.

Shao: Your soul can cross. That body cannot.

Lightning opened the palace gate. Ren stood in the tearing robe. Shao kept the spear lowered, not kind. Between them the debt finally had a face.`,N=`young man, half-tied black hair, thin scar on the left cheek, torn saffron-yellow robe over black`,P={title:`The Lantern Debt`,source:`sample`,text:M,logline:`A cracked jade pendant calls in a debt on a rain-soaked bridge, and the body is not allowed to follow the soul.`,characters:[{id:`ren`,name:`Ren`,soul:`Pays what he owes, even the wrong bill. Refuses to look at the water. The debt stays with him if the body changes.`,vessel:`Living body on the bridge: torn saffron robe, scar on the left cheek. Shao says this body cannot cross.`,look:N},{id:`shao`,name:`Shao`,soul:`The boundary. Calm enough to part fog. She will let a soul through and stop the body.`,vessel:`Silver-white hair in a high knot, black layered armor, long spear. No swap in this chapter.`,look:`woman, silver-white hair in a high knot, black layered armor, long spear, severe calm face`}],timeline:[`Bridge: rain, lanterns, robe already torn, Ren will not face the water.`,`Jade: pendant cracked and glowing, blood on the thumb.`,`Cedar: Shao's vessel unchanged, spear held, fog steps aside.`,`Gate: lightning, robe tearing harder, spear lowered, souls still in their own vessels.`],scenes:[{id:`s1`,caption:`Rain argued with the lanterns. Ren would not look at the water.`,dialogue:`The pendant cracked because I paid the wrong debt.`,speaker:`Ren`,sfx:``,state:`Torn saffron robe, night rain, scar visible`,imagePrompt:`Vertical manhua panel, no text. Night rain on a stone bridge, paper lanterns. ${N}. He will not look at the water.`,imageUrl:`/panels/01-bridge.jpg`,captionEn:`Rain argued with the lanterns. Ren would not look at the water.`,dialogueEn:`The pendant cracked because I paid the wrong debt.`,captionHi:`बारिश लालटेन से झगड़ रही थी। रेन पानी की तरफ़ नहीं देख रहा था।`,dialogueHi:`पेंडेंट इसलिए टूटा क्योंकि मैंने गलत क़र्ज़ चुकाया।`,lineEn:`Rain argued with the lanterns. Ren would not look at the water. The pendant cracked because I paid the wrong debt.`,lineHi:`बारिश लालटेन से झगड़ रही थी। रेन पानी की तरफ़ नहीं देख रहा था। पेंडेंट इसलिए टूटा क्योंकि मैंने गलत क़र्ज़ चुकाया।`,locked:!0},{id:`s2`,caption:`The cracked jade remembered a name he had tried to forget.`,dialogue:``,speaker:``,sfx:`CRACK`,state:`Blood on the thumb, pale-green glow, wet hair`,imagePrompt:`Vertical manhua close-up, no text. ${N}, cupping a cracked glowing jade pendant, blood on the thumb, rain.`,imageUrl:`/panels/02-jade.jpg`,captionEn:`The cracked jade remembered a name he had tried to forget.`,dialogueEn:``,captionHi:`टूटी हुई जेड ने वह नाम याद किया जिसे वह भुलाना चाहता था।`,dialogueHi:``,lineEn:`The cracked jade remembered a name he had tried to forget.`,lineHi:`टूटी हुई जेड ने वह नाम याद किया जिसे वह भुलाना चाहता था।`,locked:!0},{id:`s3`,caption:`Across the cedar mist, Shao waited. Her calm made the fog step aside.`,dialogue:`Your soul can cross. That body cannot.`,speaker:`Shao`,sfx:``,state:`Dawn fog, spear diagonal, silver hair knotted high`,imagePrompt:`Vertical manhua panel, no text. Misty cedar forest at dawn. Woman with silver-white hair in a high knot, black armor, long spear, severe calm face.`,imageUrl:`/panels/03-spear.jpg`,captionEn:`Across the cedar mist, Shao waited. Her calm made the fog step aside.`,dialogueEn:`Your soul can cross. That body cannot.`,captionHi:`देवदार के कोहरे के पार शाओ इंतज़ार कर रही थी। उसके सुकून से कोहरा हट गया।`,dialogueHi:`तुम्हारी रूह पार हो सकती है। यह शरीर नहीं।`,lineEn:`Across the cedar mist, Shao waited. Her calm made the fog step aside. Your soul can cross. That body cannot.`,lineHi:`देवदार के कोहरे के पार शाओ इंतज़ार कर रही थी। उसके सुकून से कोहरा हट गया। तुम्हारी रूह पार हो सकती है। यह शरीर नहीं।`,locked:!0},{id:`s4`,caption:`Lightning opened the palace gate. Between them the debt had a face.`,dialogue:``,speaker:``,sfx:`CRACK`,state:`Robe tearing in the wind, spear lowered, lightning over the gate`,imagePrompt:`Vertical manhua wide panel, no text. Dark palace gate, lightning, rain. Left: ${N}. Right: silver-haired woman in black armor with a spear lowered.`,imageUrl:`/panels/04-gate.jpg`,captionEn:`Lightning opened the palace gate. Between them the debt had a face.`,dialogueEn:``,captionHi:`बिजली ने महल का द्वार खोल दिया। उनके बीच क़र्ज़ का चेहरा था।`,dialogueHi:``,lineEn:`Lightning opened the palace gate. Between them the debt had a face.`,lineHi:`बिजली ने महल का द्वार खोल दिया। उनके बीच क़र्ज़ का चेहरा था।`,locked:!0}],narration:`Rain argued with the lanterns on Old Bridge. Ren would not look at the water. The pendant cracked because he paid the wrong debt. Blood threaded his thumb, and the jade remembered a name. In the cedar mist Shao waited with her spear. Your soul can cross, she said. That body cannot. Lightning opened the palace gate, and the debt finally had a face.`,narrationEn:`Rain argued with the lanterns on Old Bridge. Ren would not look at the water. The pendant cracked because he paid the wrong debt. Blood threaded his thumb, and the jade remembered a name. In the cedar mist Shao waited with her spear. Your soul can cross, she said. That body cannot. Lightning opened the palace gate, and the debt finally had a face.`,narrationHi:`पुराने पुल पर बारिश लालटेन से झगड़ रही थी। रेन पानी की तरफ़ नहीं देख रहा था। पेंडेंट इसलिए टूटा क्योंकि उसने गलत क़र्ज़ चुकाया। अंगूठे पर खून था, और जेड ने एक नाम याद किया। देवदार के कोहरे में शाओ भाला लेकर खड़ी थी। उसने कहा, तुम्हारी रूह पार हो सकती है। यह शरीर नहीं। बिजली ने महल का द्वार खोला, और क़र्ज़ का चेहरा सामने था।`,seo:{title:`The Lantern Debt — a soul may cross, the body may not`,description:`Motion comic. On a rain bridge, Ren's cracked jade calls in a debt. Shao lets the soul through and stops the body at the palace gate.`,tags:[`motion comic`,`manhua`,`The Lantern Debt`,`Ren`,`Shao`,`original story`],hashtags:`#manhua #motioncomic #TheLanternDebt`,privacy:`private`},seoEn:{title:`The Lantern Debt — a soul may cross, the body may not`,description:`Motion comic. On a rain bridge, Ren's cracked jade calls in a debt. Shao lets the soul through and stops the body at the palace gate.`,tags:[`motion comic`,`manhua`,`The Lantern Debt`,`Ren`,`Shao`,`original story`],hashtags:`#manhua #motioncomic #TheLanternDebt`},seoHi:{title:`लालटेन का क़र्ज़ — रूह पार हो सकती है, शरीर नहीं`,description:`मोशन कॉमिक। बारिश वाले पुल पर रेन की टूटी जेड एक क़र्ज़ वसूलती है। शाओ रूह को जाने देती है और शरीर को महल के द्वार पर रोक देती है।`,tags:[`मोशन कॉमिक`,`manhua`,`लालटेन का क़र्ज़`,`Ren`,`Shao`],hashtags:`#manhua #मोशनकॉमिक #लालटेनकाकर्ज़`}},xt=[[/lightning|thunder|gate/i,`CRACK`],[/spear|blade|slash|sword/i,`SHING`],[/crack|shatter|blood|jade/i,`CRACK`],[/gasp|whisper|breath/i,`GASP`],[/boom|roar|explode/i,`BOOM`]];function F(e){return e.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/^-|-$/g,``)||`figure`}function St(e){for(let[t,n]of xt)if(t.test(e))return n;return``}function I(e,t){let n=e.replace(/\s+/g,` `).trim();return n.length<=t?n:`${n.slice(0,t-1).trimEnd()}…`}function L(e){let t=e.split(/\n+/).map(e=>e.trim()).filter(Boolean),n=`Untitled chapter`;t.length>1&&t[0].length<=48&&!t[0].includes(`:`)&&(n=t[0],t.shift());let r=[],i=[],a=()=>{i.length&&r.push(i.join(` `)),i=[]};for(let e of t)/^[^:\n]{1,32}:\s+\S/.test(e)?(a(),r.push(e)):(i.push(e),i.join(` `).length>320&&a());return a(),{title:n,blocks:r}}function Ct(e){let t=e.trim();if(t===M.trim())return P;let n=O(t);if(n===M.trim())return P;let{title:r,blocks:i}=L(n),a=new Map,o=i.map((e,t)=>{let n=e.match(/^([^:\n]{1,32}):\s+([\s\S]+)$/),r=n?n[1].trim():``,i=n?I(n[2],180):``,o=n?``:I(e,220);if(r){let e=a.get(r)??[];e.push(i),a.set(r,e)}let s=`${o} ${i}`;return{id:`s${t+1}`,caption:n?``:I(e,220),dialogue:i,speaker:r,sfx:St(s),state:I(s,120),imagePrompt:`Vertical illustrated comic panel, no text, no letters, no logos, no speech bubbles. ${I(s,400)}`,imageUrl:null}}),s=a.size?[]:n.match(/\b[A-Z][a-z]{2,}(?:\s[A-Z][a-z]+)?\b/g)??[];for(let e of s)[`The`,`Rain`,`Across`,`Between`,`Lightning`,`Your`].includes(e)||a.has(e)||a.set(e,[]);let c=[],l=new Set;for(let[e,t]of a){if(c.length>=24)break;let r=F(e);for(;l.has(r);)r=`${r}-${l.size}`;l.add(r);let i=n.split(/(?<=[.!?])\s+/).find(t=>t.includes(e)&&/robe|hair|scar|armor|spear|eyes|face|blood/i.test(t))??``,a=i?I(i,180):`Body not described in this chapter.`;c.push({id:r,name:e,soul:t[0]?`Says: “${I(t[0],140)}” Identity stays on this name if the body changes.`:`Named in the chapter. Identity stays on this name if the body changes.`,vessel:a,look:a})}o.length===0&&o.push({id:`s1`,caption:`The chapter is empty.`,dialogue:``,speaker:``,sfx:``,state:`Nothing to track yet`,imagePrompt:`Vertical empty storyboard panel, no text`,imageUrl:null});let u=o.map(e=>[e.caption,e.dialogue].filter(Boolean).join(` `)).join(` `).replace(/\s+/g,` `).trim();return{title:r,source:`local`,text:n,logline:I(o.find(e=>e.caption)?.caption||r,160),characters:c,timeline:o.map((e,t)=>`Panel ${t+1}: ${e.state}`),scenes:o,narration:u||r,seo:{title:`${r} — motion comic`,description:I(u||r,180),tags:[`motion comic`,`original story`,...c.map(e=>e.name)].slice(0,8)}}}function wt(e){let t=e[0];if(!t)throw Error(`Nothing to merge.`);let n=[],r=new Set,i=[],a=[];for(let t of e){for(let e of t.characters){let t=e.name.trim().toLowerCase();t&&!r.has(t)&&(r.add(t),n.push(e))}for(let e of t.scenes)i.push({...e,id:`s${i.length+1}`});a.push(...t.timeline)}let o=e.map(e=>e.narration).filter(Boolean).join(` `).replace(/\s+/g,` `).trim(),s=e.map(e=>e.text).join(`

`);return{...t,text:s,characters:n,scenes:i.length?i:t.scenes,timeline:a,narration:o||t.narration||t.title,chapters:void 0,language:gt(`${s}\n${o}`)}}function Tt(e){if(!e.length)throw Error(`No chapters to cut.`);let t=[],n=[],r=[],i=new Set,a=[];for(let o of e){let e=o.text.trim(),s=Ct(e),c=(o.title||s.title||`Chapter ${o.index}`).trim()||`Chapter ${o.index}`,l=s.scenes.map((e,t)=>({...e,id:`s${t+1}`}));t.push({index:o.index,title:c,sourceUrl:o.sourceUrl,narration:s.narration,characters:s.characters,scenes:l});for(let e of l)n.push({...e,id:`c${o.index}-${e.id}`,chapter:o.index});for(let e of s.characters){let t=e.name.trim().toLowerCase();t&&!i.has(t)&&(i.add(t),r.push(e))}a.push(`${c}\n\n${e}`)}let o=a.join(`

`),s=t.map(e=>e.narration).filter(Boolean).join(`

`),c=t.length===1?t[0].title:`${t[0].title} · ${t.length} chapters`;return{title:c,source:`local`,text:o,logline:I(t[0].scenes.find(e=>e.caption)?.caption||c,160),characters:r,timeline:n.map((e,t)=>`Panel ${t+1}: ${e.state}`),scenes:n,narration:s||c,seo:{title:`${c} — motion comic`,description:I(s||c,180),tags:[`motion comic`,`original story`,...r.map(e=>e.name)].slice(0,8)},chapters:t,language:gt(o)}}function Et(e,t){let n=`${e.speaker}\n${e.caption}\n${e.dialogue}\n${e.state}`,r=t.filter(e=>n.includes(e.name)),i=t.find(t=>t.name===e.speaker),a=r.map(e=>e.id);return[{prompt:e.imagePrompt.trim()||`Vertical illustrated comic panel, no text, no letters. ${e.caption||e.dialogue||e.state||`Open panel`}`,negative:k,characters:a,vessel_id:i?.id??a[0]??``}]}function Dt(e,t){let n=`${e.speaker}\n${e.caption}\n${e.dialogue}\n${e.imagePrompt}`,r=t.find(e=>e.faceUrl&&e.name&&n.includes(e.name)),i=t.length===1?t[0]:void 0,a=r?.faceUrl||i?.faceUrl||``;if(!(!a||a.length>4e5))return a}function Ot(e,t){let n=e.imageUrl&&e.imageUrl.length>0&&e.imageUrl.length<=12e5?e.imageUrl:void 0,r=Dt(e,t);return{id:e.id,caption:e.caption,sfx:e.sfx,state:e.state,bubble:{speaker:e.speaker,text:e.dialogue},...n?{image_url:n}:{},...e.holdSec&&e.holdSec>0?{hold_sec:e.holdSec}:{},...r?{reference:r}:{},tiles:Et(e,t)}}function kt(e){return{index:e.index,title:e.title.trim()||`Chapter ${e.index}`,source_url:e.sourceUrl,narration:e.narration,characters:e.characters.map(({id:e,name:t,soul:n,vessel:r})=>({id:e,name:t,soul:n,vessel:r,vessel_id:e})),scenes:e.scenes.map(t=>Ot(t,e.characters))}}function At(e,t){let n=e=>!e||/^https?:\/\//i.test(e)||e.startsWith(`data:`)?e:e.startsWith(`/`)&&/^https?:\/\//i.test(t)?`${t.replace(/\/$/,``)}${e}`:e;return{...e,scenes:e.scenes.map(e=>({...e,imageUrl:n(e.imageUrl)})),chapters:e.chapters?.map(e=>({...e,scenes:e.scenes.map(e=>({...e,imageUrl:n(e.imageUrl)}))}))}}function jt(e,t=`assemble`){let n=e.language??gt(`${e.text}\n${e.narration}`),r=e.chapters?.length?e.chapters.map(kt):[kt({index:1,title:e.title,sourceUrl:null,narration:e.narration,characters:e.characters,scenes:e.scenes})];return ht.parse({version:2,language:n,voice:_t(n,e.voice),title:e.title.trim()||`Untitled chapter`,aspect:e.aspect===`9:16`?`9:16`:`16:9`,local_model:e.localModel===`airllm`||e.localModel===`fast`?e.localModel:`gguf`,hook:e.hook??``,pass:t,chapters:r,seo:{title:e.seo.title,description:e.seo.description,tags:e.seo.tags},...e.imageRepo?.trim()?{image_repo:e.imageRepo.trim().slice(0,200)}:{},note:`Job packet v2. Explanation video. Do not fetch paywalled pages. Panels are prompts for the GPU render, not a static strip.`})}function Mt(e,t,n,r){return{...e,scenes:e.scenes.map(e=>{let i=t[e.id],a=n[e.id],o=i&&i>0?Math.max(e.holdSec||0,i):e.holdSec;return r===`hi`?{...e,...o?{holdSec:o}:{},...a?{voiceHi:a}:{}}:{...e,...o?{holdSec:o}:{},...a?{voiceEn:a}:{}}})}}var Nt=2e3,Pt=8e3;function Ft(e,t,n){let r=e.trim();if(!r)throw Error(`Add a chapter URL.`);if(!Number.isInteger(t)||!Number.isInteger(n))throw Error(`Start and end must be whole numbers.`);if(t<0||n<t)throw Error(`The range has to end on or after the start.`);let i=n-t+1;if(i>2e3)throw Error(`That range is ${i} chapters. Pull at most ${Nt} in one go, or narrow the start and end.`);let a=[];for(let e=t;e<=n;e+=1)a.push(e);if(r.includes(`{n}`))return a.map(e=>r.replaceAll(`{n}`,String(e)));let o=r.match(/\d+/g);if(!o)throw Error(`Put {n} in the URL, or include a chapter number to replace.`);let s=o[o.length-1],c=r.lastIndexOf(s);return a.map(e=>`${r.slice(0,c)}${e}${r.slice(c+s.length)}`)}function It(e,t=Pt){let n=e.replace(/\r\n/g,`
`).trim();if(!n)return[];if(n.length<=t)return[n];let r=[],i=n;for(;i.length>t;){let e=i.lastIndexOf(`

`,t);e<t*.45&&(e=i.lastIndexOf(`
`,t)),e<t*.45&&(e=i.lastIndexOf(`. `,t)),e<t*.45&&(e=t);let n=i.slice(0,e).trim();n&&r.push(n),i=i.slice(e).trim()}if(i&&r.push(i),r.length>1&&r[r.length-1].length<40){let e=r.pop();e&&(r[r.length-1]=`${r[r.length-1]}\n\n${e}`)}return r}function Lt(e){return/\p{Script=Han}/u.test(e)}var R=`manhua-factory-project-v1`;function Rt(e){if(typeof localStorage<`u`)try{let t=e.scenes.map(e=>({...e,imageUrl:e.imageUrl&&e.imageUrl.startsWith(`data:`)&&e.imageUrl.length>8e4?null:e.imageUrl,voiceEn:e.voiceEn?.startsWith(`data:`)?void 0:e.voiceEn,voiceHi:e.voiceHi?.startsWith(`data:`)?void 0:e.voiceHi})),n=e.characters.map(e=>({...e,faceUrl:e.faceUrl&&e.faceUrl.startsWith(`data:`)&&e.faceUrl.length>18e4?void 0:e.faceUrl})),r=JSON.stringify({...e,scenes:t,characters:n});if(r.length>45e5)return;localStorage.setItem(R,r)}catch{}}function zt(){if(typeof localStorage>`u`)return null;try{let e=localStorage.getItem(R);if(!e)return null;let t=JSON.parse(e);return!t||typeof t.title!=`string`||!Array.isArray(t.scenes)?null:t}catch{return null}}var z=t(),Bt={token:``,email:``,channel:``},B=new Map,Vt=Object.keys(fe);function Ht(e,t,n){try{let r=ge(e,`/api/v1/masters/${n}.mp4`);return t.trim()&&r.searchParams.set(`token`,t.trim()),r.toString()}catch{return null}}function Ut(e,t){return t===`revoice`&&(!e||/generat|paint|draw|image/i.test(e))?`Re-voicing`:e}function Wt(e){try{let t=new URL(e.trim());return t.protocol!==`http:`&&t.protocol!==`https:`?null:t.toString()}catch{return null}}function Gt(e){return e===`sample`?`Sample painted`:e===`grok`?`AI recap`:`Fetched chapter`}async function Kt(e){try{return await navigator.clipboard.writeText(e),!0}catch{try{let t=document.createElement(`textarea`);t.value=e,t.setAttribute(`readonly`,``),t.style.position=`fixed`,t.style.top=`0`,t.style.left=`0`,t.style.opacity=`0`,document.body.appendChild(t),t.focus(),t.select();let n=document.execCommand(`copy`);return t.remove(),n}catch{return!1}}}function qt(e,t){let n=t.map((e,t)=>{let n=e.bubble?.trim()||``,r=e.aside?.trim()||``,i=[n,r].filter(Boolean).join(` `).trim()||e.text.trim()||`Panel ${t+1}`,a=r||i,o=n&&r?n:``;return{id:`s${t+1}`,caption:a,dialogue:o,speaker:``,sfx:``,state:`Source panel`,imagePrompt:`Source panel. Do not redraw.`,imageUrl:e.src,locked:!0,promptLocked:!0,lineEn:i,captionEn:a,dialogueEn:o}});return{...P,title:e||`Source panels`,source:`local`,text:n.map(e=>e.caption).join(`

`),logline:n[0]?.caption||e,characters:[],timeline:n.map((e,t)=>`Panel ${t+1}`),scenes:n,narration:n.map(e=>e.caption).join(` `),seo:{...P.seo,title:`${e||`Manhua`} — explanation`,description:(n[0]?.caption||e).slice(0,180)}}}function Jt(e,t){return t.seo.privacy?{...e,seo:{...e.seo,privacy:t.seo.privacy}}:e}function Yt(e){let t=new Set,n=[];for(let r of e.split(`,`)){let e=r.replace(/\s+/g,` `).trim().slice(0,30);if(!e)continue;let i=e.toLowerCase();if(!t.has(i)&&(t.add(i),n.push(e),n.length>=15))break}return n}function Xt(){let e=e=>{let t=[];for(let n=0;n<e.length;n+=1){let r=e.key(n);r&&r.startsWith(`aether-`)&&t.push(r)}for(let n of t)e.removeItem(n)};try{e(localStorage)}catch{}try{e(sessionStorage)}catch{}}function Zt(){return window.google}function Qt(){return Zt()?.accounts?.oauth2?Promise.resolve():new Promise((e,t)=>{let n=document.querySelector(`script[data-aether-gis]`);if(n){n.addEventListener(`load`,()=>e(),{once:!0}),n.addEventListener(`error`,()=>t(Error(`Google sign-in did not load.`)),{once:!0});return}let r=document.createElement(`script`);r.src=`https://accounts.google.com/gsi/client`,r.async=!0,r.dataset.aetherGis=`1`,r.onload=()=>e(),r.onerror=()=>t(Error(`Google sign-in did not load.`)),document.head.appendChild(r)})}function $t({scene:e,wide:t}){let n=yt(e),r=e.imageUrl?(0,z.jsx)(`img`,{src:e.imageUrl,alt:e.caption||n||`Panel`,className:t?`h-full w-full object-cover`:`aspect-[2/3] w-full object-cover`}):(0,z.jsx)(`div`,{className:`flex items-end justify-center bg-panel pb-4 ${t?`h-full w-full`:`aspect-[2/3] w-full`}`,children:(0,z.jsx)(`p`,{className:`text-xs font-semibold tracking-widest text-muted uppercase`,children:`Not painted`})});return(0,z.jsxs)(`figure`,{className:`rounded-2xl bg-ink-2 hairline`,children:[(0,z.jsxs)(`div`,{className:`relative overflow-hidden rounded-t-2xl bg-ink ${t?`aspect-video`:``}`,children:[r,e.sfx?(0,z.jsx)(`p`,{className:`sfx-hit pointer-events-none absolute top-3 left-3 z-10 font-display text-cinnabar italic ${t?`text-3xl`:`text-5xl`}`,children:e.sfx}):null]}),n?(0,z.jsxs)(`div`,{className:`mx-3 mt-3 rounded-2xl bg-paper px-4 py-3 text-ink`,children:[e.speaker?(0,z.jsx)(`p`,{className:`mb-1.5 text-xs font-semibold tracking-widest text-seal uppercase`,children:e.speaker}):null,(0,z.jsx)(`p`,{className:`font-display text-lg leading-snug break-words text-ink`,children:n})]}):null,e.caption?(0,z.jsx)(`p`,{className:`px-4 pt-3 pb-4 text-sm leading-relaxed break-words text-paper`,children:e.caption}):(0,z.jsx)(`div`,{className:`h-3`})]})}function V(){let[e,t]=(0,C.useState)(`story`),[n,r]=(0,C.useState)(P),[i,a]=(0,C.useState)(M),[o,s]=(0,C.useState)(``),[c,l]=(0,C.useState)(null),[u,d]=(0,C.useState)(null),[f,p]=(0,C.useState)(null),[m,h]=(0,C.useState)(!1),[g,_]=(0,C.useState)(null),[v,y]=(0,C.useState)(!1),[b,ce]=(0,C.useState)(``),[x,le]=(0,C.useState)(``),[S,ue]=(0,C.useState)(`zai`),[de,Ne]=(0,C.useState)(he(`zai`)),[Ve,w]=(0,C.useState)(``),[Ge,Ye]=(0,C.useState)(``),[Ze,$e]=(0,C.useState)(``),[et,rt]=(0,C.useState)(!1),[at,D]=(0,C.useState)(null),[st,ct]=(0,C.useState)(null),[k,lt]=(0,C.useState)(`gguf`),[ut,dt]=(0,C.useState)(`split`),[A,ft]=(0,C.useState)(``),[j,pt]=(0,C.useState)(`en`),[mt,ht]=(0,C.useState)(`en-US-ChristopherNeural`),[gt,_t]=(0,C.useState)(`hi-IN-MadhurNeural`),[yt,N]=(0,C.useState)({en:!1,hi:!1}),[xt,F]=(0,C.useState)(!1),[St,I]=(0,C.useState)(!1),[L,Ct]=(0,C.useState)(`9:16`),[Et,Dt]=(0,C.useState)(`3`),[Ot,kt]=(0,C.useState)(``),[Nt,Pt]=(0,C.useState)(``),[R,Wt]=(0,C.useState)(``),[V,tn]=(0,C.useState)(``),[H,nn]=(0,C.useState)(`text`),[rn,an]=(0,C.useState)(``),[on,sn]=(0,C.useState)(`40`),[cn,ln]=(0,C.useState)(`20`),[un,U]=(0,C.useState)(``),[W,dn]=(0,C.useState)({en:Bt,hi:Bt}),[fn,pn]=(0,C.useState)([{role:`studio`,text:`Ask about a look, a line, or the two channels. Changing English or Hindi only re-voices. Pictures stay.`}]),[mn,hn]=(0,C.useState)(``),[G,gn]=(0,C.useState)(0),[K,_n]=(0,C.useState)(null),[vn,yn]=(0,C.useState)(``),[bn,xn]=(0,C.useState)(``),[Sn,Cn]=(0,C.useState)(``),[wn,Tn]=(0,C.useState)(``),[q,En]=(0,C.useState)(null),[Dn,On]=(0,C.useState)(null),[kn,An]=(0,C.useState)(P.seo.tags.join(`, `)),jn=(0,C.useRef)(P.seo.tags.join(`|`)),[Mn,J]=(0,C.useState)({}),Y=(0,C.useRef)(0),Nn=(0,C.useRef)(`assemble`),Pn=(0,C.useRef)(`en`),Fn=(0,C.useRef)(!1);(0,C.useEffect)(()=>{Xt();let e=zt();if(e){r(e),a(e.text||M),(e.language===`hi`||e.language===`en`)&&pt(e.language),e.bible&&U(e.bible),(e.aspect===`16:9`||e.aspect===`9:16`)&&Ct(e.aspect),e.imageRepo&&ft(e.imageRepo);let t={};for(let n of e.scenes)n.voiceEn&&(t[`${n.id}:en`]=!0),n.voiceHi&&(t[`${n.id}:hi`]=!0);J(t),An((e.seo?.tags||[]).join(`, `))}Fn.current=!0},[]),(0,C.useEffect)(()=>{Fn.current&&Rt({...n,imageRepo:A.trim()||n.imageRepo})},[n,A]),(0,C.useEffect)(()=>()=>{q&&URL.revokeObjectURL(q)},[q]);let In=fe[S];function Ln(e){return e===`hi`?gt:mt}let X=Ln(j),Z=Ht(b,x,j);function Q(){return{provider:S,model:Ve.trim()||de,apiKey:Ze.trim(),customBaseUrl:Ge.trim(),workerUrl:b.trim(),workerToken:x.trim(),localModel:k,language:j,duty:ut}}async function Rn(e){let t=e.map(e=>({...e}));if(!b.trim())return t;let n=t.map((e,t)=>({panel:e,index:t})).filter(e=>/^https?:\/\//i.test(e.panel.src));if(!n.length)return t;for(let e=0;e<n.length;e+=8){let r=n.slice(e,e+8);l(`Reading bubbles ${e+1}–${e+r.length} of ${n.length}`);try{let e=await Me({data:{images:r.map(e=>({id:`p${e.index}`,url:e.panel.src})),...Q()}});if(!e.ok){p(`${e.error} Nearby page text is kept.`);break}for(let n of e.panels){let e=Number(n.id.slice(1)),r=t[e];if(!r||!Number.isInteger(e))continue;n.bubble.trim()&&(r.bubble=n.bubble.trim()),n.aside.trim()&&(r.aside=n.aside.trim());let i=[r.bubble,r.aside].filter(Boolean).join(` `).trim();i&&(r.text=i)}}catch{p(`Bubble reading stopped. Nearby page text is kept.`);break}}return t}async function zn(e){let t=new Set(Re(e.scenes)),n=e.scenes.filter(e=>t.has(e.id)&&!e.imagePrompt.trim());if(!n.length)return e;let i=e;for(let e=0;e<n.length;e+=1){let t=n[e];if(t){l(`Writing prompt ${e+1} of ${n.length}. One beat, then the next. No picture yet.`);try{let e=await ve({data:{caption:t.caption,dialogue:t.dialogue,speaker:t.speaker,state:t.state,chapter:t.chapter||0,lock:ze(t,i.characters),...Q()}});if(!e.ok)return d(e.error),l(null),null;i={...i,scenes:i.scenes.map(n=>n.id===t.id?{...n,imagePrompt:e.prompt,promptLocked:!0}:n)},r(i)}catch(e){return d(e instanceof Error?e.message:`The prompt writer stopped. No picture was drawn.`),l(null),null}}}return i}function Bn(e,t,n){r(r=>{let i=r.characters.map(r=>{if(r.id!==e)return r;let i={...r,...t,outfits:t.outfits??r.outfits};return n&&(i.look=Pe(i),i.vessel=i.outfit||i.look),i}),a=i.some(e=>[e.face,e.hair,e.age,e.scars,e.eyes,e.body,e.outfit,...(e.outfits??[]).map(e=>e.outfit)].some(e=>e?.trim()));return{...r,characters:i,...a?{bible:Fe(i)}:{}}})}function Vn(e){if(!e)return``;if(e.startsWith(`data:`)||/^https?:\/\//i.test(e))return e;try{let t=ge(b,e.startsWith(`/api/v1/`)?e:`/api/v1/voices/${e}`);return x.trim()&&t.searchParams.set(`token`,x.trim()),t.toString()}catch{return``}}function Hn(e,t=n){let i={...qe(E(t,j),e),voice:Ln(e)};return pt(e),r(i),An(i.seo.tags.join(`, `)),p(`Language change = audio, captions, and SEO only. Pictures stay.`),i}function Un(e,t,n,i){n&&B.set(`${e}:${t}`,n),J(n=>({...n,[`${e}:${t}`]:!0})),i&&r(n=>({...n,scenes:n.scenes.map(n=>n.id===e?{...n,...t===`hi`?{voiceHi:i}:{voiceEn:i}}:n)}))}async function Wn(e,t,n=!1){let r=e.scenes.filter(e=>T(e,t)?!(t===`hi`?e.voiceHi:e.voiceEn)&&!B.has(`${e.id}:${t}`):!1);if(!r.length){n&&p(`Both voice tracks that exist stay. Nothing was redrawn.`);return}if(!n&&r.length>8){p(`Language change = audio, captions, and SEO only. Pictures stay. Re-voice makes the rest of the male track.`);return}let i=Y.current+1;Y.current=i;for(let e=0;e<r.length;e+=1){if(Y.current!==i)return;let n=r[e];l(`Re-voicing panel ${e+1} of ${r.length}. Pictures stay locked.`);try{let e=await be({data:{text:T(n,t),voice:Ln(t),sceneId:n.id,...Q(),language:t}});if(Y.current!==i)return;if(e.ok){let r=e.audioBase64?`data:${e.mimeType||`audio/mpeg`};base64,${e.audioBase64}`:Vn(e.audioUrl||``);Un(n.id,t,r,e.audioUrl)}}catch{if(Y.current!==i)return;p(`Language change = audio, captions, and SEO only. Pictures stay. One voice line did not start.`);break}}Y.current===i&&(l(null),p(`Language change = audio, captions, and SEO only. Pictures stay.`))}async function $(e){if(e===j||c)return;d(null),Y.current+=1;let t=E(n,j),r=Ke(t,e);if(r.length===0){let n=Hn(e,t);if(F(!1),I(!1),yt[e]){p(`Language change = audio, captions, and SEO only. Pictures stay.`);return}b.trim()?nr(`revoice`,n):Wn(n,e)}else{F(!1),I(!1),l(`Re-voicing. Pictures stay locked.`);try{let n=t,i=n.scenes.filter(e=>r.includes(e.id)),a=``,o=``,s=null;for(let t=0;t<i.length;t+=30){let r=i.slice(t,t+30);l(`Re-voicing lines ${t+1}–${Math.min(t+30,i.length)}. Pictures stay locked.`);let c=await De({data:{target:e,lines:r.map(e=>({id:e.id,caption:e.caption,dialogue:e.dialogue})),...Q(),language:e}});if(!c.ok){d(c.error),l(null);return}n=Je(n,e,c.lines),c.narration&&(a=c.narration),c.seo.title&&(o=c.seo.title,s={...c.seo,privacy:void 0})}let c=Hn(e,e===`hi`?{...n,narrationHi:a||n.narrationHi,seoHi:o&&s?s:n.seoHi}:{...n,narrationEn:a||n.narrationEn,seoEn:o&&s?s:n.seoEn});b.trim()?nr(`revoice`,c):Wn(c,e)}catch(e){d(e instanceof Error?`${e.message} Pictures were not touched.`:`Re-voice stopped. Pictures were not touched.`),l(null)}}}function Gn(e){ue(e),Ne(he(e)),w(``),D(null)}function Kn(e,t){return{...e,source:`grok`,language:j,voice:X,hook:t||e.hook||``,aspect:L,localModel:k,text:i}}async function qn(e,i=un){let o=It(e);if(!o.length)return d(`Paste at least a short chapter.`),!1;let s=[],c=Q();for(let e=0;e<o.length;e+=1){l(o.length>1?`Directing part ${e+1} of ${o.length}`:`Directing the manhua explanation`);let t=await _e({data:{text:o[e],lock:i,...c}});if(!t.ok)return d(o.length>1?`Part ${e+1}: ${t.error}`:t.error),!1;s.push({...t.direction,source:`grok`,text:o[e],hook:t.direction.hook}),t.via===`local`&&p(`Cloud missed. Shifted to the connected Colab/Kaggle model.`)}let u=E(Jt(wt(s),n),j),f=We(u.characters,Ue(e,u.characters)),m=(i||un).trim()||Fe(f);return m&&U(m),r(Kn({...u,characters:f,bible:m||u.bible},s.find(e=>e.hook)?.hook)),a(e),p(o.length>1?`Explanation written in ${o.length} parts. ${u.scenes.length} panels, no four-panel cap.`:`AI Manhua Recap Director wrote ${u.scenes.length} panels in ${j===`hi`?`Hindi`:`English`}.`),t(`forge`),!0}async function Jn(){let e=O(i);e!==i&&a(e),d(null);try{await qn(e)}catch(e){d(e instanceof Error?e.message:`The director did not answer.`)}finally{l(null)}}async function Yn(){d(null);let e=R.trim()!==``||V.trim()!==``,i=rn.trim();if(e){if(R.trim()===``||V.trim()===``){d(`Set both a start and an end chapter.`);return}let e=Number(R),s=Number(V),c=[];try{c=Ft(o,e,s)}catch(e){d(e instanceof Error?e.message:`That chapter range is not valid.`);return}let u=Math.min(100,Math.max(0,Number(on)||0)),f=Math.min(50,Math.max(0,Number(cn)||0)),m=[];try{u>0&&e-u>=1?m.push(...Ft(o,e-u,e-1)):u>0&&e>1&&m.push(...Ft(o,1,e-1)),f>0&&m.push(...Ft(o,s+1,s+f))}catch{}let h=[];try{let o=[...m,...c],s=new Map;if(b.trim()&&o.length>2){l(`Sending the chapter range to the worker. This phone is not opening every page.`);let e=await Ae({data:{urls:o,cookie:i,...Q()}});if(e.ok){for(let t=0;t<90;t+=1){await new Promise(e=>window.setTimeout(e,1500));let t=await je({data:{jobId:e.jobId,...Q()}});if(!t.ok)break;if(l(t.label||`Worker fetch ${t.progress}%`),t.status===`error`)throw Error(t.label||`The worker could not finish that fetch.`);if(t.status===`done`){for(let e of t.pages)s.set(e.url,{title:e.title,text:e.text,error:e.error,ok:e.ok&&!e.error,panels:e.panels});break}}s.size||p(`The worker fetch did not return pages. Reading from this phone instead.`)}}let u=[];for(let e=0;e<m.length;e+=1){let t=m[e];if(!t)continue;let n=s.get(t);if(n?.ok){u.push(n.text);continue}l(`Reading look context ${e+1} of ${m.length}. These pages do not become panels.`);let r=await xe({data:{url:t,cookie:i}});r.ok&&u.push(r.text)}let f=We(n.characters,Ue(u.join(`
`),n.characters)),g=f.some(e=>e.face||e.hair||e.outfit||e.scars||e.eyes),_=g?Fe(f):Xe(u.join(`
`));_&&U(_),g&&r(e=>({...e,characters:f,bible:_})),((Number(on)||0)>100||(Number(cn)||0)>50)&&p(`Look lock was capped at 100 chapters before and 50 after. Those pages never become panels.`);for(let t=0;t<c.length;t+=1){let n=e+t,r=c[t];if(!r)continue;let a=s.get(r);if(a&&!a.ok){d(`Chapter ${n}: ${a.error||`The worker could not open that page.`}`);return}if(a?.ok){h.push({index:n,title:O(a.title)||`Chapter ${n}`,sourceUrl:r,text:O(a.text),panels:a.panels});continue}l(`Reading chapter ${n} (${t+1} of ${c.length})`);let o=await xe({data:{url:r,cookie:i}});if(!o.ok){d(`Chapter ${n}: ${o.error}`);return}h.push({index:n,title:O(o.title)||`Chapter ${n}`,sourceUrl:r,text:O(o.text),panels:o.panels})}if(H===`panels`){let e=h.flatMap(e=>e.panels);if(e=await Rn(e),!e.length){d(`No panel images on those pages. Switch to text mode, or paste the chapter.`);return}let i=E(qt(h[0]?.title||n.title,e),`en`);r({...Jt(i,n),language:j,voice:X,aspect:L,localModel:k,bible:_,characters:g?f:n.characters}),p(`${e.length} source panels locked. Bubbles and nearby lines are separate. They will not be redrawn.`),t(`strip`);return}let ee=h.map(e=>`${e.title}\n\n${e.text}`).join(`

`);if(Lt(ee)||_){a(ee),U(_),p(_?`Look lock saved from nearby chapters. Directing the selected range only.`:`Chinese text pulled. Translating into the explanation script.`),await qn(ee,_);return}let te=Jt(Tt(h),n);r({...E({...te,language:j,voice:X,aspect:L,localModel:k,bible:_,characters:g?We(te.characters,f):te.characters},j)}),a(te.text),p(`${h.length} chapters fetched. Run the director to write the explanation. Pictures are not made yet.`),t(`story`)}catch(e){d(e instanceof Error?e.message:`The chapter range did not load.`)}finally{l(null)}}else{l(`Reading the page`);try{let e=await xe({data:{url:o,cookie:i}});if(!e.ok){d(e.error);return}if(H===`panels`){if(!e.panels.length){d(`No panel images on that page. Switch to text mode, or paste the chapter.`);return}let i=await Rn(e.panels),a=E(qt(e.title||`Source panels`,i),`en`);r({...Jt(a,n),language:j,voice:X,aspect:L,localModel:k}),p(`${i.length} source panels locked. Bubble lines and text near the face stay separate. Nothing is redrawn.`),t(`strip`);return}let s=O(e.title?`${e.title}\n\n${e.text}`:e.text);if(a(s),Lt(s)){p(`Chinese chapter pulled. Translating it into the explanation.`),await qn(s);return}p(`Page text is in the script. Ads and nav were stripped. Direct it when you want the explanation.`)}catch(e){d(e instanceof Error?e.message:`The page did not load.`)}finally{l(null)}}}async function Xn(e){d(null);let i=await zn(n);if(!i)return;let a=i.scenes.filter(t=>t.locked?!1:e?t.id===e:!t.imageUrl);if(!a.length){p(i.scenes.some(e=>e.locked)?`Source panels stay as they are. Nothing was redrawn.`:`The open panels are already painted.`),l(null);return}let o=Q(),s=i,c=!1;for(let e=0;e<a.length;e+=1){let n=s.scenes.find(t=>t.id===a[e]?.id)??a[e];if(!n)continue;let i=null,u=``,f=Math.min(3,Math.max(1,Number(Et)||3));for(let t=1;t<=f;t+=1){l(t===1?`Painting panel ${e+1} of ${a.length}`:`Panel ${e+1} did not match. Retry ${t} of ${f}. Later panels are waiting.`);try{let e=ze(n,s.characters),r=await ye({data:{prompt:[n.imagePrompt,e].filter(Boolean).join(`
`),reference:Be(n,s.characters),repo:A.trim(),...o}});if(!r.ok){d(r.error),l(null);return}r.fallback&&(c=!0);let a=await ke({data:{prompt:n.imagePrompt,imageUrl:r.url,...o}});if(a.ok&&a.match===`no`&&t<f){u=a.note||`Face or scene did not match.`;continue}i=r.url,u=a.ok?a.note:``,a.ok&&a.match===`no`&&(u||=`Still off after ${f} tries.`);break}catch(e){d(e instanceof Error?e.message:`Painting stopped.`),l(null);return}}if(!i){d(`That panel failed three times. The queue is stopped. Pictures already accepted were kept.`),l(null);return}let p=u.startsWith(`Still off`),m=s.characters.filter(e=>[n.caption,n.dialogue,n.speaker,n.imagePrompt].join(`
`).includes(e.name)),h=m.length===1?m[0]:void 0;if(s={...s,characters:s.characters.map(e=>e.faceUrl||!h||e.id!==h.id?e:{...e,faceUrl:i}),scenes:s.scenes.map(e=>e.id===n.id?{...e,imageUrl:i,checkNote:u,retries:p?f:e.retries}:e)},r(s),p){d(`${u} Fix the prompt or retry this panel. The queue is stopped so the next picture does not start on a bad face.`),l(null),t(`strip`);return}}l(null),p(c?`Free fallback painter finished one panel at a time. Faces can drift. Your Colab checkpoint is the real one. Connect the worker so the vision check can run.`:`Panels painted one at a time. The first accepted face is kept as a reference.`),t(`strip`)}(0,C.useEffect)(()=>{_(B.get(`narration:${j}`)??null)},[n.narration,j]);async function Zn(){if(d(null),tt(),g){try{await new Audio(g).play(),p(`Played the saved voice.`)}catch{d(`The track is ready, but this phone blocked playback. Tap again.`)}return}let e=O(n.narration)||n.narration,t=typeof window<`u`?window.speechSynthesis:void 0,r={state:`failed`};t&&(r.state=`reading`,ot(e,it(t.getVoices(),e)).then(()=>{r.state=`done`},()=>{r.state=`failed`})),l(`Reading the chapter`);try{let n=await be({data:{text:e,voice:X,...Q()}});if(n.ok){t?.cancel();let e=`data:${n.mimeType||`audio/mpeg`};base64,${n.audioBase64}`;B.set(`narration:${j}`,e),J(e=>({...e,[`narration:${j}`]:!0})),_(e);try{await new Audio(e).play(),p(`Played ${X}.`)}catch{p(`The voice track is ready. Tap Read again to play it.`)}return}if(r.state!==`failed`){p(`Reading on this phone.`);return}let i=await nt(1200);try{await ot(e,it(i,e)),p(`Reading on this phone.`)}catch{d(`Voice did not start. Tap Read again.`)}}catch(e){if(r.state!==`failed`){p(`Reading on this phone.`);return}d(e instanceof Error?e.message:`The reading stopped.`)}finally{l(null)}}async function Qn(e,t){let n=await Kt(e);p(n?`${t} copied.`:`Could not copy ${t.toLowerCase()} on this phone.`)}async function $n(){l(`Verifying the API`),d(null),D(null);try{let e=await Te({data:Q()});if(!e.ok){d(e.error);return}D(e.badge)}catch(e){d(e instanceof Error?e.message:`The API check failed.`)}finally{l(null)}}async function er(e){let t=(e||b).trim();l(`Testing the worker`),d(null),ct(null);try{let n=await Se({data:{url:t,token:x}});if(!n.ok){d(n.body?`${n.error} ${n.body}`:n.error);return}e&&e!==b&&ce(e),ct(`Connection Done — Local AI & GPU Worker Active`),p(`Worker health answered.`)}catch(e){d(e instanceof Error?e.message:`The worker did not answer.`)}finally{l(null)}}function tr(e=`assemble`,t=n){let r=typeof window<`u`?window.location.origin:``,i=t.language===`hi`||t.language===`en`?t.language:j;return jt(At({...t,language:i,voice:t.voice||me[i],aspect:L,localModel:k,imageRepo:A.trim()||t.imageRepo,hook:t.hook},r),e)}async function nr(e=`assemble`,n){Nn.current=e;let r=n?.language===`hi`||n?.language===`en`?n.language:j;Pn.current=r,l(e===`revoice`?`Re-voicing. Pictures stay locked.`:`Rendering the explanation video`),d(null),On(null);try{let r=await Ce({data:{url:b,token:x,packet:tr(e,n)}});if(!r.ok){d(e===`revoice`?`${r.error} Pictures were not touched.`:r.error);return}r.jobId?(_n({id:r.jobId,status:`queued`,progress:0,label:e===`revoice`?`Re-voicing`:`Accepted`,error:``,mp4Url:null,timing:{},voices:{}}),p(e===`revoice`?`Worker is re-voicing the same pictures. Audio and captions only.`:`Worker accepted the film. Watching job ${r.jobId}.`),t(`bay`)):(_n(null),p(`Worker accepted the packet, but the reply had no job id.`))}catch(e){d(e instanceof Error?e.message:`The worker did not take the job.`)}finally{l(null)}}let rr=!K||K.status===`done`||K.status===`error`;(0,C.useEffect)(()=>{if(!K?.id||rr||!b.trim())return;let e=K.id,t=!1,n=async()=>{try{let n=await we({data:{url:b,token:x,jobId:e}});if(t)return;if(!n.ok){_n(t=>t&&t.id===e?{...t,status:`error`,error:n.error}:t);return}let i={...n.job,label:Ut(n.job.label,Nn.current)};if(_n(i),i.status===`done`){let e=Pn.current;N(t=>({...t,[e]:!0})),(Object.keys(i.timing).length||Object.keys(i.voices).length)&&(r(t=>Mt(t,i.timing,i.voices,e)),J(t=>{let n={...t};for(let t of Object.keys(i.voices))n[`${t}:${e}`]=!0;return n}))}}catch(n){if(t)return;_n(t=>t&&t.id===e?{...t,status:`error`,error:n instanceof Error?n.message:`The status check stopped.`}:t)}};n();let i=window.setInterval(()=>void n(),2500);return()=>{t=!0,window.clearInterval(i)}},[K?.id,rr,b,x]);async function ir(){l(`Loading the 6 second preview`),d(null);try{let e=await fetch(`/api/studio/mp4`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({kind:`preview`,url:b,token:x,jobId:K?.id})});if(!e.ok){let t=await e.json().catch(()=>null);d(t?.error||`The preview did not load.`);return}let t=await e.blob();q&&URL.revokeObjectURL(q),En(URL.createObjectURL(t)),p(`Six second preview is in the player. The full file stayed on the worker.`)}catch(e){d(e instanceof Error?e.message:`The preview did not load.`)}finally{l(null)}}async function ar(){let e=vn.trim();if(!e)d(`Paste the Google OAuth client id first. It stays in this tab only.`);else{d(null),l(`Opening Google`);try{await Qt();let t=Zt();if(!t)throw Error(`Google sign-in did not load.`);t.accounts.oauth2.initTokenClient({client_id:e,scope:`https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly openid email`,callback:e=>{if(!e.access_token){d(e.error||`Google did not return a token.`),l(null);return}xn(e.access_token);let t=j;dn(n=>({...n,[t]:{token:e.access_token||``,email:n[t].email,channel:n[t].channel}})),(async()=>{try{let[n,r]=await Promise.all([fetch(`https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true`,{headers:{Authorization:`Bearer ${e.access_token}`}}),fetch(`https://www.googleapis.com/oauth2/v3/userinfo`,{headers:{Authorization:`Bearer ${e.access_token}`}})]),i=await n.json(),a=await r.json();Tn(i.items?.[0]?.snippet?.title||``),Cn(a.email||``),dn(n=>({...n,[t]:{token:e.access_token||``,email:a.email||``,channel:i.items?.[0]?.snippet?.title||``}})),p(t===`hi`?`Hindi channel connected. Upload sends the Hindi master. Pictures are not redrawn.`:`English channel connected. Upload sends the English master.`)}catch{p(`Token received. Channel details did not load.`)}finally{l(null)}})()}}).requestAccessToken({prompt:`select_account`})}catch(e){d(e instanceof Error?e.message:`Google did not open.`),l(null)}}}async function or(){if(!K||K.status!==`done`){d(`Render the video on the worker, then scrub the preview. The full film stays there.`);return}if(!xt&&!q){d(`Scrub the preview first. Nothing uploads until you have watched it.`);return}let e=W[j].token||bn;if(!e){d(j===`hi`?`Connect the Hindi YouTube channel first.`:`Connect the English YouTube channel first.`);return}l(`Uploading from the worker`),d(null);let t=Yt(kn);try{let r=await Ee({data:{url:b,token:x,jobId:K.id,accessToken:e,title:n.seo.title,description:[n.seo.description,n.seo.hashtags].filter(Boolean).join(`

`),tags:t,privacy:bt(n.seo.privacy),language:j}});if(!r.ok){d(r.error);return}On(r.watchUrl),p(`Uploaded. The watch link is below.`)}catch(e){d(e instanceof Error?e.message:`The upload did not finish.`)}finally{l(null)}}async function sr(){let e=mn.trim();if(e){hn(``),pn(t=>[...t,{role:`user`,text:e}]),l(`Asking the studio AI`),d(null);try{let t=n.scenes.slice(0,40).map(e=>`${e.id}: ${T(e,j).slice(0,90)}`).join(`
`),i=n.characters.map(e=>e.name).filter(Boolean).join(`, `),a=await Oe({data:{message:e,context:`${n.title}. Language ${j}. ${n.scenes.length} panels. Pictures stay on a language switch. Cast: ${i||`none`}.\nBeats:\n${t}\n${n.bible?`Look lock: ${n.bible.slice(0,500)}`:``}`,...Q()}});if(!a.ok){pn(e=>[...e,{role:`studio`,text:a.error}]);return}if(pn(e=>[...e,{role:`studio`,text:a.reply}]),a.action?.type===`line`){let e=a.action;n.scenes.some(t=>t.id===e.id)?(r(t=>({...t,scenes:t.scenes.map(t=>{if(t.id!==e.id)return t;let n={...t,caption:e.text,dialogue:``};return j===`hi`?{...n,captionHi:e.text,dialogueHi:``,lineHi:e.text}:{...n,captionEn:e.text,dialogueEn:``,lineEn:e.text}})})),p(`Beat ${e.id} updated. Pictures were not redrawn.`)):p(`No beat ${e.id}. The line was not changed.`)}if(a.action?.type===`look`){let e=a.action;n.characters.some(t=>t.name.toLowerCase()===e.name.toLowerCase())?(r(t=>{let n=t.characters.map(t=>t.name.toLowerCase()===e.name.toLowerCase()?He(t,e):t);return{...t,characters:n,bible:Fe(n)}}),p(`${e.name} look updated. Pictures were not redrawn.`)):p(`No character named ${e.name}. The look was not changed.`)}}catch(e){pn(t=>[...t,{role:`studio`,text:e instanceof Error?e.message:`The assistant did not answer.`}])}finally{l(null)}}}async function cr(){d(null),tt();let e=n.scenes;if(e.length){for(let t=G;t<e.length;t+=1){gn(t);let n=e[t];if(!n)break;let r=T(n,j),i=`${n.id}:${j}`,a=j===`hi`?n.voiceHi:n.voiceEn,o=B.get(i)||(a?Vn(a):``);if(o){try{await new Audio(o).play()}catch{d(`Playback was blocked. Tap Play again.`);return}await new Promise(e=>window.setTimeout(e,400))}else{l(`Reading panel ${t+1} of ${e.length}`);try{let e=await be({data:{text:r,voice:X,sceneId:n.id,...Q()}});if(e.ok){let t=e.audioBase64?`data:${e.mimeType||`audio/mpeg`};base64,${e.audioBase64}`:Vn(e.audioUrl||``);Un(n.id,j,t,e.audioUrl),t&&await new Audio(t).play()}else await ot(r,null)}catch{try{await ot(r,null)}catch{d(`Voice did not start. Pictures were not touched.`),l(null);return}}}}l(null),p(`Preview played the saved pictures with this language only.`)}}function lr(e,t){r(n=>({...n,scenes:n.scenes.map(n=>{if(n.id!==e)return n;let r={...n,...t},i=[r.caption,r.dialogue].filter(Boolean).join(` `).trim();return j===`hi`?{...r,captionHi:r.caption,dialogueHi:r.dialogue,lineHi:i}:{...r,captionEn:r.caption,dialogueEn:r.dialogue,lineEn:i}})}))}let ur=[{id:`story`,label:`Source`,icon:ie},{id:`strip`,label:`Beats`,icon:ee},{id:`forge`,label:`Cast`,icon:oe},{id:`chat`,label:`Chat`,icon:ne},{id:`bay`,label:`Video`,icon:te},{id:`youtube`,label:`Upload`,icon:se}],dr=n.seo.tags.join(`|`);return(0,C.useEffect)(()=>{jn.current!==dr&&(jn.current=dr,An(n.seo.tags.join(`, `)))},[dr]),(0,z.jsxs)(`main`,{className:`mx-auto min-h-dvh max-w-lg`,children:[(0,z.jsxs)(`header`,{className:`sticky top-0 z-20 flex items-center gap-3 bg-ink/95 px-4 py-3 backdrop-blur`,children:[(0,z.jsx)(`img`,{src:`/favicon.svg`,alt:``,className:`size-9 shrink-0`}),(0,z.jsxs)(`div`,{className:`min-w-0`,children:[(0,z.jsx)(`p`,{className:`text-xs font-semibold tracking-widest text-cinnabar`,children:`AETHER STUDIO`}),(0,z.jsx)(`h1`,{className:`truncate text-xl text-paper`,children:n.title})]}),(0,z.jsx)(`p`,{className:`ml-auto shrink-0 rounded-full bg-panel px-3 py-1 text-xs text-muted`,children:Gt(n.source)}),(0,z.jsx)(`button`,{type:`button`,"aria-label":`Settings`,"aria-pressed":v,onClick:()=>y(e=>!e),className:`flex size-11 shrink-0 items-center justify-center rounded-full ${v?`bg-seal text-paper`:`bg-panel text-paper`}`,children:(0,z.jsx)(ae,{className:`size-5`,"aria-hidden":!0})})]}),c?(0,z.jsxs)(`div`,{className:`px-4`,children:[(0,z.jsx)(`p`,{className:`text-sm text-paper`,children:c}),(0,z.jsx)(`div`,{className:`mt-2 h-0.5 overflow-hidden bg-line`,children:(0,z.jsx)(`div`,{className:`grow-bar h-full bg-cinnabar`})})]}):null,u?(0,z.jsx)(`p`,{role:`alert`,className:`mx-4 mt-3 rounded-2xl bg-panel px-4 py-3 text-sm text-paper`,children:u}):null,f&&!u?(0,z.jsx)(`p`,{className:`mx-4 mt-3 text-sm text-muted`,children:f}):null,(0,z.jsxs)(`div`,{className:`screen-pad px-4 pt-4`,children:[v?(0,z.jsxs)(`section`,{className:`space-y-4`,children:[(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`h2`,{className:`text-3xl text-paper`,children:`Settings`}),(0,z.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:`Keys, tokens, notebook links, and the YouTube token live in this tab’s memory only. Refresh clears them. Nothing is written to storage.`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`ai-provider`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`AI provider`}),(0,z.jsx)(`select`,{id:`ai-provider`,value:S,onChange:e=>Gn(e.target.value),className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base`,children:Vt.map(e=>(0,z.jsx)(`option`,{value:e,children:fe[e].label},e))}),(0,z.jsx)(`span`,{className:`mt-1 block text-xs text-muted`,children:In.hint})]}),In.models.length?(0,z.jsxs)(`label`,{className:`block`,htmlFor:`ai-model`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Model`}),(0,z.jsx)(`select`,{id:`ai-model`,value:de,onChange:e=>{Ne(e.target.value),D(null)},className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base`,children:In.models.map(e=>(0,z.jsx)(`option`,{value:e.id,children:e.label},e.id))})]}):null,(0,z.jsxs)(`label`,{className:`block`,htmlFor:`custom-model`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Model ID`}),(0,z.jsx)(`input`,{id:`custom-model`,value:Ve,onChange:e=>{w(e.target.value),D(null)},placeholder:de||`glm-5.2`,autoComplete:`off`,spellCheck:!1,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`}),(0,z.jsx)(`span`,{className:`mt-1 block text-xs text-muted`,children:`Any id overrides the list. Leave this empty to use the selected model.`})]}),S===`custom`?(0,z.jsxs)(`label`,{className:`block`,htmlFor:`custom-base`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`OpenAI-compatible base URL`}),(0,z.jsx)(`input`,{id:`custom-base`,value:Ge,onChange:e=>Ye(e.target.value),placeholder:`https://host/v1`,inputMode:`url`,autoComplete:`off`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}):null,(0,z.jsxs)(`label`,{className:`block`,htmlFor:`api-key`,children:[(0,z.jsxs)(`span`,{className:`flex items-center justify-between gap-3 text-sm font-medium text-paper`,children:[`API key `,S===`github`?`(GitHub PAT)`:``,(0,z.jsx)(`button`,{type:`button`,onClick:()=>rt(e=>!e),className:`text-xs font-semibold text-cinnabar`,children:et?`Hide`:`Show`})]}),(0,z.jsx)(`input`,{id:`api-key`,type:et?`text`:`password`,value:Ze,onChange:e=>{$e(e.target.value),D(null)},placeholder:S===`github`?`ghp_… or github_pat_…`:`Paste a key. It is not saved.`,autoComplete:`off`,autoCapitalize:`off`,autoCorrect:`off`,spellCheck:!1,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:$n,disabled:!!c||!Ze.trim(),className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Verify & Connect API`}),at?(0,z.jsx)(`p`,{className:`badge-ok rounded-xl px-3 py-2 text-sm font-semibold`,children:at}):null,(0,z.jsxs)(`label`,{className:`block`,htmlFor:`local-mode`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Local model if the cloud key is missing or limited`}),(0,z.jsx)(`select`,{id:`local-mode`,value:k,onChange:e=>lt(e.target.value),className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base`,children:pe.map(e=>(0,z.jsx)(`option`,{value:e.id,children:e.label},e.id))})]}),(0,z.jsxs)(`fieldset`,{children:[(0,z.jsx)(`legend`,{className:`text-sm font-medium text-paper`,children:`Explanation & voiceover language`}),(0,z.jsxs)(`div`,{className:`mt-2 grid grid-cols-1 gap-2`,children:[(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`hi`,onClick:()=>void $(`hi`),className:`min-h-12 rounded-xl px-3 text-left text-sm font-semibold ${j===`hi`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`Hindi re-voice · hi-IN-MadhurNeural`}),(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`en`,onClick:()=>void $(`en`),className:`min-h-12 rounded-xl px-3 text-left text-sm font-semibold ${j===`en`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`English re-voice · en-US-ChristopherNeural`})]})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`voice-en`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`English male voice`}),(0,z.jsxs)(`select`,{id:`voice-en`,value:mt,onChange:e=>{ht(e.target.value);for(let e of[...B.keys()])(e.endsWith(`:en`)||e===`narration:en`)&&B.delete(e);J(e=>{let t={...e};for(let e of Object.keys(t))e.endsWith(`:en`)&&delete t[e];return t}),N(e=>({...e,en:!1}))},className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base`,children:[(0,z.jsx)(`option`,{value:`en-US-ChristopherNeural`,children:`Christopher`}),(0,z.jsx)(`option`,{value:`en-US-AndrewNeural`,children:`Andrew`})]})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`voice-hi`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Hindi male voice`}),(0,z.jsx)(`select`,{id:`voice-hi`,value:gt,onChange:e=>{_t(e.target.value);for(let e of[...B.keys()])(e.endsWith(`:hi`)||e===`narration:hi`)&&B.delete(e);J(e=>{let t={...e};for(let e of Object.keys(t))e.endsWith(`:hi`)&&delete t[e];return t}),N(e=>({...e,hi:!1}))},className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base`,children:(0,z.jsx)(`option`,{value:`hi-IN-MadhurNeural`,children:`Madhur`})})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`retry-count`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Vision retries per panel`}),(0,z.jsx)(`input`,{id:`retry-count`,value:Et,onChange:e=>Dt(e.target.value),inputMode:`numeric`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsxs)(`fieldset`,{children:[(0,z.jsx)(`legend`,{className:`text-sm font-medium text-paper`,children:`Frame`}),(0,z.jsx)(`div`,{className:`mt-2 grid grid-cols-2 gap-2`,children:[`9:16`,`16:9`].map(e=>(0,z.jsx)(`button`,{type:`button`,"aria-pressed":L===e,onClick:()=>Ct(e),className:`min-h-12 rounded-xl text-sm font-semibold ${L===e?`bg-seal text-paper`:`bg-panel text-paper`}`,children:e===`9:16`?`9:16 vertical`:`16:9 wide`},e))})]}),(0,z.jsxs)(`fieldset`,{children:[(0,z.jsx)(`legend`,{className:`text-sm font-medium text-paper`,children:`Who writes, who draws`}),(0,z.jsx)(`div`,{className:`mt-2 grid grid-cols-1 gap-2`,children:[[`split`,`Split — key writes and checks. Worker draws, speaks, and cuts.`],[`worker`,`Worker does the writing too.`],[`key`,`Key only for text. Pictures use the free fallback if no worker draw is allowed.`]].map(([e,t])=>(0,z.jsx)(`button`,{type:`button`,"aria-pressed":ut===e,onClick:()=>dt(e),className:`min-h-12 rounded-xl px-3 text-left text-sm font-semibold ${ut===e?`bg-seal text-paper`:`bg-panel text-paper`}`,children:t},e))}),(0,z.jsx)(`p`,{className:`mt-2 text-xs text-muted`,children:`Default is split. A language switch still does not redraw.`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`image-repo`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Image checkpoint`}),(0,z.jsx)(`input`,{id:`image-repo`,value:A,onChange:e=>ft(e.target.value),placeholder:`cagliostrolab/animagine-xl-3.1 or a Flux repo`,autoComplete:`off`,spellCheck:!1,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`}),(0,z.jsx)(`span`,{className:`mt-1 block text-xs text-muted`,children:`Empty keeps the worker default. A repo name with “flux” loads Flux and can use the saved face. If that model cannot load, Pollinations runs, then a simple ink drawing. Faces can drift on the fallback.`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`worker-url`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Live worker URL`}),(0,z.jsx)(`input`,{id:`worker-url`,value:b,onChange:e=>{ce(e.target.value),ct(null)},placeholder:`https://….trycloudflare.com`,inputMode:`url`,autoComplete:`off`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`worker-token`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Worker token`}),(0,z.jsx)(`input`,{id:`worker-token`,type:`password`,value:x,onChange:e=>le(e.target.value),autoComplete:`off`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>er(),disabled:!!c||!b.trim(),className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Test & Connect`}),st?(0,z.jsx)(`p`,{className:`badge-ok rounded-xl px-3 py-2 text-sm font-semibold`,children:st}):null,(0,z.jsx)(en,{colabUrl:Ot,kaggleUrl:Nt,onColab:kt,onKaggle:Pt,onTest:e=>er(/trycloudflare\.com|ngrok/i.test(e)?e:b),busy:!!c,badge:st})]}):null,!v&&e===`story`?(0,z.jsxs)(`section`,{className:`space-y-4`,children:[(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`h2`,{className:`text-3xl text-paper`,children:`Explain the chapter`}),(0,z.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:`Chinese from WTR-LAB is translated by the active model into a Hindi or English manhua explanation. Nothing is stored on this phone.`})]}),(0,z.jsxs)(`fieldset`,{children:[(0,z.jsx)(`legend`,{className:`text-sm font-medium text-paper`,children:`Explanation & voiceover language`}),(0,z.jsxs)(`div`,{className:`mt-2 grid grid-cols-2 gap-2`,children:[(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`hi`,onClick:()=>void $(`hi`),className:`min-h-12 rounded-xl px-2 text-sm font-semibold ${j===`hi`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`Hindi`}),(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`en`,onClick:()=>void $(`en`),className:`min-h-12 rounded-xl px-2 text-sm font-semibold ${j===`en`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`English`})]}),(0,z.jsx)(`p`,{className:`mt-2 text-xs text-muted`,children:`Language change = audio, captions, and SEO only. Pictures stay.`})]}),(0,z.jsxs)(`fieldset`,{children:[(0,z.jsx)(`legend`,{className:`text-sm font-medium text-paper`,children:`Source`}),(0,z.jsxs)(`div`,{className:`mt-2 grid grid-cols-2 gap-2`,children:[(0,z.jsx)(`button`,{type:`button`,"aria-pressed":H===`text`,onClick:()=>nn(`text`),className:`min-h-12 rounded-xl px-2 text-sm font-semibold ${H===`text`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`Text only`}),(0,z.jsx)(`button`,{type:`button`,"aria-pressed":H===`panels`,onClick:()=>nn(`panels`),className:`min-h-12 rounded-xl px-2 text-sm font-semibold ${H===`panels`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`Picture manhua`})]})]}),(0,z.jsxs)(`label`,{className:`block`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Chapter script`}),(0,z.jsx)(`textarea`,{value:i,onChange:e=>a(e.target.value),onPaste:e=>{let t=e.clipboardData.getData(`text`);if(!t)return;e.preventDefault();let n=e.currentTarget.selectionStart??i.length,r=e.currentTarget.selectionEnd??i.length;a(O(`${i.slice(0,n)}${t}${i.slice(r)}`))},className:`field mt-2 min-h-72 w-full rounded-2xl px-4 py-3 text-base outline-none`,spellCheck:!0})]}),(0,z.jsx)(`button`,{type:`button`,onClick:Jn,disabled:!!c,className:`min-h-14 w-full rounded-2xl bg-seal px-3 text-sm font-semibold text-paper disabled:opacity-50`,children:`AI Manhua Recap Director (GLM-5.2)`}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>{r(P),a(M),p(`Sample restored.`)},className:`min-h-11 w-full text-sm font-semibold text-cinnabar`,children:`Restore sample`}),(0,z.jsxs)(`div`,{className:`rounded-2xl bg-ink-2 p-4`,children:[(0,z.jsx)(`label`,{className:`block text-sm font-medium text-paper`,htmlFor:`source-url`,children:`Chapter link`}),(0,z.jsx)(`input`,{id:`source-url`,value:o,onChange:e=>s(e.target.value),placeholder:`https://wtr-lab.com/…/chapter-1`,inputMode:`url`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`}),(0,z.jsxs)(`div`,{className:`mt-3 grid grid-cols-2 gap-2`,children:[(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`chapter-start`,children:[`Start`,(0,z.jsx)(`input`,{id:`chapter-start`,value:R,onChange:e=>Wt(e.target.value),inputMode:`numeric`,placeholder:`1`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`})]}),(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`chapter-end`,children:[`End`,(0,z.jsx)(`input`,{id:`chapter-end`,value:V,onChange:e=>tn(e.target.value),inputMode:`numeric`,placeholder:`12`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`})]})]}),(0,z.jsxs)(`div`,{className:`mt-3 grid grid-cols-2 gap-2`,children:[(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`bible-before`,children:[`Chapters before (look only)`,(0,z.jsx)(`input`,{id:`bible-before`,value:on,onChange:e=>sn(e.target.value),inputMode:`numeric`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`bible-after`,children:[`Chapters after (look only)`,(0,z.jsx)(`input`,{id:`bible-after`,value:cn,onChange:e=>ln(e.target.value),inputMode:`numeric`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]})]}),(0,z.jsxs)(`label`,{className:`mt-3 block text-sm text-paper`,htmlFor:`source-cookie`,children:[`Site cookie, only if the page is behind your login`,(0,z.jsx)(`input`,{id:`source-cookie`,value:rn,onChange:e=>an(e.target.value),autoComplete:`off`,spellCheck:!1,placeholder:`Paste the cookie from a tab you are logged into`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`})]}),(0,z.jsx)(`p`,{className:`mt-2 text-xs text-muted`,children:`Passwords are never asked. The cookie is sent only with that fetch and is not saved. Nearby chapters lock the character look and are not turned into panels.`}),(0,z.jsx)(`button`,{type:`button`,onClick:Yn,disabled:!!c||!o.trim(),className:`mt-3 min-h-12 w-full rounded-xl bg-panel text-sm font-semibold text-paper disabled:opacity-50`,children:R.trim()||V.trim()?`Pull chapter range`:`Pull readable text`})]}),(0,z.jsxs)(`div`,{className:`rounded-2xl bg-ink-2 p-4 text-xs leading-relaxed text-muted`,children:[(0,z.jsx)(`p`,{className:`text-sm font-medium text-paper`,children:`Hard limits`}),(0,z.jsx)(`p`,{className:`mt-2`,children:`This studio directs. Colab or Kaggle grows a long film and draws panels. A multi-hour file stays on the worker, not in the phone.`}),(0,z.jsx)(`p`,{className:`mt-2`,children:`Login walls work only with your cookie, and some sites still refuse. Paste the chapter when that happens.`}),(0,z.jsx)(`p`,{className:`mt-2`,children:`The picture check is a vision pass, not magic. After the retry count, you decide. Language change = audio, captions, and SEO only. Pictures stay. A longer line holds the same panel longer.`}),(0,z.jsx)(`p`,{className:`mt-2`,children:`Copyright stays with you. This is a production tool.`})]})]}):null,!v&&e===`forge`?(0,z.jsxs)(`section`,{className:`space-y-5`,children:[(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`h2`,{className:`text-3xl text-paper`,children:`Soul and vessel`}),(0,z.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:n.hook||n.logline})]}),(0,z.jsxs)(`ul`,{className:`space-y-3`,children:[n.characters.length===0?(0,z.jsx)(`li`,{className:`text-sm text-muted`,children:`No named cast in this cut.`}):null,n.characters.map(e=>(0,z.jsxs)(`li`,{className:`rounded-2xl bg-ink-2 p-4`,children:[(0,z.jsx)(`p`,{className:`font-display text-2xl text-paper`,children:e.name}),(0,z.jsxs)(`label`,{className:`mt-3 block text-xs font-semibold tracking-widest text-cinnabar uppercase`,htmlFor:`soul-${e.id}`,children:[`Soul`,(0,z.jsx)(`textarea`,{id:`soul-${e.id}`,value:e.soul,onChange:t=>r(n=>({...n,characters:n.characters.map(n=>n.id===e.id?{...n,soul:t.target.value}:n)})),className:`field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm font-medium normal-case outline-none`})]}),(0,z.jsxs)(`label`,{className:`mt-3 block text-xs font-semibold tracking-widest text-cinnabar uppercase`,htmlFor:`look-${e.id}`,children:[`Locked look`,(0,z.jsx)(`textarea`,{id:`look-${e.id}`,value:e.look,onChange:t=>Bn(e.id,{look:t.target.value,vessel:t.target.value},!1),className:`field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm font-medium normal-case outline-none`})]}),(0,z.jsx)(`div`,{className:`mt-3 grid grid-cols-2 gap-2`,children:[[`face`,`Face`],[`hair`,`Hair`],[`age`,`Age`],[`scars`,`Scars`],[`eyes`,`Eyes`],[`body`,`Body`],[`outfit`,`Outfit`]].map(([t,n])=>(0,z.jsxs)(`label`,{className:`block text-xs font-semibold tracking-widest text-cinnabar uppercase`,htmlFor:`${t}-${e.id}`,children:[n,(0,z.jsx)(`input`,{id:`${t}-${e.id}`,value:e[t]||``,onChange:n=>Bn(e.id,{[t]:n.target.value},!0),className:`field mt-2 min-h-11 w-full rounded-xl px-3 text-sm font-medium normal-case outline-none`})]},t))}),(0,z.jsxs)(`label`,{className:`mt-3 block text-xs font-semibold tracking-widest text-cinnabar uppercase`,htmlFor:`outfits-${e.id}`,children:[`Outfit changes, one chapter per line`,(0,z.jsx)(`textarea`,{id:`outfits-${e.id}`,value:Le(e.outfits),onChange:t=>Bn(e.id,{outfits:Ie(t.target.value)},!0),placeholder:`420: black court robe
460: travel cloak`,className:`field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm font-medium normal-case outline-none`})]}),e.faceUrl?(0,z.jsx)(`img`,{src:e.faceUrl,alt:``,className:`mt-3 h-24 w-16 rounded-lg object-cover`}):(0,z.jsx)(`p`,{className:`mt-2 text-xs text-muted`,children:`The first accepted panel of this face is kept as a reference. A language switch does not replace it.`})]},e.id))]}),(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`bible-lock`,children:[`Character bible`,(0,z.jsx)(`textarea`,{id:`bible-lock`,value:n.bible||un,onChange:e=>{U(e.target.value),r(t=>({...t,bible:e.target.value}))},className:`field mt-2 min-h-28 w-full rounded-xl px-3 py-3 text-sm outline-none`,placeholder:`Face, hair, scars, outfit, and the chapter an outfit changes. Written once. A language switch does not rebuild it.`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>void zn(n),disabled:!!c,className:`min-h-12 w-full rounded-2xl bg-panel text-sm font-semibold text-paper disabled:opacity-50`,children:`Write prompts, one beat at a time`}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>void Xn(),disabled:!!c,className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Paint unpainted panels`}),(0,z.jsx)(`p`,{className:`text-xs text-muted`,children:`One English prompt per beat, then one picture. The worker checkpoint draws it. If that model cannot load, the free fallback is used and faces can drift. A language switch does not come back here.`})]}):null,!v&&e===`strip`?(0,z.jsxs)(`section`,{className:`space-y-4`,children:[(0,z.jsx)(`div`,{className:`flex items-end justify-between gap-3`,children:(0,z.jsx)(`h2`,{className:`text-3xl text-paper`,children:`Explanation film`})}),(0,z.jsx)(`div`,{className:`grid grid-cols-2 gap-2`,role:`group`,"aria-label":`Aspect ratio`,children:[`16:9`,`9:16`].map(e=>(0,z.jsx)(`button`,{type:`button`,"aria-pressed":L===e,onClick:()=>Ct(e),className:`min-h-12 rounded-xl text-sm font-semibold ${L===e?`bg-seal text-paper`:`bg-panel text-paper`}`,children:e===`16:9`?`16:9 YouTube`:`9:16 Shorts`},e))}),(0,z.jsxs)(`p`,{className:`text-sm text-muted`,children:[n.scenes.length,` panels. Play scrubs the pictures already made. A language switch does not send them back to the painter.`]}),(0,z.jsxs)(`div`,{className:`overflow-hidden rounded-2xl bg-ink`,children:[n.scenes[G]?.imageUrl?(0,z.jsx)(`img`,{src:n.scenes[G]?.imageUrl||``,alt:``,className:L===`16:9`?`aspect-video w-full object-cover`:`aspect-[9/16] max-h-[70vh] w-full object-cover`}):(0,z.jsx)(`div`,{className:`flex aspect-[9/16] items-end justify-center pb-4`,children:(0,z.jsx)(`p`,{className:`text-xs font-semibold tracking-widest text-muted uppercase`,children:`Not painted`})}),(0,z.jsxs)(`div`,{className:`bg-paper px-4 py-3 text-ink`,children:[(0,z.jsx)(`p`,{className:`text-xs font-semibold tracking-widest text-seal uppercase`,children:j===`hi`?`Hindi caption`:`English caption`}),(0,z.jsx)(`p`,{className:`mt-1 font-display text-lg leading-snug`,children:n.scenes[G]?T(n.scenes[G],j):``})]})]}),(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`panel-seek`,children:[`Panel `,G+1,` of `,Math.max(n.scenes.length,1),(0,z.jsx)(`input`,{id:`panel-seek`,type:`range`,min:0,max:Math.max(n.scenes.length-1,0),value:Math.min(G,Math.max(n.scenes.length-1,0)),onChange:e=>gn(Number(e.target.value)),className:`mt-2 w-full`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>void cr(),disabled:!!c||n.scenes.length===0,className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Play from this panel`}),n.bible?(0,z.jsxs)(`p`,{className:`text-xs text-muted`,children:[`Look lock: `,n.bible.slice(0,220)]}):null,(0,z.jsx)(`div`,{className:`space-y-4`,children:n.scenes.map((e,t)=>{let n=j===`hi`?`en`:`hi`,i=T(e,n);return(0,z.jsxs)(`div`,{className:`space-y-2`,children:[(0,z.jsx)($t,{scene:e,wide:L===`16:9`}),(0,z.jsxs)(`p`,{className:`text-xs text-muted`,children:[`Beat `,t+1,e.locked?` · source panel, not redrawn`:``,` · `,`EN voice `,Mn[`${e.id}:en`]?`saved`:`missing`,` · `,`HI voice `,Mn[`${e.id}:hi`]?`saved`:`missing`,e.checkNote?` · ${e.checkNote}`:``]}),(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`line-${e.id}`,children:[j===`hi`?`Hindi line`:`English line`,(0,z.jsx)(`textarea`,{id:`line-${e.id}`,value:[e.caption,e.dialogue].filter(Boolean).join(`
`),onChange:t=>lr(e.id,{caption:t.target.value,dialogue:``}),className:`field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm outline-none`})]}),i?(0,z.jsxs)(`p`,{className:`text-xs text-muted`,children:[n===`hi`?`Hindi`:`English`,` kept: `,i]}):(0,z.jsxs)(`p`,{className:`text-xs text-muted`,children:[n===`hi`?`Hindi`:`English`,` line is not written yet. A language switch translates this beat only.`]}),e.locked?null:(0,z.jsxs)(`label`,{className:`block text-sm text-paper`,htmlFor:`prompt-${e.id}`,children:[`Image prompt, English`,(0,z.jsx)(`textarea`,{id:`prompt-${e.id}`,value:e.imagePrompt,onChange:t=>r(n=>({...n,scenes:n.scenes.map(n=>n.id===e.id?{...n,imagePrompt:t.target.value,promptLocked:t.target.value.trim().length>0}:n)})),className:`field mt-2 min-h-24 w-full rounded-xl px-3 py-2 text-sm outline-none`})]}),e.locked?null:(0,z.jsx)(`button`,{type:`button`,onClick:()=>void Xn(e.id),disabled:!!c,className:`min-h-11 rounded-xl bg-panel px-4 text-sm font-semibold text-paper disabled:opacity-50`,children:`Retry this panel`})]},e.id)})}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>void nr(),disabled:!!c||!b.trim(),className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Render explanation video`})]}):null,!v&&e===`chat`?(0,z.jsxs)(`section`,{className:`space-y-4`,children:[(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`h2`,{className:`text-3xl text-paper`,children:`Chat`}),(0,z.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:`Same AI as the director. It can see this project. Correct a look or a line here. A language change does not redraw.`})]}),(0,z.jsx)(`ul`,{className:`space-y-2`,children:fn.map((e,t)=>(0,z.jsx)(`li`,{className:`rounded-2xl px-4 py-3 text-sm ${e.role===`user`?`bg-seal text-paper`:`bg-ink-2 text-paper`}`,children:e.text},`${e.role}-${t}`))}),(0,z.jsxs)(`form`,{className:`flex gap-2`,onSubmit:e=>{e.preventDefault(),sr()},children:[(0,z.jsxs)(`label`,{className:`min-w-0 flex-1`,htmlFor:`chat-draft`,children:[(0,z.jsx)(`span`,{className:`sr-only`,children:`Message`}),(0,z.jsx)(`input`,{id:`chat-draft`,value:mn,onChange:e=>hn(e.target.value),placeholder:`The scar is on the left cheek`,className:`field min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsx)(`button`,{type:`submit`,disabled:!!c||!mn.trim(),className:`min-h-12 rounded-xl bg-seal px-4 text-sm font-semibold text-paper disabled:opacity-50`,children:`Send`})]}),fn.some(e=>e.role===`studio`)?(0,z.jsx)(`button`,{type:`button`,onClick:()=>{let e=[...fn].reverse().find(e=>e.role===`studio`);e&&(U(t=>[t,e.text].filter(Boolean).join(`
`)),r(t=>({...t,bible:[t.bible,e.text].filter(Boolean).join(`
`)})),p(`Saved into the character bible. Pictures were not redrawn.`))},className:`min-h-11 text-sm font-semibold text-cinnabar`,children:`Lock the last reply into the character bible`}):null]}):null,!v&&e===`bay`?(0,z.jsxs)(`section`,{className:`space-y-4`,children:[(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`h2`,{className:`text-3xl text-paper`,children:`Factory bay`}),(0,z.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:b.trim()?`The worker keeps the long file. Scrub the master here. Language change = audio, captions, and SEO only. Pictures stay.`:`The worker is offline. Scrub the panels on Beats. This phone will not pretend a full film is ready.`})]}),(0,z.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`en`,onClick:()=>void $(`en`),className:`min-h-12 rounded-xl text-sm font-semibold ${j===`en`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`English audio`}),(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`hi`,onClick:()=>void $(`hi`),className:`min-h-12 rounded-xl text-sm font-semibold ${j===`hi`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`Hindi audio`})]}),(0,z.jsx)(`div`,{className:`overflow-hidden rounded-2xl bg-ink`,children:Z?(0,z.jsx)(`video`,{src:Z,controls:!0,playsInline:!0,preload:`metadata`,className:`aspect-[9/16] max-h-[70vh] w-full bg-ink`,onLoadedData:()=>{F(!0),I(!1)},onError:()=>I(!0)},Z):(0,z.jsx)(`div`,{className:`flex aspect-[9/16] max-h-80 items-end justify-center pb-4`,children:(0,z.jsx)(`p`,{className:`px-4 text-center text-xs font-semibold tracking-widest text-muted uppercase`,children:`Worker offline`})})}),St?(0,z.jsxs)(`p`,{className:`text-sm text-paper`,children:[`The worker is offline, or the `,j===`hi`?`Hindi`:`English`,` master is not ready. Pictures were not redrawn.`]}):null,(0,z.jsxs)(`div`,{className:`rounded-2xl bg-ink-2 p-4`,children:[(0,z.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,z.jsx)(re,{className:`size-4 text-cinnabar`,"aria-hidden":!0}),(0,z.jsxs)(`h3`,{className:`text-lg text-paper`,children:[`Narration · `,X]})]}),(0,z.jsx)(`p`,{className:`mt-2 text-sm text-paper`,children:n.narration}),(0,z.jsx)(`button`,{type:`button`,onClick:Zn,disabled:!!c,className:`mt-3 min-h-12 w-full rounded-xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Read it`}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>void Wn(n,j,!0),disabled:!!c,className:`mt-2 min-h-12 w-full rounded-xl bg-panel text-sm font-semibold text-paper disabled:opacity-50`,children:`Re-voice missing lines`})]}),(0,z.jsxs)(`div`,{className:`rounded-2xl bg-ink-2 p-4`,children:[(0,z.jsx)(`h3`,{className:`text-lg text-paper`,children:j===`hi`?`Hindi captions`:`English captions`}),(0,z.jsx)(`pre`,{className:`mt-2 max-h-40 overflow-auto text-xs text-paper`,children:Qe(n,j)}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>Qn(Qe(n,j),j===`hi`?`Hindi captions`:`English captions`),className:`mt-2 min-h-11 text-sm font-semibold text-cinnabar`,children:`Copy this .srt`}),(0,z.jsx)(`p`,{className:`mt-2 text-xs text-muted`,children:`The other language keeps its own captions. Silence is trimmed on the worker after each voice, without cutting a breath inside a line.`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>void nr(),disabled:!!c||!b.trim(),className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Send film to worker`}),(0,z.jsxs)(`div`,{className:`rounded-2xl bg-ink-2 p-4`,children:[(0,z.jsx)(`h3`,{className:`text-lg text-paper`,children:`Render status`}),K?(0,z.jsxs)(`div`,{className:`mt-3`,"aria-live":`polite`,children:[(0,z.jsxs)(`p`,{className:`text-sm text-paper`,children:[K.id,` · `,K.status,K.label?` · ${K.label}`:``]}),(0,z.jsx)(`div`,{className:`mt-2 h-2 overflow-hidden rounded-full bg-line`,children:(0,z.jsx)(`div`,{className:`h-full bg-cinnabar`,style:{width:`${K.progress}%`}})}),K.error?(0,z.jsx)(`p`,{className:`mt-2 text-sm text-paper`,children:K.error}):null,(0,z.jsx)(`button`,{type:`button`,onClick:()=>void nr(),disabled:!!c,className:`mt-3 min-h-12 w-full rounded-xl bg-panel text-sm font-semibold text-paper disabled:opacity-50`,children:`Render again`})]}):(0,z.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:`No job yet. Connect the worker, then render.`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>h(e=>!e),className:`min-h-11 text-sm font-semibold text-cinnabar`,children:m?`Hide factory cell`:`Show factory cell`}),m?(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`pre`,{className:`max-h-80 overflow-auto rounded-2xl bg-ink-2 p-3 text-xs text-paper`,children:vt}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>Qn(vt,`Factory cell`),className:`mt-2 min-h-11 rounded-xl bg-panel px-4 text-sm text-paper`,children:`Copy factory cell`})]}):null]}):null,!v&&e===`youtube`?(0,z.jsxs)(`section`,{className:`space-y-4`,"aria-labelledby":`youtube-heading`,children:[(0,z.jsxs)(`div`,{children:[(0,z.jsx)(`h2`,{id:`youtube-heading`,className:`text-3xl text-paper`,children:`YouTube`}),(0,z.jsxs)(`p`,{className:`mt-2 text-sm text-muted`,children:[`Preview first. Upload uses the `,j===`hi`?`Hindi`:`English`,` channel and that language’s master. The phone does not hold the full file. Nothing uploads until you press Upload.`]})]}),(0,z.jsx)(`div`,{className:`overflow-hidden rounded-2xl bg-ink`,children:Z?(0,z.jsx)(`video`,{src:Z,controls:!0,playsInline:!0,preload:`metadata`,className:`aspect-[9/16] max-h-[70vh] w-full bg-ink`,onLoadedData:()=>{F(!0),I(!1)},onError:()=>I(!0)},`yt-${Z}`):q?(0,z.jsx)(`video`,{src:q,controls:!0,playsInline:!0,className:`aspect-video w-full bg-ink`,onLoadedData:()=>F(!0)}):(0,z.jsx)(`div`,{className:`flex aspect-[9/16] max-h-80 items-end justify-center pb-4`,children:(0,z.jsx)(`p`,{className:`text-xs font-semibold tracking-widest text-muted uppercase`,children:`No preview yet`})})}),(0,z.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`en`,onClick:()=>void $(`en`),className:`min-h-12 rounded-xl text-sm font-semibold ${j===`en`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`English master`}),(0,z.jsx)(`button`,{type:`button`,"aria-pressed":j===`hi`,onClick:()=>void $(`hi`),className:`min-h-12 rounded-xl text-sm font-semibold ${j===`hi`?`bg-seal text-paper`:`bg-panel text-paper`}`,children:`Hindi master`})]}),(0,z.jsx)(`button`,{type:`button`,onClick:ir,disabled:!!c||!b.trim(),className:`min-h-12 w-full rounded-2xl bg-panel text-sm font-semibold text-paper disabled:opacity-50`,children:`Load a short preview if the worker stream will not play`}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`yt-client`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Google OAuth client id`}),(0,z.jsx)(`input`,{id:`yt-client`,value:vn,onChange:e=>yn(e.target.value),autoComplete:`off`,spellCheck:!1,placeholder:`….apps.googleusercontent.com`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsxs)(`div`,{className:`grid grid-cols-2 gap-2 text-sm`,children:[(0,z.jsxs)(`p`,{className:`rounded-xl px-3 py-3 ${W.en.token?`badge-ok`:`bg-panel text-paper`}`,children:[`English channel `,W.en.channel||W.en.email||(W.en.token?`connected`:`not connected`)]}),(0,z.jsxs)(`p`,{className:`rounded-xl px-3 py-3 ${W.hi.token?`badge-ok`:`bg-panel text-paper`}`,children:[`Hindi channel `,W.hi.channel||W.hi.email||(W.hi.token?`connected`:`not connected`)]})]}),(0,z.jsx)(`button`,{type:`button`,onClick:ar,disabled:!!c,className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:j===`hi`?`Connect Hindi channel`:`Connect English channel`}),W[j].token||bn?(0,z.jsxs)(`p`,{className:`badge-ok rounded-xl px-3 py-2 text-sm font-semibold`,children:[(j===`hi`?W.hi.email:W.en.email)||Sn||`Account connected`,(j===`hi`?W.hi.channel:W.en.channel)||wn?` · ${(j===`hi`?W.hi.channel:W.en.channel)||wn}`:``]}):null,(0,z.jsxs)(`label`,{className:`block`,htmlFor:`yt-title`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Title`}),(0,z.jsx)(`input`,{id:`yt-title`,value:n.seo.title,maxLength:100,onChange:e=>r(t=>({...t,seo:{...t.seo,title:e.target.value}})),className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`yt-description`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Description`}),(0,z.jsx)(`textarea`,{id:`yt-description`,value:n.seo.description,maxLength:5e3,onChange:e=>r(t=>({...t,seo:{...t.seo,description:e.target.value}})),className:`field mt-2 min-h-32 w-full rounded-xl px-3 py-3 text-base outline-none`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`yt-tags`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Tags`}),(0,z.jsx)(`input`,{id:`yt-tags`,value:kn,onChange:e=>An(e.target.value),onBlur:()=>r(e=>({...e,seo:{...e.seo,tags:Yt(kn)}})),className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`yt-hash`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Hashtags`}),(0,z.jsx)(`input`,{id:`yt-hash`,value:n.seo.hashtags||``,onChange:e=>r(t=>({...t,seo:{...t.seo,hashtags:e.target.value}})),className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none`})]}),(0,z.jsx)(`div`,{className:`grid grid-cols-3 gap-2`,children:[`private`,`unlisted`,`public`].map(e=>(0,z.jsx)(`button`,{type:`button`,"aria-pressed":bt(n.seo.privacy)===e,onClick:()=>r(t=>({...t,seo:{...t.seo,privacy:e}})),className:`min-h-11 rounded-xl px-2 text-sm font-semibold capitalize ${bt(n.seo.privacy)===e?`bg-seal text-paper`:`bg-panel text-paper`}`,children:e},e))}),(0,z.jsxs)(`button`,{type:`button`,onClick:or,disabled:!!c||!(W[j].token||bn)||!xt&&!q,className:`min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:[`Upload to the `,j===`hi`?`Hindi`:`English`,` channel`]}),Dn?(0,z.jsx)(`a`,{href:Dn,target:`_blank`,rel:`noreferrer`,className:`block text-sm font-semibold text-cinnabar`,children:Dn}):null]}):null]}),!v&&e!==`chat`?(0,z.jsxs)(`button`,{type:`button`,onClick:()=>{y(!1),t(`chat`)},className:`fixed right-4 bottom-20 z-30 flex min-h-12 items-center gap-2 rounded-full bg-seal px-4 text-sm font-semibold text-paper`,children:[(0,z.jsx)(ne,{className:`size-4`,"aria-hidden":!0}),`Chat`]}):null,(0,z.jsx)(`nav`,{className:`dock-safe fixed inset-x-0 bottom-0 z-20 border-t border-line bg-ink/95 backdrop-blur`,"aria-label":`Studio`,children:(0,z.jsx)(`div`,{className:`mx-auto grid max-w-lg grid-cols-6`,children:ur.map(n=>{let r=n.icon,i=e===n.id;return(0,z.jsxs)(`button`,{type:`button`,onClick:()=>{y(!1),t(n.id)},"aria-current":i?`page`:void 0,className:`flex min-h-14 min-w-0 flex-col items-center justify-center gap-1 px-0.5 text-[10px] leading-none whitespace-nowrap ${i?`text-cinnabar`:`text-muted`}`,children:[(0,z.jsx)(r,{className:`size-5`,"aria-hidden":!0}),n.label]},n.id)})})})]})}function en({colabUrl:e,kaggleUrl:t,onColab:n,onKaggle:r,onTest:i,busy:a,badge:o}){let s=Wt(e),c=Wt(t);return(0,z.jsxs)(`div`,{className:`space-y-3 rounded-2xl bg-ink-2 p-4`,children:[(0,z.jsx)(`h3`,{className:`text-lg text-paper`,children:`Colab and Kaggle`}),(0,z.jsx)(`p`,{className:`text-xs text-muted`,children:`Notebook links are not saved. Test hits the live worker health check.`}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`colab-url`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Colab URL`}),(0,z.jsx)(`input`,{id:`colab-url`,value:e,onChange:e=>n(e.target.value),placeholder:`https://colab.research.google.com/…`,inputMode:`url`,autoComplete:`off`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`})]}),(0,z.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,z.jsx)(`a`,{href:s??void 0,target:`_blank`,rel:`noreferrer`,"aria-disabled":!s,className:`flex min-h-11 items-center justify-center rounded-xl bg-panel text-sm font-semibold text-paper ${s?``:`pointer-events-none opacity-50`}`,children:`Open Colab`}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>i(e),disabled:a,className:`min-h-11 rounded-xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Test & Connect`})]}),(0,z.jsxs)(`label`,{className:`block`,htmlFor:`kaggle-url`,children:[(0,z.jsx)(`span`,{className:`text-sm font-medium text-paper`,children:`Kaggle URL`}),(0,z.jsx)(`input`,{id:`kaggle-url`,value:t,onChange:e=>r(e.target.value),placeholder:`https://www.kaggle.com/code/…`,inputMode:`url`,autoComplete:`off`,className:`field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted`})]}),(0,z.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,z.jsx)(`a`,{href:c??void 0,target:`_blank`,rel:`noreferrer`,"aria-disabled":!c,className:`flex min-h-11 items-center justify-center rounded-xl bg-panel text-sm font-semibold text-paper ${c?``:`pointer-events-none opacity-50`}`,children:`Open Kaggle`}),(0,z.jsx)(`button`,{type:`button`,onClick:()=>i(t),disabled:a,className:`min-h-11 rounded-xl bg-seal text-sm font-semibold text-paper disabled:opacity-50`,children:`Test & Connect`})]}),o?(0,z.jsx)(`p`,{className:`badge-ok rounded-xl px-3 py-2 text-sm font-semibold`,children:o}):null]})}function tn(){return(0,z.jsx)(V,{})}export{tn as component};
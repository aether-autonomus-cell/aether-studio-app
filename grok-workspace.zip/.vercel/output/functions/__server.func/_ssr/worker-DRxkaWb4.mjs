import { a as object, i as number, n as array, o as string, r as literal, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/worker-DRxkaWb4.js
/** Cloud + local routing. Keys are passed per call and never stored here. */
var CLOUD_PROVIDERS = [
	"zai",
	"openrouter",
	"github",
	"gemini",
	"groq",
	"openai",
	"deepseek",
	"custom"
];
var PROVIDER_PRESETS = {
	zai: {
		label: "GLM-5.2 / GLM-4-Flash Free (Z.ai)",
		hint: "https://open.bigmodel.cn/api/paas/v4",
		models: [
			{
				id: "glm-5.2",
				label: "glm-5.2"
			},
			{
				id: "glm-5-turbo",
				label: "glm-5-turbo"
			},
			{
				id: "glm-4-flash",
				label: "glm-4-flash (free)"
			}
		],
		allowCustomModel: false
	},
	openrouter: {
		label: "OpenRouter Free Tier",
		hint: "https://openrouter.ai/api/v1",
		models: [
			{
				id: "z-ai/glm-5.2:free",
				label: "z-ai/glm-5.2:free"
			},
			{
				id: "deepseek/deepseek-chat:free",
				label: "deepseek/deepseek-chat:free"
			},
			{
				id: "qwen/qwen-2.5-7b-instruct:free",
				label: "qwen/qwen-2.5-7b-instruct:free"
			}
		],
		allowCustomModel: true
	},
	github: {
		label: "GitHub Models Free API",
		hint: "https://models.inference.ai.azure.com",
		models: [
			{
				id: "gpt-4o",
				label: "gpt-4o"
			},
			{
				id: "gpt-4o-mini",
				label: "gpt-4o-mini"
			},
			{
				id: "Meta-Llama-3.1-405B-Instruct",
				label: "Llama 3.1 405B"
			},
			{
				id: "Mistral-large-2411",
				label: "Mistral Large"
			}
		],
		allowCustomModel: true
	},
	gemini: {
		label: "Google Gemini Free",
		hint: "gemini-2.5-flash",
		models: [{
			id: "gemini-2.5-flash",
			label: "gemini-2.5-flash"
		}],
		allowCustomModel: false
	},
	groq: {
		label: "Groq",
		hint: "llama-3.3-70b-versatile",
		models: [{
			id: "llama-3.3-70b-versatile",
			label: "llama-3.3-70b-versatile"
		}],
		allowCustomModel: true
	},
	openai: {
		label: "OpenAI",
		hint: "https://api.openai.com/v1",
		models: [{
			id: "gpt-4o-mini",
			label: "gpt-4o-mini"
		}, {
			id: "gpt-4o",
			label: "gpt-4o"
		}],
		allowCustomModel: true
	},
	deepseek: {
		label: "DeepSeek",
		hint: "https://api.deepseek.com",
		models: [{
			id: "deepseek-chat",
			label: "deepseek-chat"
		}, {
			id: "deepseek-reasoner",
			label: "deepseek-reasoner"
		}],
		allowCustomModel: false
	},
	custom: {
		label: "Custom OpenAI-compatible URL",
		hint: "Any /v1 base URL",
		models: [],
		allowCustomModel: true
	}
};
var LOCAL_MODES = [
	{
		id: "gguf",
		label: "GLM-5.2 4-Bit GGUF / Distill (Ollama / llama.cpp)"
	},
	{
		id: "airllm",
		label: "GLM-5.2 AirLLM layer-wise (low VRAM)"
	},
	{
		id: "fast",
		label: "Fast local fallback (GLM-4-9B / Qwen2.5-14B)"
	}
];
var EXPLAIN_VOICES = {
	hi: "hi-IN-MadhurNeural",
	en: "en-US-ChristopherNeural"
};
var BASES = {
	zai: "https://open.bigmodel.cn/api/paas/v4/chat/completions",
	openrouter: "https://openrouter.ai/api/v1/chat/completions",
	github: "https://models.inference.ai.azure.com/chat/completions",
	groq: "https://api.groq.com/openai/v1/chat/completions",
	openai: "https://api.openai.com/v1/chat/completions",
	deepseek: "https://api.deepseek.com/chat/completions"
};
function defaultModel(provider) {
	return PROVIDER_PRESETS[provider].models[0]?.id ?? "";
}
function isCloudProvider(value) {
	return CLOUD_PROVIDERS.includes(value);
}
function isLocalMode(value) {
	return value === "gguf" || value === "airllm" || value === "fast";
}
function clipKey(value, max) {
	const key = value.replace(/\s+/g, " ").trim().replace(/^["']|["']$/g, "");
	if (key.length > max) throw new Error("That key is too long.");
	return key;
}
function dutyOf(value) {
	return value === "worker" || value === "key" ? value : "split";
}
function readSession(input) {
	const row = input && typeof input === "object" ? input : {};
	const rawProvider = typeof row.provider === "string" ? row.provider : "";
	let provider = "zai";
	if (isCloudProvider(rawProvider)) provider = rawProvider;
	else if (rawProvider === "worker") provider = "zai";
	else if (rawProvider === "gemini") provider = "gemini";
	const model = typeof row.model === "string" ? row.model.trim().slice(0, 160) : "";
	const legacyGemini = typeof row.geminiKey === "string" ? row.geminiKey : "";
	const apiKey = clipKey(typeof row.apiKey === "string" ? row.apiKey : legacyGemini, 800);
	const customBaseUrl = typeof row.customBaseUrl === "string" ? row.customBaseUrl.trim().slice(0, 300) : "";
	const workerUrl = typeof row.workerUrl === "string" ? row.workerUrl : "";
	const workerToken = typeof row.workerToken === "string" ? row.workerToken : "";
	if (workerToken.length > 500) throw new Error("That token is too long.");
	const localModel = typeof row.localModel === "string" && isLocalMode(row.localModel) ? row.localModel : "gguf";
	const language = row.language === "hi" ? "hi" : "en";
	const duty = dutyOf(row.duty);
	if (rawProvider === "worker") return {
		provider,
		model: model || defaultModel(provider),
		apiKey: "",
		customBaseUrl,
		workerUrl,
		workerToken,
		localModel,
		language,
		duty
	};
	return {
		provider,
		model: model || defaultModel(provider),
		apiKey,
		customBaseUrl,
		workerUrl,
		workerToken,
		localModel,
		language,
		duty
	};
}
/** Null means there is no cloud key, so the router must use the local worker. */
function cloudRequest(session) {
	const apiKey = session.apiKey.trim();
	if (!apiKey) return null;
	const model = session.model.trim() || defaultModel(session.provider);
	if (session.provider === "gemini") return {
		kind: "gemini",
		apiKey,
		model: model || "gemini-2.5-flash",
		url: `https://generativelanguage.googleapis.com/v1beta/models/${model || "gemini-2.5-flash"}:generateContent`
	};
	let url = "";
	if (session.provider === "custom") {
		const base = session.customBaseUrl.trim().replace(/\/+$/, "");
		if (!/^https:\/\//i.test(base)) return null;
		url = /\/chat\/completions$/i.test(base) ? base : `${base}/chat/completions`;
	} else url = BASES[session.provider];
	if (!model && session.provider === "custom") return null;
	const headers = {
		"Content-Type": "application/json",
		Authorization: `Bearer ${apiKey}`
	};
	if (session.provider === "openrouter") {
		headers["HTTP-Referer"] = "https://aether.studio";
		headers["X-Title"] = "Aether Studio";
	}
	return {
		kind: "openai",
		url,
		model: model || "gpt-4o-mini",
		headers
	};
}
/** Any cloud failure shifts to the connected Colab/Kaggle model. A clean 2xx does not. */
function shouldFailover(status, body) {
	if (status === 0 || status === 408 || status === 429 || status >= 400) return true;
	return /quota|rate limit|resource exhausted|insufficient|billing|timeout|too many requests/i.test(body);
}
/** Default when both are connected: the key writes. The user can flip this in Settings. */
function textVia(duty, hasKey, hasWorker) {
	if (duty === "worker") {
		if (hasWorker) return "worker";
		if (hasKey) return "key";
		return "none";
	}
	if (duty === "key") {
		if (hasKey) return "key";
		if (hasWorker) return "worker";
		return "none";
	}
	if (hasKey) return "key";
	if (hasWorker) return "worker";
	return "none";
}
/** Images, voice, and ffmpeg stay on the worker unless the user forces key-only. */
function imageVia(duty, hasWorker) {
	if (hasWorker && duty !== "key") return "worker";
	return "fallback";
}
function textFromModel(json) {
	if (typeof json === "string") return json;
	if (!json || typeof json !== "object") return "";
	const row = json;
	if (typeof row.text === "string") return row.text;
	if (typeof row.content === "string") return row.content;
	if (typeof row.output === "string") return row.output;
	const choices = row.choices;
	if (Array.isArray(choices) && choices[0] && typeof choices[0] === "object") {
		const choice = choices[0];
		const message = choice.message;
		if (message && typeof message === "object") {
			const content = message.content;
			if (typeof content === "string") return content;
		}
		if (typeof choice.text === "string") return choice.text;
	}
	return "";
}
function directorSystem(language) {
	return [
		"You direct a professional manhua explanation video. Return only JSON.",
		`Every title, hook, logline, caption, dialogue, narration, soul, vessel, and seo string must be ${language === "hi" ? "Hindi, Devanagari, desi manhua-explanation style, third person. Narrator voice hi-IN-MadhurNeural." : "English, dramatic manhua-recap style, third person. Narrator voice en-US-ChristopherNeural."}`,
		"If the source is Chinese or any other language, translate it completely into that language. Do not leave Chinese characters in the JSON values.",
		"Keys: title, hook, logline, timeline (string[]), characters ([{id,name,soul,vessel,look,face,hair,age,scars,eyes,body,outfit}]), scenes ([{caption,dialogue,speaker,sfx,state}]), narration, seo ({title,description,tags,hashtags}).",
		"hook is a one or two sentence YouTube cold open.",
		"narration is the full voiceover: hook first, then the chapter in order, third person, no speaker labels, no Chinese.",
		"soul is identity. vessel is the body they wear in this chapter, with visual detail.",
		"Put face, hair, age, scars, eyes, body, and outfit on each character when the source says them. Outfit changes belong on the character, with the chapter number in the look text.",
		"Unlimited scenes, one per beat. Never cap at 4 or 6. Do not drop the ending.",
		"Do not write imagePrompt in this pass. Picture prompts are written later, one beat at a time, in English.",
		"A language change must never invent a new look. If a CHARACTER LOCK is included, keep that look. Do not rewrite it.",
		"sfx is one short word or empty. No markdown."
	].join(" ");
}
var ID_RE = /^[A-Za-z0-9._-]{1,80}$/;
function assertJobId(id) {
	const clean = id.trim();
	if (!ID_RE.test(clean)) throw new Error("That job id is not valid.");
	return clean;
}
function jobResourcePath(id, leaf) {
	const safe = assertJobId(id);
	return leaf ? `/api/v1/jobs/${safe}/mp4` : `/api/v1/jobs/${safe}`;
}
function asId(value) {
	if (typeof value === "number" && Number.isFinite(value)) {
		const clean = String(Math.trunc(value));
		return ID_RE.test(clean) ? clean : null;
	}
	if (typeof value !== "string") return null;
	const clean = value.trim();
	return ID_RE.test(clean) ? clean : null;
}
function readJobId(body) {
	try {
		const json = JSON.parse(body);
		const nested = json.job && typeof json.job === "object" ? json.job : null;
		return asId(json.id) ?? asId(json.job_id) ?? asId(json.jobId) ?? (nested ? asId(nested.id) ?? asId(nested.job_id) : null);
	} catch {
		return null;
	}
}
function clampProgress(value) {
	if (!Number.isFinite(value)) return 0;
	const scaled = value >= 0 && value <= 1 ? value * 100 : value;
	return Math.max(0, Math.min(100, Math.round(scaled)));
}
function phaseOf(raw) {
	const status = raw.toLowerCase();
	if (/queue|pending|accept|submit|wait/.test(status)) return "queued";
	if (/run|process|work|progress|start|paint|render|encod/.test(status)) return "running";
	if (/done|complete|success|ready|finish/.test(status)) return "done";
	if (/error|fail|cancel/.test(status)) return "error";
	return "unknown";
}
function progressOf(row) {
	const progress = row.progress;
	if (typeof progress === "number") return {
		progress: clampProgress(progress),
		label: ""
	};
	if (typeof progress === "string") {
		const n = Number(progress.replace("%", "").trim());
		if (!Number.isNaN(n)) return {
			progress: clampProgress(n),
			label: ""
		};
	}
	if (progress && typeof progress === "object") {
		const box = progress;
		const current = Number(box.current ?? box.done ?? box.completed ?? 0);
		const total = Number(box.total ?? 0);
		const label = typeof box.label === "string" ? box.label : typeof box.step === "string" ? box.step : "";
		if (total > 0 && Number.isFinite(current)) return {
			progress: clampProgress(current / total),
			label
		};
		if (typeof box.percent === "number") return {
			progress: clampProgress(box.percent),
			label
		};
	}
	if (typeof row.percent === "number") return {
		progress: clampProgress(row.percent),
		label: ""
	};
	return {
		progress: 0,
		label: ""
	};
}
function mp4Of(row) {
	const direct = [
		row.mp4_url,
		row.mp4Url,
		row.download_url,
		row.downloadUrl,
		row.video_url,
		row.videoUrl,
		row.mp4
	];
	for (const value of direct) if (typeof value === "string" && value.trim()) return value.trim();
	const output = row.output ?? row.result;
	if (typeof output === "string" && /\.mp4($|\?)/i.test(output)) return output;
	if (output && typeof output === "object") {
		const box = output;
		const nested = box.mp4_url ?? box.mp4Url ?? box.url ?? box.download_url;
		if (typeof nested === "string" && nested.trim()) return nested.trim();
	}
	return null;
}
function timingOf(value) {
	if (!value || typeof value !== "object") return {};
	const out = {};
	for (const [key, raw] of Object.entries(value)) {
		if (!ID_RE.test(key)) continue;
		const n = typeof raw === "number" ? raw : Number(raw);
		if (Number.isFinite(n) && n > 0 && n <= 180) out[key] = Math.round(n * 1e3) / 1e3;
	}
	return out;
}
function voicesOf(value) {
	if (!value || typeof value !== "object") return {};
	const out = {};
	for (const [key, raw] of Object.entries(value)) {
		if (!ID_RE.test(key) || typeof raw !== "string") continue;
		const path = raw.trim();
		if (path.startsWith("/api/v1/voices/") && path.length < 180) out[key] = path;
	}
	return out;
}
function parseJobStatus(json, fallbackId) {
	const root = json && typeof json === "object" ? json : {};
	const row = root.job && typeof root.job === "object" ? root.job : root;
	const id = asId(row.id) ?? asId(row.job_id) ?? asId(row.jobId) ?? assertJobId(fallbackId);
	const status = phaseOf(typeof row.status === "string" ? row.status : typeof row.state === "string" ? row.state : "");
	const measured = progressOf(row);
	const label = measured.label || (typeof row.label === "string" ? row.label : "") || (typeof row.step === "string" ? row.step : "") || (typeof row.stage === "string" ? row.stage : "");
	const message = typeof row.message === "string" ? row.message : "";
	const errorText = typeof row.error === "string" ? row.error : status === "error" ? message : "";
	return {
		id,
		status,
		progress: status === "done" ? Math.max(measured.progress, 100) : measured.progress,
		label: status === "error" ? "" : label || (status === "running" ? message : ""),
		error: errorText,
		mp4Url: mp4Of(row),
		timing: timingOf(row.timing),
		voices: voicesOf(row.voices)
	};
}
var DEFAULT_NEGATIVE = "text, letters, logos, watermark, speech bubbles, signature, extra limbs, deformed hands";
var VOICE_BY_LANGUAGE = {
	hi: "hi-IN-MadhurNeural",
	en: "en-US-ChristopherNeural"
};
var languageSchema = _enum(["hi", "en"]);
var tileSchema = object({
	prompt: string().min(1),
	negative: string(),
	characters: array(string()),
	vessel_id: string()
});
var bubbleSchema = object({
	speaker: string(),
	text: string()
});
var packetSceneSchema = object({
	id: string().min(1),
	caption: string(),
	sfx: string(),
	state: string(),
	bubble: bubbleSchema,
	image_url: string().max(12e5).optional(),
	/** Language-neutral picture hold from the first assemble. A longer line may extend it. */
	hold_sec: number().positive().max(180).optional(),
	/** Approved face file. The worker may use it. A language switch does not replace it. */
	reference: string().max(5e5).optional(),
	tiles: array(tileSchema).min(1)
});
var packetCharacterSchema = object({
	id: string().min(1),
	name: string().min(1),
	soul: string(),
	vessel: string(),
	vessel_id: string()
});
var chapterSchema = object({
	index: number().int().positive(),
	title: string().min(1),
	source_url: string().nullable(),
	narration: string(),
	characters: array(packetCharacterSchema),
	scenes: array(packetSceneSchema).min(1)
});
var seoSchema = object({
	title: string(),
	description: string(),
	tags: array(string())
});
var jobPacketV2Schema = object({
	version: literal(2),
	language: languageSchema,
	voice: string().min(1),
	title: string().min(1),
	aspect: _enum(["16:9", "9:16"]).default("16:9"),
	local_model: _enum([
		"gguf",
		"airllm",
		"fast"
	]).default("gguf"),
	hook: string().default(""),
	/** assemble draws missing art. revoice keeps every picture and only replaces audio and captions. */
	pass: _enum(["assemble", "revoice"]).default("assemble"),
	chapters: array(chapterSchema).min(1),
	seo: seoSchema,
	/** Hugging Face repo for the Colab checkpoint. Empty keeps the cell default. */
	image_repo: string().max(200).optional(),
	note: string()
});
function detectLanguage(text) {
	return /[\u0900-\u097F]/.test(text) ? "hi" : "en";
}
function voiceFor(language, override) {
	return override?.trim() || VOICE_BY_LANGUAGE[language];
}
function workerEndpoint(raw, path) {
	if (!path.startsWith("/api/v1/") || path.includes("..") || path.includes("//")) throw new Error("That worker path is not valid.");
	const trimmed = raw.trim();
	if (!trimmed) throw new Error("Add the worker URL first.");
	let origin;
	try {
		origin = new URL(/^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`);
	} catch {
		throw new Error("That worker URL is not valid.");
	}
	if (origin.protocol !== "http:" && origin.protocol !== "https:") throw new Error("Only http and https workers.");
	let prefix = origin.pathname.replace(/\/+$/, "");
	if (prefix.endsWith("/api/v1/health")) prefix = prefix.slice(0, -14);
	else if (prefix.endsWith("/api/v1/jobs")) prefix = prefix.slice(0, -12);
	else if (prefix.endsWith("/api/v1")) prefix = prefix.slice(0, -7);
	const next = new URL(origin.origin);
	next.pathname = `${prefix}${path}`.replace(/\/{2,}/g, "/");
	return next;
}
//#endregion
export { textFromModel as _, assertJobId as a, workerEndpoint as b, detectLanguage as c, jobPacketV2Schema as d, jobResourcePath as f, shouldFailover as g, readSession as h, PROVIDER_PRESETS as i, directorSystem as l, readJobId as m, EXPLAIN_VOICES as n, cloudRequest as o, parseJobStatus as p, LOCAL_MODES as r, defaultModel as s, DEFAULT_NEGATIVE as t, imageVia as u, textVia as v, voiceFor as y };

import { i as __toESM } from "../_runtime.mjs";
import { _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, q as require_react, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, o as string, r as literal, s as union } from "../_libs/zod.mjs";
import { a as assertJobId, b as workerEndpoint, d as jobPacketV2Schema, f as jobResourcePath, h as readSession, p as parseJobStatus } from "./worker-DRxkaWb4.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-C606B4Ww.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-C15HXGqg.css";
var APP_NAME = "Aether Studio";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#14110f"
			},
			{
				name: "description",
				content: "Manhua explanation studio. Translate a chapter, render the film, upload it to YouTube."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "manifest",
				href: "/manifest.webmanifest"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,560;9..144,660&family=Outfit:wght@400;500;600&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-BGda5EzH.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var directChapter = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const text = typeof row?.text === "string" ? row.text.trim() : "";
	if (text.length < 40) throw new Error("Paste at least a short chapter.");
	if (text.length > 9e3) throw new Error("That chunk is too long. The studio splits a long chapter before asking.");
	return {
		text,
		lock: typeof row.lock === "string" ? row.lock.trim().slice(0, 1800) : "",
		session: readSession(input)
	};
}).handler(createSsrRpc("563099b809b2a51691b9f6a5d6c33f7e68ad08e1f397f41329e1d93a5d96f2ed"));
var writeBeatPrompt = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const caption = typeof row.caption === "string" ? row.caption.slice(0, 400) : "";
	const dialogue = typeof row.dialogue === "string" ? row.dialogue.slice(0, 400) : "";
	if (!caption.trim() && !dialogue.trim()) throw new Error("That beat has no line.");
	const chapter = typeof row.chapter === "number" && Number.isFinite(row.chapter) ? Math.floor(row.chapter) : 0;
	return {
		caption,
		dialogue,
		speaker: typeof row.speaker === "string" ? row.speaker.slice(0, 40) : "",
		state: typeof row.state === "string" ? row.state.slice(0, 180) : "",
		chapter: chapter > 0 && chapter < 1e5 ? chapter : 0,
		lock: typeof row.lock === "string" ? row.lock.slice(0, 1800) : "",
		session: readSession(input)
	};
}).handler(createSsrRpc("fb35a5929aeb382cfa404066c94369172b0a468056c7ce98b53e69b645a0941b"));
function referenceParts(value) {
	if (typeof value !== "string") return {
		reference: "",
		referenceBase64: ""
	};
	const raw = value.trim();
	if (/^https:\/\//i.test(raw)) return {
		reference: raw.slice(0, 2e3),
		referenceBase64: ""
	};
	const match = raw.match(/^data:[^;,]+;base64,([a-z0-9+/=\s]+)$/i);
	if (!match?.[1]) return {
		reference: "",
		referenceBase64: ""
	};
	const data = match[1].replace(/\s/g, "");
	if (data.length < 80 || data.length > 9e5) return {
		reference: "",
		referenceBase64: ""
	};
	return {
		reference: "",
		referenceBase64: data
	};
}
var paintPanel = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const prompt = typeof row?.prompt === "string" ? row.prompt.trim() : "";
	if (prompt.length < 8) throw new Error("That panel has no picture note.");
	const repo = typeof row.repo === "string" ? row.repo.trim().slice(0, 200) : "";
	return {
		prompt: prompt.slice(0, 900),
		repo,
		...referenceParts(row.reference),
		session: readSession(input)
	};
}).handler(createSsrRpc("c2f0841c7549228172cf44a94d57bc6fe6617883157ac8877ca13b3cd14e776d"));
var speakLine = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const text = typeof row?.text === "string" ? row.text.trim() : "";
	if (text.length < 2) throw new Error("Nothing to read.");
	const voice = typeof row?.voice === "string" ? row.voice : "";
	const sceneId = typeof row.sceneId === "string" ? row.sceneId.replace(/[^A-Za-z0-9._-]/g, "").slice(0, 80) : "";
	return {
		text: text.slice(0, 12e3),
		voice,
		sceneId,
		force: row.force === true,
		session: readSession(input)
	};
}).handler(createSsrRpc("7797f3a0eac382d040e1aeb5a02dc9bdd2b747691bd8bcb4b611aca40449ed00"));
function blockedIp(ip) {
	const raw = ip.toLowerCase().replace(/^::ffff:/, "");
	if (raw === "::1" || raw === "0.0.0.0" || raw.startsWith("fe80:") || raw.startsWith("fc") || raw.startsWith("fd")) return true;
	const parts = raw.split(".").map((part) => Number(part));
	if (parts.length !== 4 || parts.some((part) => Number.isNaN(part))) return raw === "localhost";
	const [a, b] = parts;
	if (a === 10 || a === 127 || a === 0) return true;
	if (a === 169 && b === 254) return true;
	if (a === 192 && b === 168) return true;
	if (a === 172 && b >= 16 && b <= 31) return true;
	if (a === 100 && b >= 64 && b <= 127) return true;
	return false;
}
async function assertPublic(hostname) {
	const host = hostname.toLowerCase().replace(/\.+$/, "");
	if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal") || host === "metadata.google.internal" || blockedIp(host)) return "That address is private. It stays blocked.";
	const dns = await import("node:dns/promises");
	let records = [];
	try {
		records = await dns.lookup(host, {
			all: true,
			verbatim: true
		});
	} catch {
		return "That host did not resolve.";
	}
	if (!records.length || records.some((record) => blockedIp(record.address))) return "That address is private. It stays blocked.";
	return null;
}
function safeCookie(value) {
	if (typeof value !== "string") return "";
	const clean = value.replace(/[\r\n]/g, "").trim();
	if (!clean) return "";
	if (clean.length > 4e3) throw new Error("That cookie is too long.");
	if (!/^[\x20-\x7E]+$/.test(clean)) throw new Error("The cookie has characters this fetch will not send.");
	return clean;
}
var fetchSource = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const url = typeof row?.url === "string" ? row.url.trim() : "";
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		throw new Error("That link is not a URL.");
	}
	if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new Error("Only http and https links.");
	return {
		url: parsed.toString(),
		cookie: safeCookie(row.cookie)
	};
}).handler(createSsrRpc("d2a6b2a19797d69c5b0f8b3d8580fdfdf17003521da123e437d08bf40052abb6"));
function redact(raw, secret, max = 280) {
	return (secret ? raw.split(secret).join("[redacted]") : raw).slice(0, max);
}
var testWorker = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const target = workerEndpoint(typeof row?.url === "string" ? row.url : "", "/api/v1/health");
	return {
		href: target.toString(),
		hostname: target.hostname,
		token
	};
}).handler(createSsrRpc("43a434a06dbf29ff3543b713d534cb31f6aa0cdec6e5bd64d4f82ca5bfba06cf"));
var submitJob = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const target = workerEndpoint(typeof row?.url === "string" ? row.url : "", "/api/v1/jobs");
	const packet = jobPacketV2Schema.parse(row?.packet);
	return {
		href: target.toString(),
		hostname: target.hostname,
		token,
		packet
	};
}).handler(createSsrRpc("2b4c3398c432f7c57717b4b27f3354ccead6a03c2c78a584a8e48580a0f312be"));
async function workerGet(href, hostname, token) {
	const blocked = await assertPublic(hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(href, {
			method: "GET",
			redirect: "manual",
			signal: AbortSignal.timeout(2e4),
			headers: {
				Accept: "application/json, video/mp4, application/octet-stream",
				"X-Aether-Token": token
			}
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not answer."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected. Nothing was followed."
	};
	const hidden = redact(await res.text(), token, 1e5);
	if (!res.ok) return {
		ok: false,
		error: hidden.slice(0, 280) || `Worker returned ${res.status}.`
	};
	return {
		ok: true,
		status: res.status,
		body: hidden,
		contentType: res.headers.get("content-type") ?? ""
	};
}
var jobStatus = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const jobId = assertJobId(typeof row?.jobId === "string" ? row.jobId : "");
	const target = workerEndpoint(typeof row?.url === "string" ? row.url : "", jobResourcePath(jobId));
	return {
		href: target.toString(),
		hostname: target.hostname,
		token,
		jobId
	};
}).handler(createSsrRpc("ef33f39ce09d4830db33acbc9b501f8bb3ee230c73513250a73d48a2693754a6"));
function mp4Target(workerUrl, jobId, mp4Url) {
	const fallback = workerEndpoint(workerUrl, jobResourcePath(jobId, "mp4"));
	if (!mp4Url) return fallback;
	if (mp4Url.startsWith("/")) return new URL(mp4Url, fallback.origin);
	try {
		const parsed = new URL(mp4Url);
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return fallback;
		return parsed;
	} catch {
		return fallback;
	}
}
async function fetchWorkerMp4(input) {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) return {
		ok: false,
		error: "That token is too long."
	};
	let jobId = "";
	try {
		jobId = assertJobId(typeof row?.jobId === "string" ? row.jobId : "");
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "That job id is not valid."
		};
	}
	const workerUrl = typeof row?.url === "string" ? row.url : "";
	let statusUrl;
	try {
		statusUrl = workerEndpoint(workerUrl, jobResourcePath(jobId));
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "That worker URL is not valid."
		};
	}
	const status = await workerGet(statusUrl.toString(), statusUrl.hostname, token);
	let mp4Url = null;
	if (status.ok) try {
		mp4Url = parseJobStatus(JSON.parse(status.body), jobId).mp4Url;
	} catch {
		mp4Url = null;
	}
	let target;
	try {
		target = mp4Target(workerUrl, jobId, mp4Url);
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "The MP4 link is not valid."
		};
	}
	const blocked = await assertPublic(target.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(target, {
			method: "GET",
			redirect: "manual",
			signal: AbortSignal.timeout(6e4),
			headers: {
				Accept: "video/mp4, application/octet-stream",
				"X-Aether-Token": token
			}
		});
	} catch {
		return {
			ok: false,
			error: "The MP4 did not download."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected the MP4. Nothing was saved."
	};
	if (!res.ok) return {
		ok: false,
		error: redact(await res.text(), token) || `The MP4 request returned ${res.status}.`
	};
	const bytes = new Uint8Array(await res.arrayBuffer());
	if (bytes.byteLength < 64) return {
		ok: false,
		error: "The worker returned an empty video."
	};
	if (bytes.byteLength > 8e7) return {
		ok: false,
		error: "That MP4 is larger than 80 MB."
	};
	const contentType = res.headers.get("content-type") ?? "video/mp4";
	if (/json|text\/html|text\/plain/.test(contentType)) return {
		ok: false,
		error: redact(new TextDecoder().decode(bytes.slice(0, 280)), token) || "The worker did not return a video."
	};
	return {
		ok: true,
		bytes,
		contentType: contentType.split(";")[0] || "video/mp4"
	};
}
var verifyCloud = createServerFn({ method: "POST" }).validator((input) => readSession(input)).handler(createSsrRpc("09a063287da321971bf1e2e5ddeff28a007c98885c01cc5edf05f991690f4cd9"));
var uploadYoutube = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const accessToken = typeof row.accessToken === "string" ? row.accessToken.trim() : "";
	if (accessToken.length < 20 || accessToken.length > 8e3) throw new Error("Connect a YouTube channel first.");
	const jobId = assertJobId(typeof row.jobId === "string" ? row.jobId : "");
	const target = workerEndpoint(typeof row.url === "string" ? row.url : "", "/api/v1/youtube-upload");
	const token = typeof row.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const title = typeof row.title === "string" ? row.title.slice(0, 100) : "";
	const description = typeof row.description === "string" ? row.description.slice(0, 5e3) : "";
	const tags = Array.isArray(row.tags) ? row.tags.filter((tag) => typeof tag === "string").slice(0, 15) : [];
	const privacy = row.privacy === "public" || row.privacy === "unlisted" || row.privacy === "private" ? row.privacy : "private";
	const language = row.language === "hi" ? "hi" : "en";
	return {
		href: target.toString(),
		hostname: target.hostname,
		token,
		accessToken,
		jobId,
		title,
		description,
		tags,
		privacy,
		language
	};
}).handler(createSsrRpc("dda5ac0a6423b8a1b16e067a52b457002d6f430cdce082076b56f01019813444"));
async function fetchWorkerPreview(input) {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) return {
		ok: false,
		error: "That token is too long."
	};
	let target;
	try {
		target = workerEndpoint(typeof row?.url === "string" ? row.url : "", "/api/v1/preview.mp4");
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "That worker URL is not valid."
		};
	}
	const blocked = await assertPublic(target.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(target, {
			method: "GET",
			redirect: "manual",
			signal: AbortSignal.timeout(3e4),
			headers: {
				Accept: "video/mp4, application/octet-stream",
				"X-Aether-Token": token
			}
		});
	} catch {
		return {
			ok: false,
			error: "The 6 second preview did not load."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected the preview."
	};
	if (!res.ok) return {
		ok: false,
		error: "Render the video first. The 6 second preview is not ready."
	};
	const bytes = new Uint8Array(await res.arrayBuffer());
	if (bytes.byteLength < 64 || bytes.byteLength > 12e6) return {
		ok: false,
		error: "That preview was empty or too large."
	};
	return {
		ok: true,
		bytes,
		contentType: "video/mp4"
	};
}
var translateLines = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const target = row.target === "hi" ? "hi" : row.target === "en" ? "en" : "";
	if (!target) throw new Error("Pick English or Hindi.");
	if (!Array.isArray(row.lines) || row.lines.length === 0) throw new Error("No lines to translate.");
	if (row.lines.length > 40) throw new Error("Translate at most 40 lines at a time.");
	return {
		target,
		lines: row.lines.map((item) => {
			const line = item;
			const id = typeof line.id === "string" ? line.id.slice(0, 40) : "";
			if (!id) throw new Error("A line is missing its id.");
			return {
				id,
				caption: typeof line.caption === "string" ? line.caption.slice(0, 400) : "",
				dialogue: typeof line.dialogue === "string" ? line.dialogue.slice(0, 400) : ""
			};
		}),
		session: readSession({
			...input,
			language: target
		})
	};
}).handler(createSsrRpc("1f0cfaf2cfb7db3fc62b33bf8cc6df12890914679a47e6591994d357a4a7e591"));
var chatTurn = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const message = typeof row.message === "string" ? row.message.trim() : "";
	if (message.length < 1) throw new Error("Type a message.");
	if (message.length > 2e3) throw new Error("That message is too long.");
	return {
		message,
		context: typeof row.context === "string" ? row.context.slice(0, 4e3) : "",
		session: readSession(input)
	};
}).handler(createSsrRpc("df700042e2b5a64c50059fb5c12effaaa337b2d36bbd1fbda7c247f351791d52"));
var checkPanel = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const prompt = typeof row.prompt === "string" ? row.prompt.trim() : "";
	const imageUrl = typeof row.imageUrl === "string" ? row.imageUrl.trim() : "";
	if (prompt.length < 8 || !imageUrl) throw new Error("Nothing to check.");
	return {
		prompt: prompt.slice(0, 700),
		imageUrl: imageUrl.slice(0, 12e5),
		session: readSession(input)
	};
}).handler(createSsrRpc("0ac02964e89d85f31604cd870fdf5c0c5055a92cb471bdc2ab52b076f55ca0a1"));
var startWorkerFetch = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	if (!Array.isArray(row.urls) || row.urls.length === 0) throw new Error("No chapter links to send.");
	if (row.urls.length > 180) throw new Error("That range is too long for one worker fetch. Split it.");
	return {
		urls: row.urls.map((item) => {
			if (typeof item !== "string") throw new Error("A chapter link is not a URL.");
			let parsed;
			try {
				parsed = new URL(item.trim());
			} catch {
				throw new Error("A chapter link is not a URL.");
			}
			if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new Error("Only http and https links.");
			return parsed.toString();
		}),
		cookie: safeCookie(row.cookie),
		session: readSession(input)
	};
}).handler(createSsrRpc("7e57028f6fb2d7224fa93966b01dee72ba28d8b1c9a68bacb107f1c2e626dd10"));
var workerFetchStatus = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const jobId = typeof row.jobId === "string" ? row.jobId.trim() : "";
	if (!/^[A-Za-z0-9]{6,32}$/.test(jobId)) throw new Error("That fetch id is not valid.");
	return {
		jobId,
		session: readSession(input)
	};
}).handler(createSsrRpc("b337bb6b6aae62e28d13fa7c64dcaab68f11dbb7970b86d5149f9a8545412300"));
var readPanelText = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	if (!Array.isArray(row.images) || row.images.length === 0) throw new Error("No panels to read.");
	if (row.images.length > 8) throw new Error("Read at most 8 panels at a time.");
	return {
		images: row.images.map((item) => {
			const box = item;
			const id = typeof box.id === "string" ? box.id.slice(0, 40) : "";
			const url = typeof box.url === "string" ? box.url.trim() : "";
			if (!id || !/^https?:\/\//i.test(url)) throw new Error("A panel image is missing its link.");
			return {
				id,
				url: url.slice(0, 500)
			};
		}),
		session: readSession(input)
	};
}).handler(createSsrRpc("8ebf86c5fb42b3069035a5d461771576917679cb3d33929db611b8c62527eb7b"));
var Route = createFileRoute("/api/studio/mp4")({ server: { handlers: { POST: async ({ request }) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({ error: "Missing download request." }, { status: 400 });
	}
	const kind = body && typeof body === "object" && body.kind === "preview" ? "preview" : "full";
	const result = kind === "preview" ? await fetchWorkerPreview(body) : await fetchWorkerMp4(body);
	if (!result.ok) return Response.json({ error: result.error }, { status: 400 });
	const payload = new Uint8Array(result.bytes.byteLength);
	payload.set(result.bytes);
	return new Response(payload, { headers: {
		"Content-Type": result.contentType || "video/mp4",
		"Content-Disposition": kind === "preview" ? "inline" : "attachment; filename=\"aether.mp4\"",
		"Cache-Control": "no-store"
	} });
} } } });
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	ApiStudioMp4Route: Route.update({
		id: "/api/studio/mp4",
		path: "/api/studio/mp4",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { writeBeatPrompt as _, fetchSource as a, readPanelText as c, submitJob as d, testWorker as f, workerFetchStatus as g, verifyCloud as h, directChapter as i, speakLine as l, uploadYoutube as m, chatTurn as n, jobStatus as o, translateLines as p, checkPanel as r, paintPanel as s, router_exports as t, startWorkerFetch as u };

import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { _ as textFromModel, a as assertJobId, b as workerEndpoint, d as jobPacketV2Schema, f as jobResourcePath, g as shouldFailover, h as readSession, l as directorSystem, m as readJobId, o as cloudRequest, p as parseJobStatus, u as imageVia, v as textVia } from "./worker-DRxkaWb4.mjs";
import { a as containsHan, c as fetchWtrChapter, g as sanitizeNovelText, h as parseWtrChapterUrl, i as composeLook, m as parseStudioAction, o as extractPanels, u as htmlToText } from "./bible-BCfVgxxi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-C8Pf0t-9.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/** Fixed paint/voice model ids. Chat models are chosen in Settings and are not stored. */
var studioConfig = {
	/** xAI / Grok endpoints are not called. This flag stays off. */
	xaiEnabled: false,
	geminiModel: "gemini-2.5-flash",
	geminiImageModel: "gemini-2.5-flash-image",
	/** Male prebuilt voice. Used only when the phone asks Gemini to read. */
	geminiVoice: "Charon",
	geminiTtsModel: "gemini-2.5-flash-preview-tts"
};
function clip(text, max) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length <= max) return clean;
	return `${clean.slice(0, max - 1).trimEnd()}…`;
}
async function geminiText(apiKey, system, user, model = studioConfig.geminiModel) {
	let res;
	try {
		res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": apiKey
			},
			signal: AbortSignal.timeout(45e3),
			body: JSON.stringify({
				systemInstruction: { parts: [{ text: system }] },
				contents: [{
					role: "user",
					parts: [{ text: user }]
				}],
				generationConfig: {
					temperature: .4,
					responseMimeType: "application/json"
				}
			})
		});
	} catch {
		return {
			ok: false,
			error: "Gemini did not answer.",
			status: 0
		};
	}
	const raw = await res.text();
	if (!res.ok) return {
		ok: false,
		error: `Gemini could not finish that call (${res.status}).`,
		status: res.status
	};
	let body;
	try {
		body = JSON.parse(raw);
	} catch {
		return {
			ok: false,
			error: "Gemini returned a plan this studio could not read.",
			status: res.status
		};
	}
	const text = body.candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("") ?? "";
	if (!text.trim()) return {
		ok: false,
		error: "Gemini returned an empty plan.",
		status: res.status
	};
	return {
		ok: true,
		text
	};
}
async function openaiText(call, system, user, jsonMode) {
	let res;
	try {
		res = await fetch(call.url, {
			method: "POST",
			headers: call.headers,
			signal: AbortSignal.timeout(45e3),
			body: JSON.stringify({
				model: call.model,
				temperature: .4,
				messages: [{
					role: "system",
					content: system
				}, {
					role: "user",
					content: user
				}],
				...jsonMode ? { response_format: { type: "json_object" } } : {}
			})
		});
	} catch {
		return {
			ok: false,
			error: "The cloud model did not answer.",
			status: 0
		};
	}
	const raw = await res.text();
	const hidden = raw.split(call.headers.Authorization ?? "").join("[redacted]");
	if (!res.ok) return {
		ok: false,
		error: hidden.slice(0, 280) || `Cloud model returned ${res.status}.`,
		status: res.status
	};
	try {
		const text = textFromModel(JSON.parse(raw));
		if (!text.trim()) return {
			ok: false,
			error: "The cloud model returned an empty plan.",
			status: res.status
		};
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "The cloud model returned a plan this studio could not read.",
			status: res.status
		};
	}
}
async function callCloud(session, system, user, jsonMode) {
	const call = cloudRequest(session);
	if (!call) return {
		ok: false,
		error: "No cloud API key in this tab.",
		status: 0
	};
	if (call.kind === "gemini") return geminiText(call.apiKey, system, user, call.model);
	const first = await openaiText(call, system, user, jsonMode);
	if (first.ok || !jsonMode || first.status === 0) return first;
	return openaiText(call, system, user, false);
}
async function callLocal(session, system, user) {
	if (!session.workerUrl.trim()) return {
		ok: false,
		error: "No Colab or Kaggle worker is connected."
	};
	const result = await workerPost("/api/v1/llm", session.workerUrl, session.workerToken, {
		system,
		prompt: user,
		model_mode: session.localModel,
		language: session.language
	});
	if (!result.ok) return result;
	const text = textFromModel(result.json);
	if (!text.trim()) return {
		ok: false,
		error: "Local AI returned an empty script."
	};
	return {
		ok: true,
		text
	};
}
async function callActiveAI(session, system, user) {
	const hasKey = Boolean(session.apiKey.trim());
	const hasWorker = Boolean(session.workerUrl.trim());
	const via = textVia(session.duty, hasKey, hasWorker);
	if (via === "none") return {
		ok: false,
		error: "Add a cloud API key or connect the Colab/Kaggle worker. Nothing is saved on this phone."
	};
	if (via === "worker") {
		const local = await callLocal(session, system, user);
		if (local.ok) return {
			ok: true,
			text: local.text,
			via: "local"
		};
		return {
			ok: false,
			error: local.error
		};
	}
	const cloud = await callCloud(session, system, user, true);
	if (cloud.ok) return {
		ok: true,
		text: cloud.text,
		via: "cloud"
	};
	if (session.duty !== "key" && hasWorker && shouldFailover(cloud.status, cloud.error)) {
		const local = await callLocal(session, system, user);
		if (local.ok) return {
			ok: true,
			text: local.text,
			via: "local"
		};
		return {
			ok: false,
			error: local.error || cloud.error
		};
	}
	return {
		ok: false,
		error: cloud.error
	};
}
async function workerPost(path, url, token, payload) {
	let target;
	try {
		target = workerEndpoint(url, path);
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "That worker URL is not valid."
		};
	}
	const blocked = await assertPublic(target.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(target, {
			method: "POST",
			redirect: "manual",
			signal: AbortSignal.timeout(6e4),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
				"X-Aether-Token": token
			},
			body: JSON.stringify(payload)
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not answer."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected. Nothing was sent."
	};
	const raw = (await res.text()).split(token).join("[redacted]");
	if (!res.ok) return {
		ok: false,
		error: raw.slice(0, 280) || `Worker returned ${res.status}.`
	};
	try {
		return {
			ok: true,
			json: JSON.parse(raw)
		};
	} catch {
		return {
			ok: true,
			json: raw
		};
	}
}
async function workerJson(path, url, token) {
	let target;
	try {
		target = workerEndpoint(url, path);
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "That worker URL is not valid."
		};
	}
	const blocked = await assertPublic(target.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	if (token) target.searchParams.set("token", token);
	let res;
	try {
		res = await fetch(target, {
			redirect: "manual",
			signal: AbortSignal.timeout(6e4),
			headers: {
				Accept: "application/json",
				"X-Aether-Token": token
			}
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not answer."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected. Nothing was sent."
	};
	const raw = (await res.text()).split(token).join("[redacted]");
	if (!res.ok) return {
		ok: false,
		error: raw.slice(0, 280) || `Worker returned ${res.status}.`
	};
	try {
		return {
			ok: true,
			json: JSON.parse(raw)
		};
	} catch {
		return {
			ok: true,
			json: raw
		};
	}
}
var directChapter_createServerFn_handler = createServerRpc({
	id: "563099b809b2a51691b9f6a5d6c33f7e68ad08e1f397f41329e1d93a5d96f2ed",
	name: "directChapter",
	filename: "src/lib/studio/api.ts"
}, (opts) => directChapter.__executeServer(opts));
var directChapter = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const text = typeof row?.text === "string" ? row.text.trim() : "";
	if (text.length < 40) throw new Error("Paste at least a short chapter.");
	if (text.length > 9e3) throw new Error("That chunk is too long. The studio splits a long chapter before asking.");
	return {
		text,
		lock: typeof row.lock === "string" ? row.lock.trim().slice(0, 1800) : "",
		session: readSession(input)
	};
}).handler(directChapter_createServerFn_handler, async ({ data }) => {
	const system = directorSystem(data.session.language);
	const lock = data.lock ? `CHARACTER LOCK. Use these looks in every imagePrompt. Do not narrate this lock as extra scenes.\n${data.lock}\n\n` : "";
	const user = containsHan(data.text) ? `${lock}Source chapter (translate every Chinese character; do not copy Chinese into the JSON):\n${data.text}` : `${lock}${data.text}`;
	let result = await callActiveAI(data.session, system, user);
	if (!result.ok) return result;
	let via = result.via;
	let direction = parseDirection(result.text);
	if (direction && containsHan(`${direction.narration}\n${direction.hook}\n${direction.scenes.map((scene) => `${scene.caption} ${scene.dialogue}`).join("\n")}`)) {
		const retry = await callActiveAI(data.session, system, `The previous JSON still contained Chinese. Translate it fully into ${data.session.language === "hi" ? "Hindi" : "English"} and return JSON only.\n${result.text.slice(0, 6e3)}`);
		if (retry.ok) {
			const again = parseDirection(retry.text);
			if (again) {
				direction = again;
				via = retry.via;
			}
		}
	}
	if (!direction) return {
		ok: false,
		error: "The director returned a plan this studio could not read."
	};
	const spoken = `${direction.narration}\n${direction.hook}\n${direction.scenes.map((scene) => `${scene.caption} ${scene.dialogue}`).join("\n")}`;
	if (containsHan(spoken)) return {
		ok: false,
		error: "The script still had Chinese in it. Run the director again."
	};
	if (!direction.narration) direction.narration = [direction.hook, ...direction.scenes.map((scene) => [scene.caption, scene.dialogue].filter(Boolean).join(" "))].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
	return {
		ok: true,
		direction,
		via
	};
});
var writeBeatPrompt_createServerFn_handler = createServerRpc({
	id: "fb35a5929aeb382cfa404066c94369172b0a468056c7ce98b53e69b645a0941b",
	name: "writeBeatPrompt",
	filename: "src/lib/studio/api.ts"
}, (opts) => writeBeatPrompt.__executeServer(opts));
var writeBeatPrompt = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const caption = typeof row.caption === "string" ? row.caption.slice(0, 400) : "";
	const dialogue = typeof row.dialogue === "string" ? row.dialogue.slice(0, 400) : "";
	if (!caption.trim() && !dialogue.trim()) throw new Error("That beat has no line.");
	const chapter = typeof row.chapter === "number" && Number.isFinite(row.chapter) ? Math.floor(row.chapter) : 0;
	return {
		caption,
		dialogue,
		speaker: typeof row.speaker === "string" ? row.speaker.slice(0, 40) : "",
		state: typeof row.state === "string" ? row.state.slice(0, 180) : "",
		chapter: chapter > 0 && chapter < 1e5 ? chapter : 0,
		lock: typeof row.lock === "string" ? row.lock.slice(0, 1800) : "",
		session: readSession(input)
	};
}).handler(writeBeatPrompt_createServerFn_handler, async ({ data }) => {
	const system = [
		"Write ONE English image prompt for a single vertical manhua panel. Return JSON only: {\"prompt\":\"...\"}.",
		"Colored manhwa, clean ink, dramatic close-up or action as this one line needs.",
		"Paste the character lock in full. No random extra people. No watermark. No letters, logos, or speech bubbles inside the picture.",
		"Do not translate the prompt. Do not write the spoken line as text in the drawing."
	].join(" ");
	const user = [
		data.lock ? `CHARACTER LOCK:\n${data.lock}` : "",
		`This beat only. Chapter ${data.chapter || "unknown"}. Speaker: ${data.speaker || "narrator"}.`,
		`Caption: ${data.caption}`,
		`Dialogue: ${data.dialogue}`,
		`State: ${data.state}`
	].filter(Boolean).join("\n");
	const result = await callActiveAI(data.session, system, user);
	if (!result.ok) return result;
	const start = result.text.indexOf("{");
	const end = result.text.lastIndexOf("}");
	let prompt = "";
	if (start >= 0 && end > start) try {
		const parsed = JSON.parse(result.text.slice(start, end + 1));
		if (typeof parsed.prompt === "string") prompt = parsed.prompt.trim();
	} catch {
		prompt = "";
	}
	if (!prompt) prompt = result.text.replace(/\s+/g, " ").trim();
	prompt = prompt.replace(/^prompt\s*:\s*/i, "").slice(0, 700);
	if (prompt.length < 8) return {
		ok: false,
		error: "The writer did not return a prompt. The picture was not drawn."
	};
	return {
		ok: true,
		prompt
	};
});
function referenceParts(value) {
	if (typeof value !== "string") return {
		reference: "",
		referenceBase64: ""
	};
	const raw = value.trim();
	if (/^https:\/\//i.test(raw)) return {
		reference: raw.slice(0, 2e3),
		referenceBase64: ""
	};
	const match = raw.match(/^data:[^;,]+;base64,([a-z0-9+/=\s]+)$/i);
	if (!match?.[1]) return {
		reference: "",
		referenceBase64: ""
	};
	const data = match[1].replace(/\s/g, "");
	if (data.length < 80 || data.length > 9e5) return {
		reference: "",
		referenceBase64: ""
	};
	return {
		reference: "",
		referenceBase64: data
	};
}
var paintPanel_createServerFn_handler = createServerRpc({
	id: "c2f0841c7549228172cf44a94d57bc6fe6617883157ac8877ca13b3cd14e776d",
	name: "paintPanel",
	filename: "src/lib/studio/api.ts"
}, (opts) => paintPanel.__executeServer(opts));
var paintPanel = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const prompt = typeof row?.prompt === "string" ? row.prompt.trim() : "";
	if (prompt.length < 8) throw new Error("That panel has no picture note.");
	const repo = typeof row.repo === "string" ? row.repo.trim().slice(0, 200) : "";
	return {
		prompt: prompt.slice(0, 900),
		repo,
		...referenceParts(row.reference),
		session: readSession(input)
	};
}).handler(paintPanel_createServerFn_handler, async ({ data }) => {
	const painted = `Vertical colored manhwa, clean ink, dramatic lighting, consistent character, no text, no letters, no watermark, no speech bubbles. ${data.prompt}`;
	const paintWorker = async () => {
		const result = await workerPost("/api/v1/paint", data.session.workerUrl, data.session.workerToken, {
			prompt: painted,
			negative: "text, letters, logos, watermark, speech bubbles",
			reference: data.reference,
			referenceBase64: data.referenceBase64,
			repo: data.repo
		});
		if (!result.ok) return result;
		const row = result.json && typeof result.json === "object" ? result.json : {};
		const fallback = row.fallback === true || row.engine === "pollinations" || row.engine === "ink";
		const engine = typeof row.engine === "string" ? row.engine.slice(0, 40) : "";
		if (typeof row.url === "string" && row.url) return {
			ok: true,
			url: row.url,
			...fallback ? { fallback: true } : {},
			...engine ? { engine } : {}
		};
		if (typeof row.imageBase64 === "string" && row.imageBase64) return {
			ok: true,
			url: `data:${typeof row.mimeType === "string" ? row.mimeType : "image/png"};base64,${row.imageBase64}`,
			...fallback ? { fallback: true } : {},
			...engine ? { engine } : {}
		};
		return {
			ok: false,
			error: "The worker returned no image."
		};
	};
	if (imageVia(data.session.duty, Boolean(data.session.workerUrl.trim())) === "worker") {
		const drawn = await paintWorker();
		if (drawn.ok) return drawn;
	}
	return {
		ok: true,
		fallback: true,
		engine: "pollinations",
		url: `https://image.pollinations.ai/prompt/${encodeURIComponent(painted.slice(0, 480))}?width=768&height=1152&nologo=true&model=flux`
	};
});
var speakLine_createServerFn_handler = createServerRpc({
	id: "7797f3a0eac382d040e1aeb5a02dc9bdd2b747691bd8bcb4b611aca40449ed00",
	name: "speakLine",
	filename: "src/lib/studio/api.ts"
}, (opts) => speakLine.__executeServer(opts));
var speakLine = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const text = typeof row?.text === "string" ? row.text.trim() : "";
	if (text.length < 2) throw new Error("Nothing to read.");
	const voice = typeof row?.voice === "string" ? row.voice : "";
	const sceneId = typeof row.sceneId === "string" ? row.sceneId.replace(/[^A-Za-z0-9._-]/g, "").slice(0, 80) : "";
	return {
		text: text.slice(0, 12e3),
		voice,
		sceneId,
		force: row.force === true,
		session: readSession(input)
	};
}).handler(speakLine_createServerFn_handler, async ({ data }) => {
	const language = data.session.language;
	const voice = data.voice.trim() || (language === "hi" ? "hi-IN-MadhurNeural" : "en-US-ChristopherNeural");
	if (data.session.workerUrl.trim() && data.session.duty !== "key") {
		const result = await workerPost("/api/v1/speak", data.session.workerUrl, data.session.workerToken, {
			text: data.text.slice(0, 700),
			language,
			voice,
			sceneId: data.sceneId || "line",
			force: data.force
		});
		if (result.ok) {
			const row = result.json && typeof result.json === "object" ? result.json : {};
			const audio = typeof row.audioBase64 === "string" ? row.audioBase64 : "";
			const audioUrl = typeof row.url === "string" && row.url.startsWith("/api/v1/voices/") ? row.url.slice(0, 180) : "";
			const mimeType = typeof row.mimeType === "string" && row.mimeType ? row.mimeType : "audio/mpeg";
			if (audio.length >= 100 || audioUrl) return {
				ok: true,
				audioBase64: audio,
				mimeType,
				...audioUrl ? { audioUrl } : {}
			};
		}
	}
	if (data.session.provider === "gemini" && data.session.apiKey && data.session.duty === "key") return geminiSpeak(data.session.apiKey, data.text);
	const edge = await edgeSpeak(data.text, voice);
	if (edge.ok) return edge;
	return {
		ok: false,
		error: "Microsoft voice did not answer, and the worker has no saved track yet. Connect the worker so a local male voice can speak."
	};
});
function escapeSsml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
async function edgeSpeak(text, voice) {
	const name = voice.trim() || "en-US-ChristopherNeural";
	const lang = name.startsWith("hi-") ? "hi-IN" : "en-US";
	let tokenRes;
	try {
		tokenRes = await fetch("https://edge.microsoft.com/translate/auth", {
			signal: AbortSignal.timeout(12e3),
			headers: { "User-Agent": "Mozilla/5.0" }
		});
	} catch {
		return {
			ok: false,
			error: "Free voice did not answer."
		};
	}
	if (!tokenRes.ok) return {
		ok: false,
		error: "Free voice refused the token."
	};
	const token = (await tokenRes.text()).trim();
	if (!token) return {
		ok: false,
		error: "Free voice returned an empty token."
	};
	const pieces = speechChunks(text);
	const chunks = [];
	for (const piece of pieces) {
		const ssml = `<speak version="1.0" xml:lang="${lang}"><voice name="${escapeSsml(name)}">${escapeSsml(piece)}</voice></speak>`;
		let res;
		try {
			res = await fetch("https://speech.platform.bing.com/cognitiveservices/v1", {
				method: "POST",
				signal: AbortSignal.timeout(25e3),
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/ssml+xml",
					"X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3",
					"User-Agent": "Mozilla/5.0"
				},
				body: ssml
			});
		} catch {
			return {
				ok: false,
				error: "Free voice timed out."
			};
		}
		if (!res.ok) return {
			ok: false,
			error: `Free voice returned ${res.status}.`
		};
		const bytes = Buffer.from(await res.arrayBuffer());
		if (bytes.length < 128) return {
			ok: false,
			error: "Free voice returned empty audio."
		};
		chunks.push(bytes);
	}
	if (!chunks.length) return {
		ok: false,
		error: "Nothing to read."
	};
	return {
		ok: true,
		audioBase64: Buffer.concat(chunks).toString("base64"),
		mimeType: "audio/mpeg"
	};
}
function pcm16ToWav(pcm, sampleRate) {
	const header = Buffer.alloc(44);
	header.write("RIFF", 0);
	header.writeUInt32LE(36 + pcm.length, 4);
	header.write("WAVE", 8);
	header.write("fmt ", 12);
	header.writeUInt32LE(16, 16);
	header.writeUInt16LE(1, 20);
	header.writeUInt16LE(1, 22);
	header.writeUInt32LE(sampleRate, 24);
	header.writeUInt32LE(sampleRate * 2, 28);
	header.writeUInt16LE(2, 32);
	header.writeUInt16LE(16, 34);
	header.write("data", 36);
	header.writeUInt32LE(pcm.length, 40);
	return Buffer.concat([header, pcm]);
}
function speechChunks(text) {
	const parts = [];
	let rest = text.trim();
	while (rest && parts.length < 20) {
		if (rest.length <= 700) {
			parts.push(rest);
			break;
		}
		let cut = rest.lastIndexOf(". ", 700);
		if (cut < 180) cut = rest.lastIndexOf(" ", 700);
		if (cut < 80) cut = 700;
		const piece = rest.slice(0, cut + 1).trim();
		if (piece) parts.push(piece);
		rest = rest.slice(piece ? cut + 1 : 700).trim();
	}
	return parts;
}
async function geminiSpeak(apiKey, text) {
	const pieces = speechChunks(text);
	if (!pieces.length) return {
		ok: false,
		error: "Nothing to read."
	};
	const pcmParts = [];
	let sampleRate = 24e3;
	for (const piece of pieces) {
		let res;
		try {
			res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${studioConfig.geminiTtsModel}:generateContent`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"x-goog-api-key": apiKey
				},
				signal: AbortSignal.timeout(45e3),
				body: JSON.stringify({
					contents: [{
						role: "user",
						parts: [{ text: piece }]
					}],
					generationConfig: {
						responseModalities: ["AUDIO"],
						speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: studioConfig.geminiVoice } } }
					}
				})
			});
		} catch {
			return {
				ok: false,
				error: "Gemini voice did not answer."
			};
		}
		if (!res.ok) return {
			ok: false,
			error: `Gemini voice could not read that (${res.status}).`
		};
		let body;
		try {
			body = JSON.parse(await res.text());
		} catch {
			return {
				ok: false,
				error: "Gemini voice returned something this studio could not read."
			};
		}
		const inline = body.candidates?.[0]?.content?.parts?.find((part) => part.inlineData?.data)?.inlineData;
		if (!inline?.data) return {
			ok: false,
			error: "Gemini voice returned no audio."
		};
		const mime = inline.mimeType || "audio/L16;rate=24000";
		if (!/l16|pcm|raw/i.test(mime)) {
			if (!pcmParts.length) return {
				ok: true,
				audioBase64: inline.data,
				mimeType: mime.split(";")[0] || "audio/wav"
			};
			break;
		}
		const rate = mime.match(/rate=(\d+)/i);
		if (rate) sampleRate = Number(rate[1]) || sampleRate;
		pcmParts.push(Buffer.from(inline.data, "base64"));
	}
	return {
		ok: true,
		audioBase64: pcm16ToWav(Buffer.concat(pcmParts), sampleRate).toString("base64"),
		mimeType: "audio/wav"
	};
}
function asText(value, max) {
	return typeof value === "string" ? clip(value, max) : "";
}
function parseDirection(raw) {
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	let data;
	try {
		data = JSON.parse(raw.slice(start, end + 1));
	} catch {
		return null;
	}
	if (!data || typeof data !== "object") return null;
	const row = data;
	const characters = Array.isArray(row.characters) ? row.characters : [];
	const scenes = Array.isArray(row.scenes) ? row.scenes : [];
	const cast = [];
	for (const item of characters.slice(0, 12)) {
		if (!item || typeof item !== "object") continue;
		const character = item;
		const name = asText(character.name, 40);
		if (!name) continue;
		const look = asText(character.look, 280) || asText(character.vessel, 280);
		const rowCast = {
			id: asText(character.id, 32) || name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
			name,
			soul: asText(character.soul, 280) || "Identity stays with this name.",
			vessel: asText(character.vessel, 280) || "Body not stated.",
			look,
			face: asText(character.face, 180),
			hair: asText(character.hair, 180),
			age: asText(character.age, 40),
			scars: asText(character.scars, 180),
			eyes: asText(character.eyes, 80),
			body: asText(character.body, 180),
			outfit: asText(character.outfit, 180)
		};
		rowCast.look = composeLook(rowCast) || look;
		rowCast.vessel = rowCast.outfit || rowCast.vessel;
		cast.push(rowCast);
	}
	const panels = [];
	for (const [index, item] of scenes.entries()) {
		if (!item || typeof item !== "object") continue;
		const scene = item;
		const caption = asText(scene.caption, 240);
		const dialogue = asText(scene.dialogue, 180);
		if (!caption && !dialogue) continue;
		panels.push({
			id: `s${index + 1}`,
			caption,
			dialogue,
			speaker: asText(scene.speaker, 40),
			sfx: asText(scene.sfx, 16).toUpperCase(),
			state: asText(scene.state, 160),
			imagePrompt: "",
			imageUrl: null,
			promptLocked: false
		});
	}
	if (!panels.length) return null;
	const seoRaw = row.seo && typeof row.seo === "object" ? row.seo : {};
	const tags = Array.isArray(seoRaw.tags) ? seoRaw.tags.filter((tag) => typeof tag === "string").slice(0, 8) : [];
	return {
		title: asText(row.title, 80) || "Untitled chapter",
		hook: asText(row.hook, 320),
		logline: asText(row.logline, 200),
		timeline: Array.isArray(row.timeline) ? row.timeline.filter((note) => typeof note === "string") : [],
		characters: cast,
		scenes: panels,
		narration: asText(row.narration, 2e4),
		seo: {
			title: asText(seoRaw.title, 100) || asText(row.title, 80),
			description: asText(seoRaw.description, 220),
			tags
		}
	};
}
function blockedIp(ip) {
	const raw = ip.toLowerCase().replace(/^::ffff:/, "");
	if (raw === "::1" || raw === "0.0.0.0" || raw.startsWith("fe80:") || raw.startsWith("fc") || raw.startsWith("fd")) return true;
	const parts = raw.split(".").map((part) => Number(part));
	if (parts.length !== 4 || parts.some((part) => Number.isNaN(part))) return raw === "localhost";
	const [a, b] = parts;
	if (a === 10 || a === 127 || a === 0) return true;
	if (a === 169 && b === 254) return true;
	if (a === 192 && b === 168) return true;
	if (a === 172 && b >= 16 && b <= 31) return true;
	if (a === 100 && b >= 64 && b <= 127) return true;
	return false;
}
async function assertPublic(hostname) {
	const host = hostname.toLowerCase().replace(/\.+$/, "");
	if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal") || host === "metadata.google.internal" || blockedIp(host)) return "That address is private. It stays blocked.";
	const dns = await import("node:dns/promises");
	let records = [];
	try {
		records = await dns.lookup(host, {
			all: true,
			verbatim: true
		});
	} catch {
		return "That host did not resolve.";
	}
	if (!records.length || records.some((record) => blockedIp(record.address))) return "That address is private. It stays blocked.";
	return null;
}
var PAGE_HEADERS = {
	Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.7",
	"Accept-Language": "en-US,en;q=0.9,hi;q=0.8",
	"User-Agent": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
	"Cache-Control": "no-cache",
	Pragma: "no-cache",
	"Upgrade-Insecure-Requests": "1",
	"Sec-Fetch-Dest": "document",
	"Sec-Fetch-Mode": "navigate",
	"Sec-Fetch-Site": "none",
	"Sec-Fetch-User": "?1"
};
var DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
var GOOGLEBOT_UA = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
function looksLikeChallenge(html) {
	const head = html.slice(0, 6e3).toLowerCase();
	return /just a moment|cf-browser-verification|challenge-platform|cf-chl-|attention required|enable javascript and cookies|cdn-cgi\/challenge/.test(head);
}
function looksLikePaywall(text) {
	if (text.length >= 500) return false;
	return /sign in|log in|login|subscribe|paywall|chapter locked|purchase to read|members only/.test(text.toLowerCase());
}
async function readHtml(url, cookie = "") {
	const agents = [
		PAGE_HEADERS["User-Agent"],
		DESKTOP_UA,
		GOOGLEBOT_UA
	];
	let last = {
		ok: false,
		code: "FETCH_FAILED",
		error: "The page did not answer."
	};
	for (const agent of agents) {
		let current = url;
		let blockedEarly = false;
		for (let hop = 0; hop < 4; hop += 1) {
			const blocked = await assertPublic(current.hostname);
			if (blocked) return {
				ok: false,
				code: "SSRF_BLOCKED",
				error: blocked
			};
			let res;
			try {
				res = await fetch(current, {
					redirect: "manual",
					signal: AbortSignal.timeout(15e3),
					headers: {
						...PAGE_HEADERS,
						"User-Agent": agent,
						...cookie ? { Cookie: cookie } : {}
					}
				});
			} catch {
				last = {
					ok: false,
					code: "FETCH_FAILED",
					error: "The page did not answer."
				};
				blockedEarly = true;
				break;
			}
			if (res.status >= 300 && res.status < 400) {
				const location = res.headers.get("location");
				if (!location) {
					last = {
						ok: false,
						code: "FETCH_FAILED",
						error: "The page redirected nowhere."
					};
					blockedEarly = true;
					break;
				}
				current = new URL(location, current);
				continue;
			}
			if (res.status === 401 || res.status === 402) {
				last = {
					ok: false,
					code: "SOURCE_ACCESS_DENIED",
					error: "This page wants a login. Paste the chapter text instead."
				};
				blockedEarly = true;
				break;
			}
			if (res.status === 403 || res.status === 429 || res.status === 503) {
				last = {
					ok: false,
					code: "FETCH_BLOCKED",
					error: "The site blocked a direct fetch."
				};
				break;
			}
			if (!res.ok) {
				last = {
					ok: false,
					code: "FETCH_FAILED",
					error: `The page returned ${res.status}.`
				};
				break;
			}
			const reader = res.body?.getReader();
			if (!reader) {
				last = {
					ok: false,
					code: "FETCH_FAILED",
					error: "The page was empty."
				};
				break;
			}
			const chunks = [];
			let total = 0;
			while (total < 5e5) {
				const step = await reader.read();
				if (step.done) break;
				total += step.value.byteLength;
				chunks.push(step.value);
			}
			reader.cancel().catch(() => void 0);
			const html = Buffer.concat(chunks).toString("utf8");
			if (looksLikeChallenge(html)) {
				last = {
					ok: false,
					code: "FETCH_BLOCKED",
					error: "The site blocked a direct fetch."
				};
				if (html.length > 8e3) {
					const embedded = htmlToText(html);
					if (embedded.text.length >= 80 && !looksLikePaywall(embedded.text)) return {
						ok: true,
						html,
						finalUrl: current
					};
				}
				break;
			}
			return {
				ok: true,
				html,
				finalUrl: current
			};
		}
		if (blockedEarly) return last;
	}
	return last;
}
async function readViaReader(pageUrl) {
	let endpoint;
	try {
		endpoint = new URL(`https://r.jina.ai/${pageUrl}`);
	} catch {
		return null;
	}
	if (await assertPublic(endpoint.hostname)) return null;
	let res;
	try {
		res = await fetch(endpoint, {
			redirect: "follow",
			signal: AbortSignal.timeout(2e4),
			headers: {
				Accept: "text/plain, text/markdown, */*",
				"User-Agent": PAGE_HEADERS["User-Agent"],
				"X-Return-Format": "markdown"
			}
		});
	} catch {
		return null;
	}
	if (!res.ok) return null;
	const raw = (await res.text()).slice(0, 5e5);
	const titleLine = raw.match(/^Title:\s*(.+)$/m);
	const body = raw.replace(/^Title:\s*.+$/m, "").replace(/^URL Source:\s*.+$/m, "").replace(/^Markdown Content:\s*/m, "");
	const extracted = htmlToText(`<title>${titleLine?.[1] ?? ""}</title><article><p>${body}</p></article>`);
	const text = extracted.text;
	if (text.length < 80 || looksLikeChallenge(raw) || looksLikePaywall(text)) return null;
	return {
		title: extracted.title || titleLine?.[1]?.trim() || "",
		text
	};
}
function safeCookie(value) {
	if (typeof value !== "string") return "";
	const clean = value.replace(/[\r\n]/g, "").trim();
	if (!clean) return "";
	if (clean.length > 4e3) throw new Error("That cookie is too long.");
	if (!/^[\x20-\x7E]+$/.test(clean)) throw new Error("The cookie has characters this fetch will not send.");
	return clean;
}
var fetchSource_createServerFn_handler = createServerRpc({
	id: "d2a6b2a19797d69c5b0f8b3d8580fdfdf17003521da123e437d08bf40052abb6",
	name: "fetchSource",
	filename: "src/lib/studio/api.ts"
}, (opts) => fetchSource.__executeServer(opts));
var fetchSource = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const url = typeof row?.url === "string" ? row.url.trim() : "";
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		throw new Error("That link is not a URL.");
	}
	if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new Error("Only http and https links.");
	return {
		url: parsed.toString(),
		cookie: safeCookie(row.cookie)
	};
}).handler(fetchSource_createServerFn_handler, async ({ data }) => {
	const page = new URL(data.url);
	const blocked = await assertPublic(page.hostname);
	if (blocked) return {
		ok: false,
		code: "SSRF_BLOCKED",
		error: blocked
	};
	const wtr = parseWtrChapterUrl(data.url);
	if (wtr && !data.cookie) try {
		const chapter = await fetchWtrChapter(wtr);
		if (chapter && chapter.text.length >= 80) {
			const text = sanitizeNovelText(chapter.text);
			const title = sanitizeNovelText(chapter.title);
			if (text.length >= 80) return {
				ok: true,
				title: title || page.hostname,
				text,
				panels: []
			};
		}
	} catch {}
	const direct = await readHtml(page, data.cookie);
	if (direct.ok) {
		const challenge = looksLikeChallenge(direct.html);
		const extracted = htmlToText(direct.html);
		const panels = extractPanels(direct.html, direct.finalUrl.toString());
		if (!challenge && (extracted.text.length >= 80 || panels.length > 0) && !looksLikePaywall(extracted.text)) return {
			ok: true,
			title: extracted.title || direct.finalUrl.hostname,
			text: extracted.text,
			panels
		};
	} else if (direct.code === "SSRF_BLOCKED") return direct;
	const fallback = data.cookie ? null : await readViaReader(data.url);
	if (fallback) return {
		ok: true,
		title: fallback.title || page.hostname,
		text: fallback.text,
		panels: []
	};
	if (direct.ok && looksLikeChallenge(direct.html)) return {
		ok: false,
		code: "FETCH_BLOCKED",
		error: "The site blocked the fetch (Cloudflare or a script-only page). Paste the chapter, or paste your browser cookie for this site. This is not a paywall."
	};
	if (!direct.ok && direct.code === "FETCH_BLOCKED") return {
		ok: false,
		code: "FETCH_BLOCKED",
		error: data.cookie ? "The site still blocked the fetch with that cookie. Paste the chapter text." : "The site blocked the fetch. Paste a cookie from a tab where you are logged in, or paste the chapter text."
	};
	if (!direct.ok && direct.code === "SOURCE_ACCESS_DENIED") return {
		ok: false,
		code: "SOURCE_ACCESS_DENIED",
		error: data.cookie ? "That cookie was rejected. Paste the chapter text. Passwords are not accepted." : "This page wants a login. Paste your browser cookie for this site, or paste the chapter text. Passwords are not accepted."
	};
	if (!direct.ok) return direct;
	return {
		ok: false,
		code: "FETCH_FAILED",
		error: "No chapter text on that page. Paste it instead."
	};
});
function redact(raw, secret, max = 280) {
	return (secret ? raw.split(secret).join("[redacted]") : raw).slice(0, max);
}
var testWorker_createServerFn_handler = createServerRpc({
	id: "43a434a06dbf29ff3543b713d534cb31f6aa0cdec6e5bd64d4f82ca5bfba06cf",
	name: "testWorker",
	filename: "src/lib/studio/api.ts"
}, (opts) => testWorker.__executeServer(opts));
var testWorker = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const target = workerEndpoint(typeof row?.url === "string" ? row.url : "", "/api/v1/health");
	return {
		href: target.toString(),
		hostname: target.hostname,
		token
	};
}).handler(testWorker_createServerFn_handler, async ({ data }) => {
	const blocked = await assertPublic(data.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(data.href, {
			method: "GET",
			redirect: "manual",
			signal: AbortSignal.timeout(8e3),
			headers: {
				Accept: "application/json",
				"X-Aether-Token": data.token
			}
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not answer."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		status: res.status,
		error: "The worker redirected. Health must answer directly."
	};
	const body = redact(await res.text(), data.token);
	if (!res.ok) return {
		ok: false,
		status: res.status,
		body,
		error: `Worker health returned ${res.status}.`
	};
	return {
		ok: true,
		status: res.status,
		body
	};
});
var submitJob_createServerFn_handler = createServerRpc({
	id: "2b4c3398c432f7c57717b4b27f3354ccead6a03c2c78a584a8e48580a0f312be",
	name: "submitJob",
	filename: "src/lib/studio/api.ts"
}, (opts) => submitJob.__executeServer(opts));
var submitJob = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const target = workerEndpoint(typeof row?.url === "string" ? row.url : "", "/api/v1/jobs");
	const packet = jobPacketV2Schema.parse(row?.packet);
	return {
		href: target.toString(),
		hostname: target.hostname,
		token,
		packet
	};
}).handler(submitJob_createServerFn_handler, async ({ data }) => {
	const blocked = await assertPublic(data.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(data.href, {
			method: "POST",
			redirect: "manual",
			signal: AbortSignal.timeout(2e4),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
				"X-Aether-Token": data.token
			},
			body: JSON.stringify(data.packet)
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not take the job."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected. The job was not sent."
	};
	const body = redact(await res.text(), data.token);
	if (!res.ok) return {
		ok: false,
		error: body || `Worker returned ${res.status}.`
	};
	return {
		ok: true,
		status: res.status,
		body,
		jobId: readJobId(body)
	};
});
async function workerGet(href, hostname, token) {
	const blocked = await assertPublic(hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(href, {
			method: "GET",
			redirect: "manual",
			signal: AbortSignal.timeout(2e4),
			headers: {
				Accept: "application/json, video/mp4, application/octet-stream",
				"X-Aether-Token": token
			}
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not answer."
		};
	}
	if (res.status >= 300 && res.status < 400) return {
		ok: false,
		error: "The worker redirected. Nothing was followed."
	};
	const hidden = redact(await res.text(), token, 1e5);
	if (!res.ok) return {
		ok: false,
		error: hidden.slice(0, 280) || `Worker returned ${res.status}.`
	};
	return {
		ok: true,
		status: res.status,
		body: hidden,
		contentType: res.headers.get("content-type") ?? ""
	};
}
var jobStatus_createServerFn_handler = createServerRpc({
	id: "ef33f39ce09d4830db33acbc9b501f8bb3ee230c73513250a73d48a2693754a6",
	name: "jobStatus",
	filename: "src/lib/studio/api.ts"
}, (opts) => jobStatus.__executeServer(opts));
var jobStatus = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const token = typeof row?.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const jobId = assertJobId(typeof row?.jobId === "string" ? row.jobId : "");
	const target = workerEndpoint(typeof row?.url === "string" ? row.url : "", jobResourcePath(jobId));
	return {
		href: target.toString(),
		hostname: target.hostname,
		token,
		jobId
	};
}).handler(jobStatus_createServerFn_handler, async ({ data }) => {
	const result = await workerGet(data.href, data.hostname, data.token);
	if (!result.ok) return result;
	try {
		return {
			ok: true,
			job: parseJobStatus(JSON.parse(result.body), data.jobId)
		};
	} catch {
		return {
			ok: false,
			error: "The worker status was not JSON."
		};
	}
});
var verifyCloud_createServerFn_handler = createServerRpc({
	id: "09a063287da321971bf1e2e5ddeff28a007c98885c01cc5edf05f991690f4cd9",
	name: "verifyCloud",
	filename: "src/lib/studio/api.ts"
}, (opts) => verifyCloud.__executeServer(opts));
var verifyCloud = createServerFn({ method: "POST" }).validator((input) => readSession(input)).handler(verifyCloud_createServerFn_handler, async ({ data }) => {
	const ping = await callCloud(data, "Reply with exactly OK.", "Reply with exactly OK.", false);
	if (!ping.ok) return {
		ok: false,
		error: ping.error
	};
	if (!/ok/i.test(ping.text)) return {
		ok: false,
		error: "The model answered, but the check did not pass."
	};
	return {
		ok: true,
		badge: "API Verified & Connected — OK"
	};
});
var uploadYoutube_createServerFn_handler = createServerRpc({
	id: "dda5ac0a6423b8a1b16e067a52b457002d6f430cdce082076b56f01019813444",
	name: "uploadYoutube",
	filename: "src/lib/studio/api.ts"
}, (opts) => uploadYoutube.__executeServer(opts));
var uploadYoutube = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const accessToken = typeof row.accessToken === "string" ? row.accessToken.trim() : "";
	if (accessToken.length < 20 || accessToken.length > 8e3) throw new Error("Connect a YouTube channel first.");
	const jobId = assertJobId(typeof row.jobId === "string" ? row.jobId : "");
	const target = workerEndpoint(typeof row.url === "string" ? row.url : "", "/api/v1/youtube-upload");
	const token = typeof row.token === "string" ? row.token : "";
	if (token.length > 500) throw new Error("That token is too long.");
	const title = typeof row.title === "string" ? row.title.slice(0, 100) : "";
	const description = typeof row.description === "string" ? row.description.slice(0, 5e3) : "";
	const tags = Array.isArray(row.tags) ? row.tags.filter((tag) => typeof tag === "string").slice(0, 15) : [];
	const privacy = row.privacy === "public" || row.privacy === "unlisted" || row.privacy === "private" ? row.privacy : "private";
	const language = row.language === "hi" ? "hi" : "en";
	return {
		href: target.toString(),
		hostname: target.hostname,
		token,
		accessToken,
		jobId,
		title,
		description,
		tags,
		privacy,
		language
	};
}).handler(uploadYoutube_createServerFn_handler, async ({ data }) => {
	const blocked = await assertPublic(data.hostname);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	let res;
	try {
		res = await fetch(data.href, {
			method: "POST",
			redirect: "manual",
			signal: AbortSignal.timeout(12e4),
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
				"X-Aether-Token": data.token
			},
			body: JSON.stringify({
				jobId: data.jobId,
				accessToken: data.accessToken,
				title: data.title,
				description: data.description,
				tags: data.tags,
				privacy: data.privacy,
				language: data.language
			})
		});
	} catch {
		return {
			ok: false,
			error: "The worker did not upload the video."
		};
	}
	const raw = (await res.text()).split(data.accessToken).join("[redacted]").split(data.token).join("[redacted]");
	if (!res.ok) return {
		ok: false,
		error: raw.slice(0, 280) || `YouTube upload returned ${res.status}.`
	};
	try {
		const json = JSON.parse(raw);
		if (typeof json.watchUrl === "string" && /^https:\/\/www\.youtube\.com\/watch\?v=[\w-]{6,}$/.test(json.watchUrl)) return {
			ok: true,
			watchUrl: json.watchUrl
		};
	} catch {}
	return {
		ok: false,
		error: "The worker did not return a YouTube link."
	};
});
var translateLines_createServerFn_handler = createServerRpc({
	id: "1f0cfaf2cfb7db3fc62b33bf8cc6df12890914679a47e6591994d357a4a7e591",
	name: "translateLines",
	filename: "src/lib/studio/api.ts"
}, (opts) => translateLines.__executeServer(opts));
var translateLines = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const target = row.target === "hi" ? "hi" : row.target === "en" ? "en" : "";
	if (!target) throw new Error("Pick English or Hindi.");
	if (!Array.isArray(row.lines) || row.lines.length === 0) throw new Error("No lines to translate.");
	if (row.lines.length > 40) throw new Error("Translate at most 40 lines at a time.");
	return {
		target,
		lines: row.lines.map((item) => {
			const line = item;
			const id = typeof line.id === "string" ? line.id.slice(0, 40) : "";
			if (!id) throw new Error("A line is missing its id.");
			return {
				id,
				caption: typeof line.caption === "string" ? line.caption.slice(0, 400) : "",
				dialogue: typeof line.dialogue === "string" ? line.dialogue.slice(0, 400) : ""
			};
		}),
		session: readSession({
			...input,
			language: target
		})
	};
}).handler(translateLines_createServerFn_handler, async ({ data }) => {
	const system = [
		`Translate every string into ${data.target === "hi" ? "Hindi in Devanagari" : "English"}.`,
		"Return JSON only: {lines:[{id,caption,dialogue}], narration, seo:{title,description,tags,hashtags}}.",
		"Keep each id exactly. Do not add panels. Do not write image prompts. Do not mention pictures."
	].join(" ");
	const result = await callActiveAI(data.session, system, JSON.stringify({ lines: data.lines }));
	if (!result.ok) return {
		ok: false,
		error: `${result.error} Pictures were not touched.`
	};
	const start = result.text.indexOf("{");
	const end = result.text.lastIndexOf("}");
	if (start < 0 || end <= start) return {
		ok: false,
		error: "The translator did not return a script. Pictures were not touched."
	};
	let parsed;
	try {
		parsed = JSON.parse(result.text.slice(start, end + 1));
	} catch {
		return {
			ok: false,
			error: "The translator returned a script this studio could not read. Pictures were not touched."
		};
	}
	const wanted = new Set(data.lines.map((line) => line.id));
	const lines = (parsed.lines ?? []).map((line) => ({
		id: typeof line.id === "string" ? line.id : "",
		caption: typeof line.caption === "string" ? line.caption.slice(0, 400) : "",
		dialogue: typeof line.dialogue === "string" ? line.dialogue.slice(0, 400) : ""
	})).filter((line) => wanted.has(line.id));
	if (!lines.length) return {
		ok: false,
		error: "The translator dropped the lines. Pictures were not touched."
	};
	const seo = parsed.seo ?? {};
	const tags = Array.isArray(seo.tags) ? seo.tags.filter((tag) => typeof tag === "string").slice(0, 12) : [];
	return {
		ok: true,
		lines,
		narration: typeof parsed.narration === "string" ? parsed.narration.slice(0, 2e4) : "",
		seo: {
			title: typeof seo.title === "string" ? seo.title.slice(0, 100) : "",
			description: typeof seo.description === "string" ? seo.description.slice(0, 500) : "",
			tags,
			hashtags: typeof seo.hashtags === "string" ? seo.hashtags.slice(0, 200) : ""
		}
	};
});
var chatTurn_createServerFn_handler = createServerRpc({
	id: "df700042e2b5a64c50059fb5c12effaaa337b2d36bbd1fbda7c247f351791d52",
	name: "chatTurn",
	filename: "src/lib/studio/api.ts"
}, (opts) => chatTurn.__executeServer(opts));
var chatTurn = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const message = typeof row.message === "string" ? row.message.trim() : "";
	if (message.length < 1) throw new Error("Type a message.");
	if (message.length > 2e3) throw new Error("That message is too long.");
	return {
		message,
		context: typeof row.context === "string" ? row.context.slice(0, 4e3) : "",
		session: readSession(input)
	};
}).handler(chatTurn_createServerFn_handler, async ({ data }) => {
	const system = [
		"You are the assistant inside a manhua explanation studio.",
		"Answer in the same language the user wrote.",
		"If they ask to change English/Hindi voiceover, tell them Re-voice only changes the spoken script, audio, captions, and YouTube text. It does not redraw pictures.",
		"Do not claim you generated an image unless the user already said a panel was painted.",
		"When the user corrects one character's look, end with a single line: ACTION {\"type\":\"look\",\"name\":\"Exact Name\",\"face\":\"\",\"hair\":\"\",\"age\":\"\",\"scars\":\"\",\"eyes\":\"\",\"body\":\"\",\"outfit\":\"\",\"chapter\":0}",
		"Include only the fields they changed. chapter is 0 unless they named a chapter for an outfit change.",
		"When the user corrects one spoken line, end with: ACTION {\"type\":\"line\",\"id\":\"s1\",\"text\":\"the new spoken line only\"}",
		"Use the beat id from the project context. If they are only asking a question, do not add an ACTION line."
	].join(" ");
	const result = await callActiveAI(data.session, system, data.context ? `Project:\n${data.context}\n\nUser:\n${data.message}` : data.message);
	if (!result.ok) return result;
	const parsed = parseStudioAction(result.text.trim().slice(0, 4e3));
	return {
		ok: true,
		reply: parsed.reply || result.text.trim().slice(0, 4e3),
		action: parsed.action
	};
});
async function imageBytes(url) {
	if (url.startsWith("data:")) {
		const match = url.match(/^data:([^;,]+);base64,([a-z0-9+/=\s]+)$/i);
		if (!match?.[1] || !match[2]) return null;
		if (match[2].length > 5e6) return null;
		return {
			mime: match[1],
			data: match[2].replace(/\s/g, "")
		};
	}
	if (!/^https:\/\//i.test(url)) return null;
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return null;
	}
	if (await assertPublic(parsed.hostname)) return null;
	let res;
	try {
		res = await fetch(parsed, {
			redirect: "follow",
			signal: AbortSignal.timeout(2e4)
		});
	} catch {
		return null;
	}
	if (!res.ok) return null;
	const buf = Buffer.from(await res.arrayBuffer());
	if (buf.length < 64 || buf.length > 4e6) return null;
	const mime = (res.headers.get("content-type") || "image/jpeg").split(";")[0] || "image/jpeg";
	if (!mime.startsWith("image/")) return null;
	return {
		mime,
		data: buf.toString("base64")
	};
}
var checkPanel_createServerFn_handler = createServerRpc({
	id: "0ac02964e89d85f31604cd870fdf5c0c5055a92cb471bdc2ab52b076f55ca0a1",
	name: "checkPanel",
	filename: "src/lib/studio/api.ts"
}, (opts) => checkPanel.__executeServer(opts));
var checkPanel = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const prompt = typeof row.prompt === "string" ? row.prompt.trim() : "";
	const imageUrl = typeof row.imageUrl === "string" ? row.imageUrl.trim() : "";
	if (prompt.length < 8 || !imageUrl) throw new Error("Nothing to check.");
	return {
		prompt: prompt.slice(0, 700),
		imageUrl: imageUrl.slice(0, 12e5),
		session: readSession(input)
	};
}).handler(checkPanel_createServerFn_handler, async ({ data }) => {
	const image = await imageBytes(data.imageUrl);
	const workerChecker = Boolean(data.session.workerUrl.trim()) && data.session.duty !== "key";
	const geminiChecker = data.session.provider === "gemini" && Boolean(data.session.apiKey) && data.session.duty !== "worker";
	if (workerChecker) {
		const result = await workerPost("/api/v1/check", data.session.workerUrl, data.session.workerToken, {
			prompt: data.prompt,
			imageUrl: data.imageUrl.startsWith("data:") ? "" : data.imageUrl.slice(0, 2e3),
			imageBase64: image?.data || ""
		});
		if (result.ok && result.json && typeof result.json === "object") {
			const row = result.json;
			const match = row.match === false || row.match === "no" ? "no" : row.match === true || row.match === "yes" ? "yes" : "skipped";
			const note = typeof row.note === "string" ? row.note.slice(0, 240) : "";
			if (match !== "skipped") return {
				ok: true,
				match,
				note
			};
		}
	}
	if (geminiChecker) {
		if (!image) return {
			ok: true,
			match: "skipped",
			note: "Checker could not read the file. Picture kept."
		};
		let res;
		try {
			res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${studioConfig.geminiModel}:generateContent`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"x-goog-api-key": data.session.apiKey
				},
				signal: AbortSignal.timeout(4e4),
				body: JSON.stringify({ contents: [{
					role: "user",
					parts: [{ text: `Compare the image to this manhua prompt. Reply JSON only: {"match":true|false,"note":"one sentence"}. Fail the match if the face, hair, outfit, or scene is clearly wrong. Prompt: ${data.prompt}` }, { inlineData: {
						mimeType: image.mime,
						data: image.data
					} }]
				}] })
			});
		} catch {
			return {
				ok: true,
				match: "skipped",
				note: "Checker did not answer. Picture kept."
			};
		}
		if (!res.ok) return {
			ok: true,
			match: "skipped",
			note: "Checker could not look. Picture kept."
		};
		try {
			const text = JSON.parse(await res.text()).candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("") ?? "";
			const start = text.indexOf("{");
			const end = text.lastIndexOf("}");
			if (start < 0 || end <= start) return {
				ok: true,
				match: "skipped",
				note: "Checker reply was unclear. Picture kept."
			};
			const verdict = JSON.parse(text.slice(start, end + 1));
			const note = typeof verdict.note === "string" ? verdict.note.slice(0, 240) : "";
			return {
				ok: true,
				match: verdict.match === false ? "no" : "yes",
				note
			};
		} catch {
			return {
				ok: true,
				match: "skipped",
				note: "Checker reply was unclear. Picture kept."
			};
		}
	}
	return {
		ok: true,
		match: "skipped",
		note: "No checker connected. Picture kept. Connect the worker, or a Gemini key, to verify the face."
	};
});
function asPages(value) {
	if (!Array.isArray(value)) return [];
	return value.slice(0, 220).map((item) => {
		const row = item && typeof item === "object" ? item : {};
		const panels = Array.isArray(row.panels) ? row.panels.slice(0, 80).map((panel) => {
			const box = panel && typeof panel === "object" ? panel : {};
			const src = typeof box.src === "string" ? box.src.slice(0, 500) : "";
			const bubble = typeof box.bubble === "string" ? box.bubble.slice(0, 400) : "";
			const aside = typeof box.aside === "string" ? box.aside.slice(0, 400) : "";
			return {
				src,
				text: typeof box.text === "string" ? box.text.slice(0, 500) : [bubble, aside].filter(Boolean).join(" "),
				bubble,
				aside
			};
		}) : [];
		return {
			url: typeof row.url === "string" ? row.url.slice(0, 500) : "",
			ok: row.ok !== false,
			title: typeof row.title === "string" ? row.title.slice(0, 180) : "",
			text: typeof row.text === "string" ? row.text.slice(0, 2e4) : "",
			error: typeof row.error === "string" ? row.error.slice(0, 200) : "",
			panels: panels.filter((panel) => panel.src.startsWith("http"))
		};
	});
}
var startWorkerFetch_createServerFn_handler = createServerRpc({
	id: "7e57028f6fb2d7224fa93966b01dee72ba28d8b1c9a68bacb107f1c2e626dd10",
	name: "startWorkerFetch",
	filename: "src/lib/studio/api.ts"
}, (opts) => startWorkerFetch.__executeServer(opts));
var startWorkerFetch = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	if (!Array.isArray(row.urls) || row.urls.length === 0) throw new Error("No chapter links to send.");
	if (row.urls.length > 180) throw new Error("That range is too long for one worker fetch. Split it.");
	return {
		urls: row.urls.map((item) => {
			if (typeof item !== "string") throw new Error("A chapter link is not a URL.");
			let parsed;
			try {
				parsed = new URL(item.trim());
			} catch {
				throw new Error("A chapter link is not a URL.");
			}
			if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new Error("Only http and https links.");
			return parsed.toString();
		}),
		cookie: safeCookie(row.cookie),
		session: readSession(input)
	};
}).handler(startWorkerFetch_createServerFn_handler, async ({ data }) => {
	if (!data.session.workerUrl.trim()) return {
		ok: false,
		error: "Add the worker URL first. Long ranges are fetched there, not on this phone."
	};
	for (const url of data.urls) {
		const blocked = await assertPublic(new URL(url).hostname);
		if (blocked) return {
			ok: false,
			error: blocked
		};
	}
	const result = await workerPost("/api/v1/fetch", data.session.workerUrl, data.session.workerToken, {
		urls: data.urls,
		cookie: data.cookie
	});
	if (!result.ok) return result;
	const row = result.json && typeof result.json === "object" ? result.json : {};
	const jobId = typeof row.id === "string" ? row.id : "";
	if (!/^[A-Za-z0-9]{6,32}$/.test(jobId)) return {
		ok: false,
		error: "The worker did not start the fetch."
	};
	return {
		ok: true,
		jobId
	};
});
var workerFetchStatus_createServerFn_handler = createServerRpc({
	id: "b337bb6b6aae62e28d13fa7c64dcaab68f11dbb7970b86d5149f9a8545412300",
	name: "workerFetchStatus",
	filename: "src/lib/studio/api.ts"
}, (opts) => workerFetchStatus.__executeServer(opts));
var workerFetchStatus = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	const jobId = typeof row.jobId === "string" ? row.jobId.trim() : "";
	if (!/^[A-Za-z0-9]{6,32}$/.test(jobId)) throw new Error("That fetch id is not valid.");
	return {
		jobId,
		session: readSession(input)
	};
}).handler(workerFetchStatus_createServerFn_handler, async ({ data }) => {
	const result = await workerJson(`/api/v1/fetch/${data.jobId}`, data.session.workerUrl, data.session.workerToken);
	if (!result.ok) return result;
	const row = result.json && typeof result.json === "object" ? result.json : {};
	const progress = typeof row.progress === "number" ? Math.max(0, Math.min(100, Math.round(row.progress))) : 0;
	return {
		ok: true,
		status: typeof row.status === "string" ? row.status : "running",
		label: typeof row.label === "string" ? row.label.slice(0, 80) : "",
		progress,
		pages: asPages(row.pages)
	};
});
var readPanelText_createServerFn_handler = createServerRpc({
	id: "8ebf86c5fb42b3069035a5d461771576917679cb3d33929db611b8c62527eb7b",
	name: "readPanelText",
	filename: "src/lib/studio/api.ts"
}, (opts) => readPanelText.__executeServer(opts));
var readPanelText = createServerFn({ method: "POST" }).validator((input) => {
	const row = input;
	if (!Array.isArray(row.images) || row.images.length === 0) throw new Error("No panels to read.");
	if (row.images.length > 8) throw new Error("Read at most 8 panels at a time.");
	return {
		images: row.images.map((item) => {
			const box = item;
			const id = typeof box.id === "string" ? box.id.slice(0, 40) : "";
			const url = typeof box.url === "string" ? box.url.trim() : "";
			if (!id || !/^https?:\/\//i.test(url)) throw new Error("A panel image is missing its link.");
			return {
				id,
				url: url.slice(0, 500)
			};
		}),
		session: readSession(input)
	};
}).handler(readPanelText_createServerFn_handler, async ({ data }) => {
	if (!data.session.workerUrl.trim()) return {
		ok: false,
		error: "Bubble reading needs the worker."
	};
	const result = await workerPost("/api/v1/ocr", data.session.workerUrl, data.session.workerToken, { images: data.images });
	if (!result.ok) return result;
	const row = result.json && typeof result.json === "object" ? result.json : {};
	return {
		ok: true,
		panels: Array.isArray(row.panels) ? row.panels.map((item) => {
			const box = item && typeof item === "object" ? item : {};
			return {
				id: typeof box.id === "string" ? box.id.slice(0, 40) : "",
				bubble: typeof box.bubble === "string" ? box.bubble.slice(0, 400) : "",
				aside: typeof box.aside === "string" ? box.aside.slice(0, 400) : ""
			};
		}) : []
	};
});
//#endregion
export { chatTurn_createServerFn_handler, checkPanel_createServerFn_handler, directChapter_createServerFn_handler, fetchSource_createServerFn_handler, jobStatus_createServerFn_handler, paintPanel_createServerFn_handler, readPanelText_createServerFn_handler, speakLine_createServerFn_handler, startWorkerFetch_createServerFn_handler, submitJob_createServerFn_handler, testWorker_createServerFn_handler, translateLines_createServerFn_handler, uploadYoutube_createServerFn_handler, verifyCloud_createServerFn_handler, workerFetchStatus_createServerFn_handler, writeBeatPrompt_createServerFn_handler };

import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as workerEndpoint, c as detectLanguage, d as jobPacketV2Schema, i as PROVIDER_PRESETS, n as EXPLAIN_VOICES, r as LOCAL_MODES, s as defaultModel, t as DEFAULT_NEGATIVE, y as voiceFor } from "./worker-DRxkaWb4.mjs";
import { _ as textToOutfits, a as containsHan, d as lookLockForScene, f as mergeCast, g as sanitizeNovelText, i as composeLook, l as gleanCast, n as beatsNeedingPrompt, p as outfitsToText, r as bibleDocument, s as faceReferenceFor, t as applyLookPatch } from "./bible-BCfVgxxi.mjs";
import { a as ScrollText, c as Factory, i as Settings, l as Clapperboard, o as Mic, r as Sparkles, s as MessageCircle, t as Youtube } from "../_libs/lucide-react.mjs";
import { _ as writeBeatPrompt, a as fetchSource, c as readPanelText, d as submitJob, f as testWorker, g as workerFetchStatus, h as verifyCloud, i as directChapter, l as speakLine, m as uploadYoutube, n as chatTurn, o as jobStatus, p as translateLines, r as checkPanel, s as paintPanel, u as startWorkerFetch } from "./router-C606B4Ww.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BGda5EzH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function slot(scene, language) {
	const caption = language === "hi" ? scene.captionHi : scene.captionEn;
	const dialogue = language === "hi" ? scene.dialogueHi : scene.dialogueEn;
	if (caption === void 0 && dialogue === void 0) return null;
	return {
		caption: caption ?? "",
		dialogue: dialogue ?? ""
	};
}
function voiceLine(scene, language) {
	const stored = language === "hi" ? scene.lineHi : scene.lineEn;
	if (stored?.trim()) return stored.trim();
	const packed = slot(scene, language);
	if (packed && (packed.caption.trim() || packed.dialogue.trim())) return [packed.caption, packed.dialogue].filter(Boolean).join(" ").trim();
	const otherStored = language === "hi" ? scene.lineEn : scene.lineHi;
	const otherSlot = slot(scene, language === "hi" ? "en" : "hi");
	if (Boolean(otherStored?.trim() || otherSlot && (otherSlot.caption.trim() || otherSlot.dialogue.trim()))) return "";
	return [scene.caption, scene.dialogue].filter(Boolean).join(" ").trim();
}
function missingScript(project, language) {
	return project.scenes.filter((scene) => !voiceLine(scene, language)).map((scene) => scene.id);
}
/** Copy the stored script into the visible fields. Image URL and image prompt are copied through unchanged. */
function withLanguage(project, language) {
	const scenes = project.scenes.map((scene) => {
		const packed = slot(scene, language);
		if (!packed) return scene;
		return {
			...scene,
			caption: packed.caption,
			dialogue: packed.dialogue,
			imageUrl: scene.imageUrl,
			imagePrompt: scene.imagePrompt
		};
	});
	const narration = language === "hi" ? project.narrationHi : project.narrationEn;
	const seoPack = language === "hi" ? project.seoHi : project.seoEn;
	const seo = seoPack ? {
		...seoPack,
		privacy: project.seo.privacy
	} : project.seo;
	return {
		...project,
		language,
		scenes,
		narration: narration?.trim() || scenes.map((scene) => voiceLine(scene, language)).filter(Boolean).join(" "),
		seo
	};
}
/** Remember the visible script under the language that produced it. Does not clear the other language or any image. */
function rememberScript(project, language) {
	const scenes = project.scenes.map((scene) => {
		const line = [scene.caption, scene.dialogue].filter(Boolean).join(" ").trim();
		if (language === "hi") return {
			...scene,
			captionHi: scene.caption,
			dialogueHi: scene.dialogue,
			lineHi: scene.lineHi?.trim() || line
		};
		return {
			...scene,
			captionEn: scene.caption,
			dialogueEn: scene.dialogue,
			lineEn: scene.lineEn?.trim() || line
		};
	});
	if (language === "hi") return {
		...project,
		scenes,
		narrationHi: project.narration,
		seoHi: {
			...project.seo,
			privacy: void 0
		}
	};
	return {
		...project,
		scenes,
		narrationEn: project.narration,
		seoEn: {
			...project.seo,
			privacy: void 0
		}
	};
}
function writeTranslated(project, language, lines) {
	const byId = new Map(lines.map((line) => [line.id, line]));
	const scenes = project.scenes.map((scene) => {
		const next = byId.get(scene.id);
		if (!next) return scene;
		const line = [next.caption, next.dialogue].filter(Boolean).join(" ").trim();
		if (language === "hi") return {
			...scene,
			captionHi: next.caption,
			dialogueHi: next.dialogue,
			lineHi: line
		};
		return {
			...scene,
			captionEn: next.caption,
			dialogueEn: next.dialogue,
			lineEn: line
		};
	});
	return {
		...project,
		scenes
	};
}
var LOOK_HINT = /hair|robe|scar|eye|armor|face|beard|cloak|dress|outfit|sleeve|boots|blood|skin|brow|knot|spear|sword|pendant|jade/i;
/** Pull appearance sentences from chapters outside the cut. Not a panel list. */
function gleanLooks(text) {
	const sentences = text.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/).map((sentence) => sentence.trim()).filter((sentence) => sentence.length > 24 && sentence.length < 280 && LOOK_HINT.test(sentence));
	const unique = [];
	const seen = /* @__PURE__ */ new Set();
	for (const sentence of sentences) {
		const key = sentence.toLowerCase();
		if (seen.has(key)) continue;
		seen.add(key);
		unique.push(sentence);
		if (unique.length >= 14) break;
	}
	return unique.join(" ");
}
function srtStamp(seconds) {
	const safe = Math.max(0, seconds);
	const hours = Math.floor(safe / 3600);
	const minutes = Math.floor(safe % 3600 / 60);
	const whole = Math.floor(safe % 60);
	const millis = Math.round((safe - Math.floor(safe)) * 1e3);
	const pad = (value, size = 2) => String(value).padStart(size, "0");
	return `${pad(hours)}:${pad(minutes)}:${pad(whole)},${pad(millis, 3)}`;
}
/** Caption file for the active language. Timing follows the line length. Pictures are not involved. */
function srtFor(project, language) {
	let cursor = 0;
	return project.scenes.map((scene, index) => {
		const text = voiceLine(scene, language) || " ";
		const hold = scene.holdSec && scene.holdSec > 0 ? scene.holdSec : Math.min(18, Math.max(1.6, text.length / 14));
		const start = cursor;
		cursor += hold;
		return `${index + 1}\n${srtStamp(start)} --> ${srtStamp(cursor)}\n${text}\n`;
	}).join("\n");
}
var MALE = /male|\bguy\b|david|ravi|prabhat|madhur|daniel|fred|rishi|arthur|aaron|alex|george|charon|hindi india/i;
var FEMALE = /female|woman|zira|samantha|veena|heera|eva|susan|salli|victoria|fiona|lekha|neerja|google हिन्दी/i;
function primeSpeechUnlock() {
	if (typeof window === "undefined" || !window.speechSynthesis) return;
	try {
		window.speechSynthesis.resume();
		const primer = new SpeechSynthesisUtterance("​");
		primer.volume = 0;
		primer.rate = 1;
		window.speechSynthesis.speak(primer);
	} catch {}
}
function loadVoices(timeoutMs = 900) {
	if (typeof window === "undefined" || !window.speechSynthesis) return Promise.resolve([]);
	const synth = window.speechSynthesis;
	const ready = synth.getVoices();
	if (ready.length) return Promise.resolve(ready);
	return new Promise((resolve) => {
		let settled = false;
		const finish = () => {
			if (settled) return;
			settled = true;
			synth.removeEventListener("voiceschanged", finish);
			resolve(synth.getVoices());
		};
		synth.addEventListener("voiceschanged", finish);
		try {
			synth.getVoices();
			synth.resume();
		} catch {}
		window.setTimeout(finish, timeoutMs);
	});
}
function voiceScore(voice, hindi) {
	const blob = `${voice.lang} ${voice.name}`;
	let score = 0;
	if (hindi ? /^hi/i.test(voice.lang) : /^(en|hi)/i.test(voice.lang)) score += 4;
	if (MALE.test(blob) && !FEMALE.test(blob)) score += 3;
	if (voice.default) score += 1;
	if (voice.localService) score += 1;
	if (FEMALE.test(blob)) score -= 2;
	return score;
}
/** Prefer a male voice, but always return some voice so Android does not dead-end. */
function chooseVoice(voices, sample) {
	if (!voices.length) return null;
	const hindi = /[\u0900-\u097F]/.test(sample);
	return [...voices].sort((a, b) => voiceScore(b, hindi) - voiceScore(a, hindi))[0] ?? null;
}
function speechChunks(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (!clean) return [];
	if (clean.length <= 180) return [clean];
	const parts = [];
	let rest = clean;
	while (rest.length > 180) {
		let cut = rest.lastIndexOf(". ", 180);
		if (cut < 50) cut = rest.lastIndexOf(", ", 180);
		if (cut < 40) cut = rest.lastIndexOf(" ", 180);
		if (cut < 20) cut = 180;
		const piece = rest.slice(0, cut + 1).trim();
		if (piece) parts.push(piece);
		rest = rest.slice(cut + 1).trim();
	}
	if (rest) parts.push(rest);
	return parts.slice(0, 80);
}
function speakOnDevice(text, voice) {
	if (typeof window === "undefined" || !window.speechSynthesis) return Promise.reject(/* @__PURE__ */ new Error("This phone has no speech engine."));
	const pieces = speechChunks(text);
	if (!pieces.length) return Promise.resolve();
	const synth = window.speechSynthesis;
	const hindi = /[\u0900-\u097F]/.test(text);
	return new Promise((resolve, reject) => {
		let index = 0;
		let settled = false;
		let retriedBare = false;
		const finish = () => {
			if (settled) return;
			settled = true;
			resolve();
		};
		const fail = (message) => {
			if (settled) return;
			settled = true;
			reject(new Error(message));
		};
		const speakPiece = (bare) => {
			const utterance = new SpeechSynthesisUtterance(pieces[index] ?? "");
			if (!bare && voice) {
				utterance.voice = voice;
				if (voice.lang) utterance.lang = voice.lang;
			} else if (!bare && hindi) utterance.lang = "hi-IN";
			utterance.rate = .96;
			utterance.onend = () => {
				index += 1;
				if (index >= pieces.length) finish();
				else speakPiece(false);
			};
			utterance.onerror = (event) => {
				const code = event.error;
				if (code === "interrupted" || code === "canceled") {
					finish();
					return;
				}
				if (!retriedBare && (code === "synthesis-failed" || code === "voice-unavailable" || code === "language-unavailable" || code === "not-allowed" || code === "audio-busy")) {
					retriedBare = true;
					window.setTimeout(() => speakPiece(true), 60);
					return;
				}
				fail("This phone stopped the reading.");
			};
			try {
				synth.resume();
				synth.speak(utterance);
			} catch {
				fail("This phone stopped the reading.");
			}
		};
		speakPiece(false);
	});
}
/** Paste-ready Colab T4 / Kaggle T4x2 cell. Not executed in the browser. */
var FACTORY_CELL = `
# Aether Manhua Explanation Factory
# Colab T4 (15GB) or Kaggle T4x2 (30GB). Paste the whole cell and run.
# Printed Worker URL goes into the phone Settings. Nothing here is saved back to the phone.

import os, sys, json, uuid, time, shutil, threading, subprocess, base64, re
from pathlib import Path

PORT = 8787
ROOT = Path("/kaggle/working" if Path("/kaggle/working").exists() else "/content")
ROOT.mkdir(parents=True, exist_ok=True)
MODELS = ROOT / "models"
MODELS.mkdir(exist_ok=True)
OUT = ROOT / "aether_out"
OUT.mkdir(exist_ok=True)
TOKEN = os.environ.get("AETHER_TOKEN", "")
JOBS = {}
LATEST = {"preview": None, "mp4": None}
PANEL_CACHE = {}
PANEL_DIR = OUT / "panels"
VOICE_DIR = OUT / "voices"
CLIP_DIR = OUT / "clips"
for _folder in (PANEL_DIR, VOICE_DIR, CLIP_DIR):
    _folder.mkdir(exist_ok=True)
TIMING_PATH = OUT / "timing.json"
PAINTER = {"pipe": None, "img2img": None, "kind": "", "name": ""}
VISION = {"model": None}
OCR = {"reader": None}
FETCH_JOBS = {}
LLM = {"obj": None, "mode": "", "name": ""}

def pip_try(args):
    subprocess.call([sys.executable, "-m", "pip", "install", "-q", *args])

pip_try(["fastapi", "uvicorn", "edge-tts", "pillow", "requests", "huggingface_hub"])
try:
    import torch
    GPU_COUNT = torch.cuda.device_count() if torch.cuda.is_available() else 0
    GPU_NAMES = [torch.cuda.get_device_name(i) for i in range(GPU_COUNT)]
except Exception:
    torch = None
    GPU_COUNT = 0
    GPU_NAMES = []
print("GPUs", GPU_COUNT, GPU_NAMES, flush=True)
print("Image checkpoint", os.environ.get("AETHER_IMAGE_REPO", "cagliostrolab/animagine-xl-3.1"), flush=True)
print("Set AETHER_IMAGE_REPO to a Flux repo or a manhwa checkpoint before this cell if you do not want Animagine XL. Pollinations is only the fallback when that model cannot load.", flush=True)
print("Full GLM-5.2 4-bit GGUF is about 466GB and will not fit Colab T4 or Kaggle T4x2. gguf mode loads a 4-bit distill (default GLM-4-9B Q4) unless AETHER_GGUF_REPO is set. Flagship GLM-5.2 stays on the cloud key (Z.ai / OpenRouter / GitHub Models).", flush=True)
if shutil.which("ffmpeg") is None or shutil.which("ffprobe") is None:
    subprocess.call(["apt-get", "update", "-qq"])
    subprocess.call(["apt-get", "install", "-y", "-qq", "ffmpeg"])

def sh(args, **kw):
    subprocess.check_call(args, **kw)

def allowed(headers, token=""):
    if not TOKEN:
        return True
    presented = headers.get("x-aether-token", "") or token
    return presented == TOKEN

def han(text):
    return any("\\u4e00" <= ch <= "\\u9fff" for ch in text)

def load_llm(mode):
    if LLM["obj"] is not None and LLM["mode"] == mode:
        return LLM
    if mode == "gguf":
        # CUDA wheel first so Kaggle T4x2 / Colab T4 actually offload layers. CPU wheel is the fallback.
        cuda = subprocess.call([sys.executable, "-m", "pip", "install", "-q", "llama-cpp-python", "--extra-index-url", "https://abetlen.github.io/llama-cpp-python/whl/cu124"])
        if cuda != 0:
            os.environ["CMAKE_ARGS"] = "-DGGML_CUDA=on"
            os.environ["FORCE_CMAKE"] = "1"
            pip_try(["llama-cpp-python"])
        from llama_cpp import Llama
        gguf = next(MODELS.glob("*.gguf"), None)
        if gguf is None:
            from huggingface_hub import hf_hub_download
            repo = os.environ.get("AETHER_GGUF_REPO", "bartowski/glm-4-9b-chat-GGUF")
            name = os.environ.get("AETHER_GGUF_FILE", "glm-4-9b-chat-Q4_K_M.gguf")
            path = hf_hub_download(repo_id=repo, filename=name, local_dir=str(MODELS))
            gguf = Path(path)
        kwargs = {"model_path": str(gguf), "n_gpu_layers": -1, "n_ctx": 4096, "verbose": False}
        if GPU_COUNT >= 2:
            kwargs["tensor_split"] = [1.0 / GPU_COUNT] * GPU_COUNT
        llm = Llama(**kwargs)
        LLM.update(obj=llm, mode=mode, name=gguf.name)
        return LLM
    if mode == "airllm":
        pip_try(["airllm"])
        from airllm import AutoModel
        repo = os.environ.get("AETHER_AIR_REPO", "Qwen/Qwen2.5-14B-Instruct")
        model = AutoModel.from_pretrained(repo)
        LLM.update(obj=model, mode=mode, name=repo)
        return LLM
    pip_try(["transformers", "accelerate", "bitsandbytes"])
    from transformers import AutoModelForCausalLM, AutoTokenizer
    repo = os.environ.get("AETHER_FAST_REPO", "Qwen/Qwen2.5-14B-Instruct")
    tok = AutoTokenizer.from_pretrained(repo)
    model = AutoModelForCausalLM.from_pretrained(repo, device_map="auto", torch_dtype="auto")
    LLM.update(obj=(tok, model), mode="fast", name=repo)
    return LLM

def complete(mode, system, prompt):
    bundle = load_llm(mode if mode in ("gguf", "airllm", "fast") else "fast")
    user = system + "\\n\\n" + prompt
    if bundle["mode"] == "gguf":
        out = bundle["obj"].create_chat_completion(messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}], max_tokens=4096, temperature=0.4)
        return out["choices"][0]["message"]["content"]
    if bundle["mode"] == "airllm":
        model = bundle["obj"]
        tokens = model.tokenizer([user], return_tensors="pt")
        ids = tokens["input_ids"]
        if torch is not None and GPU_COUNT:
            ids = ids.cuda()
        gen = model.generate(ids, max_new_tokens=1200)
        return model.tokenizer.decode(gen[0], skip_special_tokens=True)
    tok, model = bundle["obj"]
    messages = [{"role": "system", "content": system}, {"role": "user", "content": prompt}]
    text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    batch = tok(text, return_tensors="pt").to(model.device)
    gen = model.generate(**batch, max_new_tokens=1200, do_sample=False)
    return tok.decode(gen[0][batch["input_ids"].shape[1]:], skip_special_tokens=True)

def ink_panel(prompt, dest, size):
    from PIL import Image, ImageDraw
    seed = abs(hash(prompt or "panel")) % 9973
    w, h = size
    im = Image.new("RGB", (w, h), (16, 12, 14))
    draw = ImageDraw.Draw(im, "RGBA")
    for band in range(16):
        y0 = int(h * band / 16)
        y1 = int(h * (band + 1) / 16) + 1
        shade = 20 + band * 6 + (seed % 18)
        draw.rectangle([0, y0, w, y1], fill=(shade, 16 + band * 2, 22 + (seed % 10), 255))
    moon = 64 + (seed % 48)
    mx = int(w * (0.58 + (seed % 17) / 100))
    my = int(h * 0.08)
    draw.ellipse([mx, my, mx + moon * 2, my + moon * 2], fill=(236, 220, 186, 235))
    ridge = int(h * (0.58 + (seed % 8) / 100))
    draw.polygon([(0, ridge + 80), (int(w * 0.35), ridge), (int(w * 0.62), ridge + 46), (w, ridge - 10), (w, h), (0, h)], fill=(12, 10, 14, 255))
    cx = int(w * (0.28 + (seed % 40) / 100))
    cy = int(h * 0.62)
    robe = (120 + (seed % 90), 36, 28, 255)
    draw.polygon([(cx - 46, cy + 220), (cx, cy + 36), (cx + 46, cy + 220)], fill=robe)
    draw.ellipse([cx - 22, cy - 10, cx + 22, cy + 36], fill=(232, 214, 190, 255))
    if seed % 2 == 0:
        draw.line([(cx + 30, cy + 20), (cx + 150, cy - 80)], fill=(210, 210, 220, 255), width=6)
    im.convert("RGB").save(dest)
    return dest

def fetch_image(raw, dest):
    if isinstance(raw, str) and raw.startswith("data:"):
        b64 = raw.split(",", 1)[-1]
        dest.write_bytes(base64.b64decode(b64))
        return True
    if isinstance(raw, str) and raw.startswith("http"):
        import requests
        res = requests.get(raw, timeout=40)
        res.raise_for_status()
        if len(res.content) < 64:
            return False
        dest.write_bytes(res.content)
        return True
    return False

def safe_id(value):
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "", str(value or "panel"))[:80]
    return cleaned or "panel"

def load_timing():
    if TIMING_PATH.exists():
        try:
            data = json.loads(TIMING_PATH.read_text())
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}

def save_timing(data):
    TIMING_PATH.write_text(json.dumps(data))

def load_painter():
    if PAINTER["pipe"] is not None:
        return PAINTER
    if GPU_COUNT < 1 or torch is None:
        raise RuntimeError("no GPU for the manhwa checkpoint")
    pip_try(["diffusers", "transformers", "accelerate", "safetensors", "sentencepiece", "protobuf"])
    repo = os.environ.get("AETHER_IMAGE_REPO", "cagliostrolab/animagine-xl-3.1")
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if "flux" in repo.lower():
        from diffusers import FluxPipeline
        pipe = FluxPipeline.from_pretrained(repo, torch_dtype=torch.bfloat16, token=token)
        pipe.enable_model_cpu_offload()
        img2img = None
        try:
            from diffusers import FluxImg2ImgPipeline
            img2img = FluxImg2ImgPipeline(**pipe.components)
        except Exception as exc:
            print("flux img2img unavailable", exc, flush=True)
        PAINTER.update(pipe=pipe, img2img=img2img, kind="flux", name=repo)
        return PAINTER
    from diffusers import StableDiffusionXLPipeline, StableDiffusionXLImg2ImgPipeline
    try:
        pipe = StableDiffusionXLPipeline.from_pretrained(repo, torch_dtype=torch.float16, variant="fp16", use_safetensors=True, token=token)
    except Exception:
        pipe = StableDiffusionXLPipeline.from_pretrained(repo, torch_dtype=torch.float16, use_safetensors=True, token=token)
    pipe.enable_model_cpu_offload()
    img2img = StableDiffusionXLImg2ImgPipeline(**pipe.components)
    PAINTER.update(pipe=pipe, img2img=img2img, kind="sdxl", name=repo)
    return PAINTER

def paint_local(prompt, dest, size, reference):
    from PIL import Image
    bundle = load_painter()
    w = max(512, (min(size[0], 832) // 64) * 64)
    h = max(768, (min(size[1], 1216) // 64) * 64)
    if bundle["kind"] == "flux":
        if reference and bundle.get("img2img") is not None:
            ref = Image.open(reference).convert("RGB").resize((w, h))
            image = bundle["img2img"](prompt=prompt, image=ref, strength=0.4, guidance_scale=3.5, num_inference_steps=4, height=h, width=w, max_sequence_length=256).images[0]
        else:
            image = bundle["pipe"](prompt, height=h, width=w, guidance_scale=3.5, num_inference_steps=4, max_sequence_length=256).images[0]
    elif reference and bundle.get("img2img") is not None:
        ref = Image.open(reference).convert("RGB").resize((w, h))
        image = bundle["img2img"](prompt=prompt, image=ref, strength=0.42, num_inference_steps=28, guidance_scale=6.5, height=h, width=w).images[0]
    else:
        image = bundle["pipe"](prompt=prompt, num_inference_steps=28, guidance_scale=6.5, height=h, width=w).images[0]
    image.convert("RGB").save(dest)
    return bundle["kind"] + ("+ref" if reference else "")

def paint_prompt(prompt, dest, size, reference=None):
    import requests, urllib.parse
    locked = "Vertical colored manhwa, clean ink, dramatic lighting, consistent character, no text, no letters, no watermark, no speech bubbles. " + (prompt or "panel")
    try:
        kind = paint_local(locked, dest, size, reference)
        print("checkpoint panel", kind, flush=True)
        return kind
    except Exception as exc:
        print("checkpoint skipped", exc, flush=True)
    try:
        url = "https://image.pollinations.ai/prompt/" + urllib.parse.quote(locked[:480]) + "?width=%d&height=%d&nologo=true&model=flux" % (min(size[0], 768), min(size[1], 1152))
        res = requests.get(url, timeout=90)
        kind = res.headers.get("content-type", "")
        if res.ok and kind.startswith("image") and len(res.content) > 1000:
            dest.write_bytes(res.content)
            print("pollinations panel — faces can drift", flush=True)
            return "pollinations"
    except Exception as exc:
        print("pollinations skipped", exc, flush=True)
    ink_panel(prompt, dest, size)
    return "ink"

def materialize_reference(payload):
    dest = OUT / "ref-face.png"
    raw_b64 = payload.get("referenceBase64") or ""
    raw = payload.get("reference") or ""
    try:
        if isinstance(raw_b64, str) and len(raw_b64) > 80:
            dest.write_bytes(base64.b64decode(raw_b64))
            return dest
        if isinstance(raw, str) and (raw.startswith("http") or raw.startswith("data:")) and fetch_image(raw, dest):
            return dest
    except Exception as exc:
        print("reference skipped", exc, flush=True)
    return None

def ensure_panel(scene, dest, size, revoice):
    sid = safe_id(scene.get("id") or dest.stem)
    stable = PANEL_DIR / f"{sid}.png"
    raw = scene.get("image_url") or ""
    def take_remote():
        if isinstance(raw, str) and (raw.startswith("http") or raw.startswith("data:")):
            try:
                if fetch_image(raw, stable):
                    shutil.copy(stable, dest)
                    PANEL_CACHE[sid] = str(stable)
                    return True
            except Exception as exc:
                print("panel fetch failed", exc, flush=True)
        return False
    if not revoice and take_remote():
        return "fetched"
    if stable.exists() and stable.stat().st_size > 64:
        shutil.copy(stable, dest)
        PANEL_CACHE[sid] = str(stable)
        return "kept"
    if take_remote():
        return "fetched"
    cached = PANEL_CACHE.get(sid)
    if cached and Path(cached).exists():
        shutil.copy(cached, stable)
        shutil.copy(stable, dest)
        return "cache"
    if revoice:
        raise RuntimeError("Picture missing for %s. Re-voice will not draw a new one." % sid)
    tiles = scene.get("tiles") or [{}]
    prompt = tiles[0].get("prompt") if tiles and isinstance(tiles[0], dict) else ""
    reference = materialize_reference({"reference": scene.get("reference") or ""})
    paint_prompt(prompt or "panel", stable, size, reference)
    shutil.copy(stable, dest)
    PANEL_CACHE[sid] = str(stable)
    return "painted"

def voice_file_name(sid, lang, voice):
    slug = re.sub(r"[^A-Za-z0-9]", "", str(voice or ""))[:32] or "male"
    return f"{safe_id(sid)}_{lang}_{slug}.mp3"

def speak_to(text, voice, dest):
    import edge_tts, asyncio
    last = "edge refused"
    for attempt in range(3):
        try:
            asyncio.run(edge_tts.Communicate((text or " ")[:700], voice).save(str(dest)))
            if dest.exists() and dest.stat().st_size > 200:
                return "edge"
        except Exception as exc:
            last = str(exc)
            print("edge retry", attempt, exc, flush=True)
            time.sleep(1.2)
    espeak = shutil.which("espeak-ng") or shutil.which("espeak")
    if not espeak:
        subprocess.call(["apt-get", "install", "-y", "-qq", "espeak-ng"])
        espeak = shutil.which("espeak-ng") or shutil.which("espeak")
    if not espeak:
        raise RuntimeError("Edge TTS refused and no local voice was available. " + last[:180])
    wav = dest.with_suffix(".wav")
    code = "hi" if str(voice).startswith("hi-") else "en"
    sh([espeak, "-v", code, "-w", str(wav), (text or " ")[:500]])
    sh(["ffmpeg", "-y", "-i", str(wav), "-c:a", "libmp3lame", "-q:a", "4", str(dest)])
    print("local voice fallback", code, flush=True)
    return "espeak"

def panel_clip(sid, img, hold, size, sfx, revoice=False):
    W, H = size
    meta_path = CLIP_DIR / f"{sid}.json"
    dest = CLIP_DIR / f"{sid}.mp4"
    prev = None
    if meta_path.exists():
        try:
            prev = json.loads(meta_path.read_text())
        except Exception:
            prev = None
    old = float(prev.get("hold") or 0) if isinstance(prev, dict) else 0
    if prev and dest.exists() and hold <= old + 0.08:
        return dest
    if revoice and prev and dest.exists() and hold > old:
        extra = max(hold - old, 0.04)
        extended = CLIP_DIR / f"{sid}-hold.mp4"
        sh(["ffmpeg", "-y", "-i", str(dest), "-vf", f"tpad=stop_mode=clone:stop_duration={extra:.3f}", "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(extended)])
        shutil.move(str(extended), str(dest))
        meta_path.write_text(json.dumps({"hold": round(hold, 3)}))
        print("extended hold only", sid, flush=True)
        return dest
    frames = max(int(hold * 30), 36)
    shake = "shake" in (sfx or "").lower() or sfx in ("CRACK", "BOOM", "SHING")
    vf = f"scale={W*2}:{H*2}:force_original_aspect_ratio=increase,crop={W*2}:{H*2},zoompan=z='min(1.0+0.0012*on,1.22)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)+on*0.45':d={frames}:s={W}x{H}:fps=30"
    if shake:
        vf += f",crop=iw-24:ih-24:12+8*sin(n*2):12+6*cos(n*3),scale={W}:{H}"
    vf += ",fade=t=in:st=0:d=0.18,format=yuv420p"
    sh(["ffmpeg", "-y", "-loop", "1", "-i", str(img), "-vf", vf, "-t", str(round(hold, 3)), "-c:v", "libx264", "-pix_fmt", "yuv420p", str(dest)])
    meta_path.write_text(json.dumps({"hold": round(hold, 3)}))
    return dest

def vision_check(prompt, image_path):
    from PIL import Image
    image = Image.open(image_path).convert("RGB")
    try:
        if VISION["model"] is None:
            pip_try(["transformers", "accelerate", "einops", "pyvips"])
            repo = os.environ.get("AETHER_VISION_REPO", "vikhyatk/moondream2")
            from transformers import AutoModelForCausalLM
            dtype = torch.float16 if GPU_COUNT and torch is not None else None
            model = AutoModelForCausalLM.from_pretrained(repo, trust_remote_code=True, torch_dtype=dtype)
            if GPU_COUNT and torch is not None:
                model = model.to("cuda")
            VISION["model"] = model
        model = VISION["model"]
        question = "Look at the face, hair, outfit, and scene. Does this image match the description? First word yes or no, then one sentence. Description: " + (prompt or "")[:700]
        if hasattr(model, "query"):
            answer = model.query(image, question)
            text = answer.get("answer") if isinstance(answer, dict) else str(answer)
        else:
            encoded = model.encode_image(image)
            tok = getattr(model, "tokenizer", None)
            text = str(model.answer_question(encoded, question, tok))
        cleaned = text.strip()
        match = cleaned.lower().startswith("yes")
        return {"match": bool(match), "note": cleaned[:240]}
    except Exception as exc:
        print("vision model skipped", exc, flush=True)
    try:
        pip_try(["transformers"])
        from transformers import CLIPModel, CLIPProcessor
        clip_id = "openai/clip-vit-base-patch32"
        if VISION.get("clip") is None:
            VISION["clip"] = (
                CLIPModel.from_pretrained(clip_id),
                CLIPProcessor.from_pretrained(clip_id),
            )
        model, processor = VISION["clip"]
        inputs = processor(text=[(prompt or "manhwa panel")[:300], "an empty wall"], images=image, return_tensors="pt", padding=True)
        score = float(model(**inputs).logits_per_image.softmax(dim=1)[0, 0])
        return {"match": score >= 0.24, "note": "CLIP score %.2f. The face model did not load, so this is a weak check." % score}
    except Exception as exc:
        return {"match": "skipped", "note": ("Vision did not load. " + str(exc))[:240]}

def read_bubbles(path):
    try:
        if OCR["reader"] is None:
            pip_try(["easyocr"])
            import easyocr
            OCR["reader"] = easyocr.Reader(["ch_sim", "en"], gpu=GPU_COUNT > 0)
        rows = OCR["reader"].readtext(str(path))
    except Exception as exc:
        print("ocr skipped", exc, flush=True)
        return "", ""
    from PIL import Image
    height = Image.open(path).size[1] or 1
    bubbles = []
    asides = []
    for box, text, conf in rows:
        if conf < 0.35 or not str(text).strip():
            continue
        ys = [point[1] for point in box]
        cy = sum(ys) / max(len(ys), 1) / height
        line = str(text).strip()
        if cy < 0.72 and len(line) <= 80:
            bubbles.append(line)
        else:
            asides.append(line)
    return " ".join(bubbles)[:400], " ".join(asides)[:400]

def extract_html(html, page):
    import urllib.parse
    title_m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    title = re.sub("<[^>]+>", " ", title_m.group(1) if title_m else "")
    title = re.sub(r"\\s+", " ", title).strip()[:180]
    body = re.sub(r"<script[\\s\\S]*?<\/script>", " ", html, flags=re.I)
    body = re.sub(r"<style[\\s\\S]*?</style>", " ", body, flags=re.I)
    panels = []
    for match in re.finditer(r"<img\\b[^>]*>", body, re.I):
        tag = match.group(0)
        src_m = re.search(r"(?:data-src|data-original|src)=[\\"']([^\\"']+)[\\"']", tag, re.I)
        if not src_m:
            continue
        src = src_m.group(1).strip()
        if src.startswith("data:") or re.search(r"logo|icon|sprite|avatar|banner|ads?", src, re.I):
            continue
        src = urllib.parse.urljoin(page, src)
        alt_m = re.search(r"alt=[\\"']([^\\"']*)[\\"']", tag, re.I)
        alt = alt_m.group(1).strip() if alt_m else ""
        after = re.sub("<[^>]+>", " ", body[match.end(): match.end() + 500])
        after = re.sub(r"\\s+", " ", after).strip()[:400]
        panels.append({"src": src, "bubble": alt[:180], "aside": after, "text": (alt + " " + after).strip()[:500]})
        if len(panels) >= 80:
            break
    text = re.sub("<[^>]+>", "\\n", body)
    lines = []
    for line in text.splitlines():
        clean = re.sub(r"\\s+", " ", line).strip()
        if not clean or re.search(r"next chapter|previous chapter|wtr-lab|sign in", clean, re.I):
            continue
        lines.append(clean)
    return title, "\\n".join(lines)[:20000], panels

def run_fetch(job_id, urls, cookie):
    import requests
    row = FETCH_JOBS[job_id]
    headers = {"User-Agent": "Mozilla/5.0"}
    if cookie:
        headers["Cookie"] = cookie
    pages = []
    try:
        for index, url in enumerate(urls, 1):
            row.update(label="Fetching %d of %d" % (index, len(urls)), progress=int(100 * index / len(urls)))
            try:
                res = requests.get(url, headers=headers, timeout=40)
                res.raise_for_status()
                title, text, panels = extract_html(res.text, url)
                pages.append({"url": url, "ok": True, "title": title, "text": text, "panels": panels})
            except Exception as exc:
                pages.append({"url": url, "ok": False, "error": str(exc)[:200], "title": "", "text": "", "panels": []})
            row["pages"] = pages
        row.update(status="done", progress=100, label="Fetch ready", error="")
    except Exception as exc:
        row.update(status="error", error=str(exc)[:300])

def place_panel(scene, dest, size, revoice):
    ensure_panel(scene, dest, size, revoice)


def save_image(raw, dest, size=(1920, 1080)):
    try:
        if fetch_image(raw, dest):
            return dest
    except Exception as exc:
        print("panel fetch failed", exc, flush=True)
    paint_prompt(raw if isinstance(raw, str) else "", dest, size)
    return dest

def render_job(job_id, packet):
    row = JOBS[job_id]
    try:
        aspect = packet.get("aspect") or "9:16"
        vertical = aspect != "16:9"
        W, H = (1080, 1920) if vertical else (1920, 1080)
        revoice = packet.get("pass") == "revoice"
        voice_id = (packet.get("voice") or "").strip() or ("hi-IN-MadhurNeural" if packet.get("language") == "hi" else "en-US-ChristopherNeural")
        chapters = packet.get("chapters") or []
        scenes = []
        for chapter in chapters:
            for scene in chapter.get("scenes") or []:
                scenes.append(scene)
        if not scenes:
            raise RuntimeError("Job packet has no scenes.")
        row.update(progress=8, label="Re-voicing" if revoice else "Voice")
        repo = packet.get("image_repo") or ""
        if isinstance(repo, str) and repo.strip() and not revoice:
            os.environ["AETHER_IMAGE_REPO"] = repo.strip()[:200]
        timing = load_timing()
        audio_parts = []
        clips = []
        cues = []
        voices = {}
        cursor = 0.0
        lang = packet.get("language") or "en"
        for index, scene in enumerate(scenes, 1):
            bubble = scene.get("bubble") or {}
            spoken = " ".join(part for part in [scene.get("caption") or "", bubble.get("text") or ""] if part).strip() or " "
            sid = safe_id(scene.get("id") or ("p%d" % index))
            voice = VOICE_DIR / voice_file_name(sid, lang, voice_id)
            if not (voice.exists() and voice.stat().st_size > 200):
                speak_to(spoken[:700], voice_id, voice)
            voices[sid] = "/api/v1/voices/" + voice.name
            trimmed = OUT / f"{job_id}-v{index}.trim.mp3"
            sh(["ffmpeg", "-y", "-i", str(voice), "-af", "silenceremove=start_periods=1:start_silence=0.02:start_threshold=-45dB:stop_periods=0,apad=pad_dur=0.12", str(trimmed)])
            probe = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(trimmed)], text=True).strip()
            audio_hold = max(float(probe or "1.4"), 1.2)
            saved = timing.get(sid)
            try:
                packet_hold = float(scene.get("hold_sec") or 0)
            except Exception:
                packet_hold = 0
            base = float(saved) if saved is not None else (packet_hold if packet_hold > 0 else audio_hold)
            hold = max(base, audio_hold)
            if saved is None or hold > float(saved) + 0.05:
                timing[sid] = round(float(hold), 3)
                save_timing(timing)
            audio_parts.append(trimmed)
            img = OUT / f"{job_id}-p{index}.png"
            ensure_panel(scene, img, (W, H), revoice)
            clip = panel_clip(sid, img, hold, (W, H), scene.get("sfx") or "", revoice)
            clips.append(clip)
            cues.append((cursor, cursor + hold, spoken))
            cursor += hold
            row.update(progress=10 + int(70 * index / len(scenes)), label=("Re-voicing" if revoice else f"Panel {index}"), timing=timing, voices=voices)
        alist = OUT / f"{job_id}-alist.txt"
        alist.write_text("".join(f"file '{part.resolve()}'\\n" for part in audio_parts))
        voice = OUT / f"{job_id}-voice.mp3"
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(alist), "-c:a", "libmp3lame", "-q:a", "4", str(voice)])
        duration = max(cursor, 1.2)
        lst = OUT / f"{job_id}-list.txt"
        lst.write_text("".join(f"file '{c.resolve()}'\\n" for c in clips))
        silent = OUT / f"{job_id}-silent.mp4"
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(silent)])
        def ts(sec):
            h = int(sec // 3600); m = int((sec % 3600) // 60); s = sec % 60
            return f"{h}:{m:02d}:{s:05.2f}"
        events = []
        srt = []
        for i, (a, b, phrase) in enumerate(cues, 1):
            safe = phrase.replace("{", "(").replace("}", ")").replace("\\n", " ")
            events.append("Dialogue: 0,%s,%s,Default,,0,0,0,,%s" % (ts(a), ts(b), safe))
            def srt_ts(sec):
                ms = int(round((sec - int(sec)) * 1000))
                return f"{int(sec // 3600):02d}:{int((sec % 3600) // 60):02d}:{int(sec % 60):02d},{ms:03d}"
            srt.append(f"{i}\\n{srt_ts(a)} --> {srt_ts(b)}\\n{safe}\\n")
        (OUT / f"{job_id}.srt").write_text("\\n".join(srt))
        align = 2
        margin = 220 if vertical else 80
        ass = OUT / f"{job_id}.ass"
        ass.write_text("\\n".join([
            "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "",
            "[V4+ Styles]",
            "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
            f"Style: Default,Arial,{48 if vertical else 36},&H00F3EADB,&H0014110F,&H8014110F,-1,0,3,8,0,{align},48,48,{margin},1",
            "", "[Events]",
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
            *events, "",
        ]))
        bgm = OUT / f"{job_id}-bgm.wav"
        dur = duration + 0.4
        sh(["ffmpeg", "-y", "-f", "lavfi", "-i", f"sine=frequency=55:duration={dur}", "-f", "lavfi", "-i", f"sine=frequency=82.5:duration={dur}", "-f", "lavfi", "-i", f"sine=frequency=110:duration={dur}:sample_rate=44100", "-filter_complex", f"[0:a]volume=0.35[a];[1:a]volume=0.16[b];[2:a]volume=0.08[c];[a][b][c]amix=inputs=3:normalize=0,lowpass=f=240,volume=0.22,afade=t=in:st=0:d=0.4,afade=t=out:st={max(dur-0.6,0.2)}:d=0.5", str(bgm)])
        mastered = OUT / f"{job_id}-mix.m4a"
        sh(["ffmpeg", "-y", "-i", str(voice), "-i", str(bgm), "-filter_complex", "[1:a]volume=0.18[b];[0:a][b]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=280[duck];[0:a][duck]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95", "-c:a", "aac", str(mastered)])
        final = OUT / f"{job_id}.mp4"
        sub = str(ass).replace(":", "\\\\:").replace("'", "\\\\'")
        sh(["ffmpeg", "-y", "-i", str(silent), "-i", str(mastered), "-vf", f"ass={sub}", "-c:v", "libx264", "-c:a", "aac", "-shortest", "-movflags", "+faststart", str(final)])
        preview = OUT / f"{job_id}-preview.mp4"
        sh(["ffmpeg", "-y", "-i", str(final), "-t", "6", "-c:v", "libx264", "-c:a", "aac", "-movflags", "+faststart", str(preview)])
        lang = packet.get("language") or "en"
        stable = OUT / f"master_{lang}.mp4"
        shutil.copy(final, stable)
        srt_stable = OUT / f"captions_{lang}.srt"
        shutil.copy(OUT / f"{job_id}.srt", srt_stable)
        LATEST["preview"] = preview
        LATEST["mp4"] = str(stable)
        LATEST[f"master_{lang}"] = str(stable)
        LATEST[f"srt_{lang}"] = str(srt_stable)
        row.update(status="done", progress=100, label="Ready", mp4=str(stable), preview=str(preview), error="", timing=timing, voices=voices)
    except Exception as exc:
        row.update(status="error", error=str(exc)[:500], label="Re-voicing" if packet.get("pass") == "revoice" else "")

def youtube_upload(token, path, meta):
    import requests
    size = os.path.getsize(path)
    body = {
        "snippet": {
            "title": (meta.get("title") or "Manhua explanation")[:100],
            "description": (meta.get("description") or "")[:5000],
            "tags": list(meta.get("tags") or [])[:15],
            "categoryId": "24",
        },
        "status": {"privacyStatus": meta.get("privacy") or "private", "selfDeclaredMadeForKids": False},
    }
    init = requests.post(
        "https://www.googleapis.com/upload/youtube/v3/videos",
        params={"uploadType": "resumable", "part": "snippet,status"},
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=UTF-8",
            "X-Upload-Content-Type": "video/mp4",
            "X-Upload-Content-Length": str(size),
        },
        json=body, timeout=60,
    )
    init.raise_for_status()
    loc = init.headers["Location"]
    chunk_size = 8 * 1024 * 1024
    offset = 0
    video_id = None
    with open(path, "rb") as handle:
        while offset < size:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            end = offset + len(chunk) - 1
            put = requests.put(
                loc,
                data=chunk,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "video/mp4",
                    "Content-Length": str(len(chunk)),
                    "Content-Range": f"bytes {offset}-{end}/{size}",
                },
                timeout=180,
            )
            if put.status_code not in (200, 201, 308):
                put.raise_for_status()
            offset = end + 1
            if put.status_code in (200, 201):
                video_id = put.json().get("id")
    if not video_id:
        raise RuntimeError("YouTube did not return a video id.")
    return video_id

def youtube_captions(token, video_id, srt_path, language):
    import requests
    meta = {"snippet": {"videoId": video_id, "language": language, "name": "English" if language == "en" else "Hindi", "isDraft": False}}
    with open(srt_path, "rb") as handle:
        files = {
            "snippet": ("snippet.json", json.dumps(meta), "application/json"),
            "file": (f"captions-{language}.srt", handle, "application/octet-stream"),
        }
        res = requests.post(
            "https://www.googleapis.com/upload/youtube/v3/captions",
            params={"part": "snippet", "uploadType": "multipart"},
            headers={"Authorization": f"Bearer {token}"},
            files=files,
            timeout=90,
        )
    if res.status_code >= 400:
        print("captions skipped", res.status_code, res.text[:180], flush=True)

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/api/v1/health")
def health():
    return {"ok": True, "gpus": GPU_COUNT, "names": GPU_NAMES, "engine": "aether-manhua", "local_ai": True}

@app.post("/api/v1/llm")
async def llm(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    mode = payload.get("model_mode") or "gguf"
    text = complete(mode, payload.get("system") or "", payload.get("prompt") or "")
    return {"text": text, "model": LLM.get("name"), "mode": mode}

@app.post("/api/v1/direct")
async def direct(request: Request):
    return await llm(request)

@app.post("/api/v1/jobs")
async def create_job(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    packet = await request.json()
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"id": job_id, "status": "running", "progress": 5, "label": "Queued", "error": "", "mp4": None, "preview": None}
    threading.Thread(target=render_job, args=(job_id, packet), daemon=True).start()
    return {"id": job_id, "status": "queued"}

@app.get("/api/v1/jobs/{job_id}")
def job_status(job_id: str):
    row = JOBS.get(job_id)
    if not row:
        raise HTTPException(404, "missing job")
    return {"id": job_id, "status": row["status"], "progress": row["progress"], "label": row["label"], "error": row["error"], "mp4_url": f"/api/v1/jobs/{job_id}/mp4" if row["status"] == "done" else None, "timing": row.get("timing") or {}, "voices": row.get("voices") or {}}

@app.get("/api/v1/jobs/{job_id}/mp4")
def job_mp4(job_id: str):
    row = JOBS.get(job_id)
    if not row or not row.get("mp4"):
        raise HTTPException(404, "mp4 not ready")
    return FileResponse(row["mp4"], media_type="video/mp4")

@app.get("/api/v1/preview.mp4")
def preview():
    path = LATEST.get("preview")
    if not path or not Path(path).exists():
        raise HTTPException(404, "preview not ready")
    return FileResponse(path, media_type="video/mp4")

@app.get("/api/v1/masters/{lang}.mp4")
def master_file(lang: str, request: Request):
    if lang not in ("en", "hi"):
        raise HTTPException(404, "language")
    if not allowed(request.headers, request.query_params.get("token", "")):
        raise HTTPException(401, "token")
    path = LATEST.get(f"master_{lang}")
    if not path or not Path(path).exists():
        raise HTTPException(404, "that language master is not ready")
    return FileResponse(path, media_type="video/mp4", filename=f"master_{lang}.mp4")

@app.post("/api/v1/check")
async def check_panel(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    dest = OUT / "check-once.png"
    raw = payload.get("imageBase64") or ""
    try:
        if isinstance(raw, str) and len(raw) > 80:
            dest.write_bytes(base64.b64decode(raw))
        elif not fetch_image(payload.get("imageUrl") or "", dest):
            return {"match": "skipped", "note": "No picture reached the checker."}
    except Exception as exc:
        return {"match": "skipped", "note": str(exc)[:180]}
    verdict = vision_check(payload.get("prompt") or "", dest)
    if verdict["match"] is True:
        return {"match": "yes", "note": verdict["note"]}
    if verdict["match"] is False:
        return {"match": "no", "note": verdict["note"]}
    return {"match": "skipped", "note": verdict["note"]}

@app.post("/api/v1/paint")
async def paint(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    repo = (payload.get("repo") or "").strip()
    if repo:
        wanted = repo[:200]
        if PAINTER.get("name") != wanted:
            PAINTER.update(pipe=None, img2img=None, kind="", name="")
        os.environ["AETHER_IMAGE_REPO"] = wanted
    dest = OUT / "paint-once.png"
    reference = materialize_reference(payload)
    mode = paint_prompt(payload.get("prompt") or "panel", dest, (832, 1216), reference)
    return {"imageBase64": base64.b64encode(dest.read_bytes()).decode(), "mimeType": "image/png", "fallback": mode == "pollinations", "engine": mode, "referenceUsed": bool(reference)}

@app.post("/api/v1/speak")
async def speak(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    text = (payload.get("text") or " ")[:700]
    lang = "hi" if payload.get("language") == "hi" else "en"
    voice = payload.get("voice") or ("hi-IN-MadhurNeural" if lang == "hi" else "en-US-ChristopherNeural")
    sid = safe_id(payload.get("sceneId") or "line")
    dest = VOICE_DIR / voice_file_name(sid, lang, voice)
    if not (dest.exists() and dest.stat().st_size > 200 and not payload.get("force")):
        speak_to(text, voice, dest)
    data = dest.read_bytes()
    encoded = base64.b64encode(data).decode() if len(data) < 1_500_000 else ""
    return {"url": "/api/v1/voices/" + dest.name, "audioBase64": encoded, "mimeType": "audio/mpeg"}

@app.get("/api/v1/voices/{name}")
def voice_file(name: str, request: Request):
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,120}", name):
        raise HTTPException(404, "voice")
    if not allowed(request.headers, request.query_params.get("token", "")):
        raise HTTPException(401, "token")
    path = VOICE_DIR / name
    if not path.exists():
        raise HTTPException(404, "voice not saved")
    return FileResponse(path, media_type="audio/mpeg")

@app.post("/api/v1/fetch")
async def start_fetch(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    urls = []
    for item in payload.get("urls") or []:
        if isinstance(item, str) and item.startswith("http") and len(urls) < 220:
            urls.append(item[:500])
    if not urls:
        raise HTTPException(400, "no urls")
    job_id = uuid.uuid4().hex[:12]
    FETCH_JOBS[job_id] = {"id": job_id, "status": "running", "progress": 1, "label": "Fetching", "error": "", "pages": []}
    threading.Thread(target=run_fetch, args=(job_id, urls, str(payload.get("cookie") or "")[:4000]), daemon=True).start()
    return {"id": job_id, "status": "queued"}

@app.get("/api/v1/fetch/{job_id}")
def fetch_status(job_id: str):
    if not re.fullmatch(r"[A-Za-z0-9]{6,32}", job_id):
        raise HTTPException(404, "missing fetch")
    row = FETCH_JOBS.get(job_id)
    if not row:
        raise HTTPException(404, "missing fetch")
    return {"id": job_id, "status": row["status"], "progress": row["progress"], "label": row["label"], "error": row["error"], "pages": row.get("pages") or []}

@app.post("/api/v1/ocr")
async def ocr(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    panels = []
    for item in (payload.get("images") or [])[:8]:
        if not isinstance(item, dict):
            continue
        dest = OUT / f"ocr-{len(panels)}.png"
        url = item.get("url") or ""
        raw_b64 = item.get("imageBase64") or ""
        try:
            if isinstance(raw_b64, str) and len(raw_b64) > 80:
                dest.write_bytes(base64.b64decode(raw_b64))
            elif not isinstance(url, str) or not fetch_image(url, dest):
                panels.append({"id": str(item.get("id") or ""), "bubble": "", "aside": "", "error": "image did not load"})
                continue
        except Exception as exc:
            panels.append({"id": str(item.get("id") or ""), "bubble": "", "aside": "", "error": str(exc)[:120]})
            continue
        bubble, aside = read_bubbles(dest)
        panels.append({"id": str(item.get("id") or ""), "bubble": bubble, "aside": aside})
    return {"panels": panels}

@app.post("/api/v1/youtube-upload")
async def upload(request: Request):
    if not allowed(request.headers):
        raise HTTPException(401, "token")
    payload = await request.json()
    job_id = payload.get("jobId") or ""
    row = JOBS.get(job_id) or {}
    path = row.get("mp4") or LATEST.get(f"master_{payload.get('language') or 'en'}") or LATEST.get("mp4")
    if not path:
        raise HTTPException(404, "render the video first")
    video_id = youtube_upload(payload.get("accessToken") or "", path, payload)
    lang = payload.get("language") or "en"
    srt = LATEST.get(f"srt_{lang}")
    if srt and Path(srt).exists():
        try:
            youtube_captions(payload.get("accessToken") or "", video_id, srt, lang)
        except Exception as exc:
            print("captions skipped", exc, flush=True)
    return {"watchUrl": f"https://www.youtube.com/watch?v={video_id}"}

def boot():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")

threading.Thread(target=boot, daemon=True).start()
time.sleep(1.5)
bin_path = shutil.which("cloudflared")
if not bin_path:
    dest = Path("/tmp/cloudflared")
    subprocess.check_call(["curl", "-fsSL", "-o", str(dest), "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"])
    dest.chmod(0o755)
    bin_path = str(dest)
log = ROOT / "tunnel.log"
proc = subprocess.Popen([bin_path, "tunnel", "--url", f"http://127.0.0.1:{PORT}", "--no-autoupdate"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
url = ""
for _ in range(80):
    line = proc.stdout.readline() if proc.stdout else ""
    if not line:
        time.sleep(0.2)
        continue
    log.write_text(log.read_text() + line if log.exists() else line)
    if "trycloudflare.com" in line:
        start = line.find("https://")
        if start >= 0:
            url = line[start:].strip().split()[0]
            break
print("WORKER_URL", url or "tunnel not ready yet — read aether tunnel log", flush=True)
print("Connection Done — paste WORKER_URL into the phone. Keys stay on the phone.", flush=True)
`.trim();
/** Spoken line for the bubble. Drops a leading "Name:" so the speaker chip is not printed twice. */
function dialogueWithoutSpeaker(scene) {
	const line = scene.dialogue.trim();
	const speaker = scene.speaker.trim();
	if (!line || !speaker) return line;
	const escaped = speaker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	return line.replace(new RegExp(`^${escaped}\\s*[:\\-—–]\\s*`, "i"), "").trim() || line;
}
function youtubePrivacy(value) {
	return value === "public" || value === "unlisted" || value === "private" ? value : "private";
}
var SAMPLE_TEXT = `The Lantern Debt

Rain argued with the lanterns on Old Bridge. Ren wore a torn saffron robe over black, a thin scar on his left cheek, and he would not look at the water.

Ren: The pendant cracked because I paid the wrong debt.

He opened his hands. A pale-green jade glowed, and blood threaded his thumb. The glow remembered a name he had tried to forget.

Across the cedar mist, Shao waited with her spear. Silver hair knotted high, black armor, a calm that made the fog step aside.

Shao: Your soul can cross. That body cannot.

Lightning opened the palace gate. Ren stood in the tearing robe. Shao kept the spear lowered, not kind. Between them the debt finally had a face.`;
var LOOK = "young man, half-tied black hair, thin scar on the left cheek, torn saffron-yellow robe over black";
var SAMPLE = {
	title: "The Lantern Debt",
	source: "sample",
	text: SAMPLE_TEXT,
	logline: "A cracked jade pendant calls in a debt on a rain-soaked bridge, and the body is not allowed to follow the soul.",
	characters: [{
		id: "ren",
		name: "Ren",
		soul: "Pays what he owes, even the wrong bill. Refuses to look at the water. The debt stays with him if the body changes.",
		vessel: "Living body on the bridge: torn saffron robe, scar on the left cheek. Shao says this body cannot cross.",
		look: LOOK
	}, {
		id: "shao",
		name: "Shao",
		soul: "The boundary. Calm enough to part fog. She will let a soul through and stop the body.",
		vessel: "Silver-white hair in a high knot, black layered armor, long spear. No swap in this chapter.",
		look: "woman, silver-white hair in a high knot, black layered armor, long spear, severe calm face"
	}],
	timeline: [
		"Bridge: rain, lanterns, robe already torn, Ren will not face the water.",
		"Jade: pendant cracked and glowing, blood on the thumb.",
		"Cedar: Shao's vessel unchanged, spear held, fog steps aside.",
		"Gate: lightning, robe tearing harder, spear lowered, souls still in their own vessels."
	],
	scenes: [
		{
			id: "s1",
			caption: "Rain argued with the lanterns. Ren would not look at the water.",
			dialogue: "The pendant cracked because I paid the wrong debt.",
			speaker: "Ren",
			sfx: "",
			state: "Torn saffron robe, night rain, scar visible",
			imagePrompt: `Vertical manhua panel, no text. Night rain on a stone bridge, paper lanterns. ${LOOK}. He will not look at the water.`,
			imageUrl: "/panels/01-bridge.jpg",
			captionEn: "Rain argued with the lanterns. Ren would not look at the water.",
			dialogueEn: "The pendant cracked because I paid the wrong debt.",
			captionHi: "बारिश लालटेन से झगड़ रही थी। रेन पानी की तरफ़ नहीं देख रहा था।",
			dialogueHi: "पेंडेंट इसलिए टूटा क्योंकि मैंने गलत क़र्ज़ चुकाया।",
			lineEn: "Rain argued with the lanterns. Ren would not look at the water. The pendant cracked because I paid the wrong debt.",
			lineHi: "बारिश लालटेन से झगड़ रही थी। रेन पानी की तरफ़ नहीं देख रहा था। पेंडेंट इसलिए टूटा क्योंकि मैंने गलत क़र्ज़ चुकाया।",
			locked: true
		},
		{
			id: "s2",
			caption: "The cracked jade remembered a name he had tried to forget.",
			dialogue: "",
			speaker: "",
			sfx: "CRACK",
			state: "Blood on the thumb, pale-green glow, wet hair",
			imagePrompt: `Vertical manhua close-up, no text. ${LOOK}, cupping a cracked glowing jade pendant, blood on the thumb, rain.`,
			imageUrl: "/panels/02-jade.jpg",
			captionEn: "The cracked jade remembered a name he had tried to forget.",
			dialogueEn: "",
			captionHi: "टूटी हुई जेड ने वह नाम याद किया जिसे वह भुलाना चाहता था।",
			dialogueHi: "",
			lineEn: "The cracked jade remembered a name he had tried to forget.",
			lineHi: "टूटी हुई जेड ने वह नाम याद किया जिसे वह भुलाना चाहता था।",
			locked: true
		},
		{
			id: "s3",
			caption: "Across the cedar mist, Shao waited. Her calm made the fog step aside.",
			dialogue: "Your soul can cross. That body cannot.",
			speaker: "Shao",
			sfx: "",
			state: "Dawn fog, spear diagonal, silver hair knotted high",
			imagePrompt: "Vertical manhua panel, no text. Misty cedar forest at dawn. Woman with silver-white hair in a high knot, black armor, long spear, severe calm face.",
			imageUrl: "/panels/03-spear.jpg",
			captionEn: "Across the cedar mist, Shao waited. Her calm made the fog step aside.",
			dialogueEn: "Your soul can cross. That body cannot.",
			captionHi: "देवदार के कोहरे के पार शाओ इंतज़ार कर रही थी। उसके सुकून से कोहरा हट गया।",
			dialogueHi: "तुम्हारी रूह पार हो सकती है। यह शरीर नहीं।",
			lineEn: "Across the cedar mist, Shao waited. Her calm made the fog step aside. Your soul can cross. That body cannot.",
			lineHi: "देवदार के कोहरे के पार शाओ इंतज़ार कर रही थी। उसके सुकून से कोहरा हट गया। तुम्हारी रूह पार हो सकती है। यह शरीर नहीं।",
			locked: true
		},
		{
			id: "s4",
			caption: "Lightning opened the palace gate. Between them the debt had a face.",
			dialogue: "",
			speaker: "",
			sfx: "CRACK",
			state: "Robe tearing in the wind, spear lowered, lightning over the gate",
			imagePrompt: `Vertical manhua wide panel, no text. Dark palace gate, lightning, rain. Left: ${LOOK}. Right: silver-haired woman in black armor with a spear lowered.`,
			imageUrl: "/panels/04-gate.jpg",
			captionEn: "Lightning opened the palace gate. Between them the debt had a face.",
			dialogueEn: "",
			captionHi: "बिजली ने महल का द्वार खोल दिया। उनके बीच क़र्ज़ का चेहरा था।",
			dialogueHi: "",
			lineEn: "Lightning opened the palace gate. Between them the debt had a face.",
			lineHi: "बिजली ने महल का द्वार खोल दिया। उनके बीच क़र्ज़ का चेहरा था।",
			locked: true
		}
	],
	narration: "Rain argued with the lanterns on Old Bridge. Ren would not look at the water. The pendant cracked because he paid the wrong debt. Blood threaded his thumb, and the jade remembered a name. In the cedar mist Shao waited with her spear. Your soul can cross, she said. That body cannot. Lightning opened the palace gate, and the debt finally had a face.",
	narrationEn: "Rain argued with the lanterns on Old Bridge. Ren would not look at the water. The pendant cracked because he paid the wrong debt. Blood threaded his thumb, and the jade remembered a name. In the cedar mist Shao waited with her spear. Your soul can cross, she said. That body cannot. Lightning opened the palace gate, and the debt finally had a face.",
	narrationHi: "पुराने पुल पर बारिश लालटेन से झगड़ रही थी। रेन पानी की तरफ़ नहीं देख रहा था। पेंडेंट इसलिए टूटा क्योंकि उसने गलत क़र्ज़ चुकाया। अंगूठे पर खून था, और जेड ने एक नाम याद किया। देवदार के कोहरे में शाओ भाला लेकर खड़ी थी। उसने कहा, तुम्हारी रूह पार हो सकती है। यह शरीर नहीं। बिजली ने महल का द्वार खोला, और क़र्ज़ का चेहरा सामने था।",
	seo: {
		title: "The Lantern Debt — a soul may cross, the body may not",
		description: "Motion comic. On a rain bridge, Ren's cracked jade calls in a debt. Shao lets the soul through and stops the body at the palace gate.",
		tags: [
			"motion comic",
			"manhua",
			"The Lantern Debt",
			"Ren",
			"Shao",
			"original story"
		],
		hashtags: "#manhua #motioncomic #TheLanternDebt",
		privacy: "private"
	},
	seoEn: {
		title: "The Lantern Debt — a soul may cross, the body may not",
		description: "Motion comic. On a rain bridge, Ren's cracked jade calls in a debt. Shao lets the soul through and stops the body at the palace gate.",
		tags: [
			"motion comic",
			"manhua",
			"The Lantern Debt",
			"Ren",
			"Shao",
			"original story"
		],
		hashtags: "#manhua #motioncomic #TheLanternDebt"
	},
	seoHi: {
		title: "लालटेन का क़र्ज़ — रूह पार हो सकती है, शरीर नहीं",
		description: "मोशन कॉमिक। बारिश वाले पुल पर रेन की टूटी जेड एक क़र्ज़ वसूलती है। शाओ रूह को जाने देती है और शरीर को महल के द्वार पर रोक देती है।",
		tags: [
			"मोशन कॉमिक",
			"manhua",
			"लालटेन का क़र्ज़",
			"Ren",
			"Shao"
		],
		hashtags: "#manhua #मोशनकॉमिक #लालटेनकाकर्ज़"
	}
};
var SFX_RULES = [
	[/lightning|thunder|gate/i, "CRACK"],
	[/spear|blade|slash|sword/i, "SHING"],
	[/crack|shatter|blood|jade/i, "CRACK"],
	[/gasp|whisper|breath/i, "GASP"],
	[/boom|roar|explode/i, "BOOM"]
];
function slug(name) {
	return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "figure";
}
function sfxFor(text) {
	for (const [rule, sfx] of SFX_RULES) if (rule.test(text)) return sfx;
	return "";
}
function clip(text, max) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length <= max) return clean;
	return `${clean.slice(0, max - 1).trimEnd()}…`;
}
function parseBlocks(raw) {
	const lines = raw.split(/\n+/).map((line) => line.trim()).filter(Boolean);
	let title = "Untitled chapter";
	if (lines.length > 1 && lines[0].length <= 48 && !lines[0].includes(":")) {
		title = lines[0];
		lines.shift();
	}
	const blocks = [];
	let buf = [];
	const flush = () => {
		if (buf.length) blocks.push(buf.join(" "));
		buf = [];
	};
	for (const line of lines) {
		if (/^[^:\n]{1,32}:\s+\S/.test(line)) {
			flush();
			blocks.push(line);
			continue;
		}
		buf.push(line);
		if (buf.join(" ").length > 320) flush();
	}
	flush();
	return {
		title,
		blocks
	};
}
function cutChapter(raw) {
	const incoming = raw.trim();
	if (incoming === SAMPLE_TEXT.trim()) return SAMPLE;
	const text = sanitizeNovelText(incoming);
	if (text === SAMPLE_TEXT.trim()) return SAMPLE;
	const { title, blocks } = parseBlocks(text);
	const speakers = /* @__PURE__ */ new Map();
	const scenes = blocks.map((block, index) => {
		const spoken = block.match(/^([^:\n]{1,32}):\s+([\s\S]+)$/);
		const speaker = spoken ? spoken[1].trim() : "";
		const dialogue = spoken ? clip(spoken[2], 180) : "";
		const caption = spoken ? "" : clip(block, 220);
		if (speaker) {
			const list = speakers.get(speaker) ?? [];
			list.push(dialogue);
			speakers.set(speaker, list);
		}
		const blob = `${caption} ${dialogue}`;
		return {
			id: `s${index + 1}`,
			caption: spoken ? "" : clip(block, 220),
			dialogue,
			speaker,
			sfx: sfxFor(blob),
			state: clip(blob, 120),
			imagePrompt: `Vertical illustrated comic panel, no text, no letters, no logos, no speech bubbles. ${clip(blob, 400)}`,
			imageUrl: null
		};
	});
	const nameHits = speakers.size ? [] : text.match(/\b[A-Z][a-z]{2,}(?:\s[A-Z][a-z]+)?\b/g) ?? [];
	for (const name of nameHits) {
		if ([
			"The",
			"Rain",
			"Across",
			"Between",
			"Lightning",
			"Your"
		].includes(name)) continue;
		if (!speakers.has(name)) speakers.set(name, []);
	}
	const characters = [];
	const used = /* @__PURE__ */ new Set();
	for (const [name, lines] of speakers) {
		if (characters.length >= 24) break;
		let id = slug(name);
		while (used.has(id)) id = `${id}-${used.size}`;
		used.add(id);
		const sentence = text.split(/(?<=[.!?])\s+/).find((part) => part.includes(name) && /robe|hair|scar|armor|spear|eyes|face|blood/i.test(part)) ?? "";
		const look = sentence ? clip(sentence, 180) : "Body not described in this chapter.";
		characters.push({
			id,
			name,
			soul: lines[0] ? `Says: “${clip(lines[0], 140)}” Identity stays on this name if the body changes.` : "Named in the chapter. Identity stays on this name if the body changes.",
			vessel: look,
			look
		});
	}
	if (scenes.length === 0) scenes.push({
		id: "s1",
		caption: "The chapter is empty.",
		dialogue: "",
		speaker: "",
		sfx: "",
		state: "Nothing to track yet",
		imagePrompt: "Vertical empty storyboard panel, no text",
		imageUrl: null
	});
	const narration = scenes.map((scene) => [scene.caption, scene.dialogue].filter(Boolean).join(" ")).join(" ").replace(/\s+/g, " ").trim();
	return {
		title,
		source: "local",
		text,
		logline: clip(scenes.find((scene) => scene.caption)?.caption || title, 160),
		characters,
		timeline: scenes.map((scene, index) => `Panel ${index + 1}: ${scene.state}`),
		scenes,
		narration: narration || title,
		seo: {
			title: `${title} — motion comic`,
			description: clip(narration || title, 180),
			tags: [
				"motion comic",
				"original story",
				...characters.map((character) => character.name)
			].slice(0, 8)
		}
	};
}
function mergeCuts(parts) {
	const first = parts[0];
	if (!first) throw new Error("Nothing to merge.");
	const characters = [];
	const seen = /* @__PURE__ */ new Set();
	const scenes = [];
	const timeline = [];
	for (const part of parts) {
		for (const character of part.characters) {
			const key = character.name.trim().toLowerCase();
			if (!key || seen.has(key)) continue;
			seen.add(key);
			characters.push(character);
		}
		for (const scene of part.scenes) scenes.push({
			...scene,
			id: `s${scenes.length + 1}`
		});
		timeline.push(...part.timeline);
	}
	const narration = parts.map((part) => part.narration).filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
	const text = parts.map((part) => part.text).join("\n\n");
	return {
		...first,
		text,
		characters,
		scenes: scenes.length ? scenes : first.scenes,
		timeline,
		narration: narration || first.narration || first.title,
		chapters: void 0,
		language: detectLanguage(`${text}\n${narration}`)
	};
}
function projectFromChapters(items) {
	if (!items.length) throw new Error("No chapters to cut.");
	const chapters = [];
	const scenes = [];
	const characters = [];
	const seen = /* @__PURE__ */ new Set();
	const blocks = [];
	for (const item of items) {
		const body = item.text.trim();
		const cut = cutChapter(body);
		const title = (item.title || cut.title || `Chapter ${item.index}`).trim() || `Chapter ${item.index}`;
		const chapterScenes = cut.scenes.map((scene, index) => ({
			...scene,
			id: `s${index + 1}`
		}));
		chapters.push({
			index: item.index,
			title,
			sourceUrl: item.sourceUrl,
			narration: cut.narration,
			characters: cut.characters,
			scenes: chapterScenes
		});
		for (const scene of chapterScenes) scenes.push({
			...scene,
			id: `c${item.index}-${scene.id}`,
			chapter: item.index
		});
		for (const character of cut.characters) {
			const key = character.name.trim().toLowerCase();
			if (!key || seen.has(key)) continue;
			seen.add(key);
			characters.push(character);
		}
		blocks.push(`${title}\n\n${body}`);
	}
	const text = blocks.join("\n\n");
	const narration = chapters.map((chapter) => chapter.narration).filter(Boolean).join("\n\n");
	const title = chapters.length === 1 ? chapters[0].title : `${chapters[0].title} · ${chapters.length} chapters`;
	return {
		title,
		source: "local",
		text,
		logline: clip(chapters[0].scenes.find((scene) => scene.caption)?.caption || title, 160),
		characters,
		timeline: scenes.map((scene, index) => `Panel ${index + 1}: ${scene.state}`),
		scenes,
		narration: narration || title,
		seo: {
			title: `${title} — motion comic`,
			description: clip(narration || title, 180),
			tags: [
				"motion comic",
				"original story",
				...characters.map((character) => character.name)
			].slice(0, 8)
		},
		chapters,
		language: detectLanguage(text)
	};
}
function tilesFor(scene, characters) {
	const blob = `${scene.speaker}\n${scene.caption}\n${scene.dialogue}\n${scene.state}`;
	const named = characters.filter((character) => blob.includes(character.name));
	const speaker = characters.find((character) => character.name === scene.speaker);
	const ids = named.map((character) => character.id);
	return [{
		prompt: scene.imagePrompt.trim() || `Vertical illustrated comic panel, no text, no letters. ${scene.caption || scene.dialogue || scene.state || "Open panel"}`,
		negative: DEFAULT_NEGATIVE,
		characters: ids,
		vessel_id: speaker?.id ?? ids[0] ?? ""
	}];
}
function faceReference(scene, characters) {
	const blob = `${scene.speaker}\n${scene.caption}\n${scene.dialogue}\n${scene.imagePrompt}`;
	const named = characters.find((character) => character.faceUrl && character.name && blob.includes(character.name));
	const only = characters.length === 1 ? characters[0] : void 0;
	const face = named?.faceUrl || only?.faceUrl || "";
	if (!face || face.length > 4e5) return void 0;
	return face;
}
function scenePacket(scene, characters) {
	const image = scene.imageUrl && scene.imageUrl.length > 0 && scene.imageUrl.length <= 12e5 ? scene.imageUrl : void 0;
	const reference = faceReference(scene, characters);
	return {
		id: scene.id,
		caption: scene.caption,
		sfx: scene.sfx,
		state: scene.state,
		bubble: {
			speaker: scene.speaker,
			text: scene.dialogue
		},
		...image ? { image_url: image } : {},
		...scene.holdSec && scene.holdSec > 0 ? { hold_sec: scene.holdSec } : {},
		...reference ? { reference } : {},
		tiles: tilesFor(scene, characters)
	};
}
function chapterPacket(chapter) {
	return {
		index: chapter.index,
		title: chapter.title.trim() || `Chapter ${chapter.index}`,
		source_url: chapter.sourceUrl,
		narration: chapter.narration,
		characters: chapter.characters.map(({ id, name, soul, vessel }) => ({
			id,
			name,
			soul,
			vessel,
			vessel_id: id
		})),
		scenes: chapter.scenes.map((scene) => scenePacket(scene, chapter.characters))
	};
}
function projectWithAbsoluteArt(project, origin) {
	const fix = (url) => {
		if (!url) return url;
		if (/^https?:\/\//i.test(url) || url.startsWith("data:")) return url;
		if (url.startsWith("/") && /^https?:\/\//i.test(origin)) return `${origin.replace(/\/$/, "")}${url}`;
		return url;
	};
	return {
		...project,
		scenes: project.scenes.map((scene) => ({
			...scene,
			imageUrl: fix(scene.imageUrl)
		})),
		chapters: project.chapters?.map((chapter) => ({
			...chapter,
			scenes: chapter.scenes.map((scene) => ({
				...scene,
				imageUrl: fix(scene.imageUrl)
			}))
		}))
	};
}
function jobPacket(project, pass = "assemble") {
	const language = project.language ?? detectLanguage(`${project.text}\n${project.narration}`);
	const chapters = project.chapters?.length ? project.chapters.map(chapterPacket) : [chapterPacket({
		index: 1,
		title: project.title,
		sourceUrl: null,
		narration: project.narration,
		characters: project.characters,
		scenes: project.scenes
	})];
	return jobPacketV2Schema.parse({
		version: 2,
		language,
		voice: voiceFor(language, project.voice),
		title: project.title.trim() || "Untitled chapter",
		aspect: project.aspect === "9:16" ? "9:16" : "16:9",
		local_model: project.localModel === "airllm" || project.localModel === "fast" ? project.localModel : "gguf",
		hook: project.hook ?? "",
		pass,
		chapters,
		seo: {
			title: project.seo.title,
			description: project.seo.description,
			tags: project.seo.tags
		},
		...project.imageRepo?.trim() ? { image_repo: project.imageRepo.trim().slice(0, 200) } : {},
		note: "Job packet v2. Explanation video. Do not fetch paywalled pages. Panels are prompts for the GPU render, not a static strip."
	});
}
/** Picture holds and worker voice paths from a finished job. Does not touch prompts or images. */
function applyWorkerAssets(project, timing, voices, language) {
	return {
		...project,
		scenes: project.scenes.map((scene) => {
			const hold = timing[scene.id];
			const voice = voices[scene.id];
			const nextHold = hold && hold > 0 ? Math.max(scene.holdSec || 0, hold) : scene.holdSec;
			if (language === "hi") return {
				...scene,
				...nextHold ? { holdSec: nextHold } : {},
				...voice ? { voiceHi: voice } : {}
			};
			return {
				...scene,
				...nextHold ? { holdSec: nextHold } : {},
				...voice ? { voiceEn: voice } : {}
			};
		})
	};
}
/** Safety stop so a mistyped end chapter cannot request thousands of pages. The old 40 cap is gone. */
var CHAPTER_PULL_CAP = 2e3;
var CHUNK_CHARS = 8e3;
function expandChapterUrls(template, start, end) {
	const raw = template.trim();
	if (!raw) throw new Error("Add a chapter URL.");
	if (!Number.isInteger(start) || !Number.isInteger(end)) throw new Error("Start and end must be whole numbers.");
	if (start < 0 || end < start) throw new Error("The range has to end on or after the start.");
	const count = end - start + 1;
	if (count > 2e3) throw new Error(`That range is ${count} chapters. Pull at most ${CHAPTER_PULL_CAP} in one go, or narrow the start and end.`);
	const numbers = [];
	for (let n = start; n <= end; n += 1) numbers.push(n);
	if (raw.includes("{n}")) return numbers.map((n) => raw.replaceAll("{n}", String(n)));
	const matches = raw.match(/\d+/g);
	if (!matches) throw new Error("Put {n} in the URL, or include a chapter number to replace.");
	const last = matches[matches.length - 1];
	const at = raw.lastIndexOf(last);
	return numbers.map((n) => `${raw.slice(0, at)}${n}${raw.slice(at + last.length)}`);
}
function chunkChapterText(text, size = CHUNK_CHARS) {
	const clean = text.replace(/\r\n/g, "\n").trim();
	if (!clean) return [];
	if (clean.length <= size) return [clean];
	const parts = [];
	let rest = clean;
	while (rest.length > size) {
		let cut = rest.lastIndexOf("\n\n", size);
		if (cut < size * .45) cut = rest.lastIndexOf("\n", size);
		if (cut < size * .45) cut = rest.lastIndexOf(". ", size);
		if (cut < size * .45) cut = size;
		const piece = rest.slice(0, cut).trim();
		if (piece) parts.push(piece);
		rest = rest.slice(cut).trim();
	}
	if (rest) parts.push(rest);
	if (parts.length > 1 && parts[parts.length - 1].length < 40) {
		const tail = parts.pop();
		if (tail) parts[parts.length - 1] = `${parts[parts.length - 1]}\n\n${tail}`;
	}
	return parts;
}
var KEY = "manhua-factory-project-v1";
/** Project snapshot only. Keys, cookies, and tokens are not fields on Project. */
function saveProject(project) {
	if (typeof localStorage === "undefined") return;
	try {
		const scenes = project.scenes.map((scene) => ({
			...scene,
			imageUrl: scene.imageUrl && scene.imageUrl.startsWith("data:") && scene.imageUrl.length > 8e4 ? null : scene.imageUrl,
			voiceEn: scene.voiceEn?.startsWith("data:") ? void 0 : scene.voiceEn,
			voiceHi: scene.voiceHi?.startsWith("data:") ? void 0 : scene.voiceHi
		}));
		const characters = project.characters.map((character) => ({
			...character,
			faceUrl: character.faceUrl && character.faceUrl.startsWith("data:") && character.faceUrl.length > 18e4 ? void 0 : character.faceUrl
		}));
		const payload = JSON.stringify({
			...project,
			scenes,
			characters
		});
		if (payload.length > 45e5) return;
		localStorage.setItem(KEY, payload);
	} catch {}
}
function loadProject() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (!data || typeof data.title !== "string" || !Array.isArray(data.scenes)) return null;
		return data;
	} catch {
		return null;
	}
}
var EMPTY_SLOT = {
	token: "",
	email: "",
	channel: ""
};
var voiceCache = /* @__PURE__ */ new Map();
var PROVIDER_IDS = Object.keys(PROVIDER_PRESETS);
function masterSrc(workerUrl, token, language) {
	try {
		const target = workerEndpoint(workerUrl, `/api/v1/masters/${language}.mp4`);
		if (token.trim()) target.searchParams.set("token", token.trim());
		return target.toString();
	} catch {
		return null;
	}
}
function shownLabel(label, pass) {
	if (pass === "revoice" && (!label || /generat|paint|draw|image/i.test(label))) return "Re-voicing";
	return label;
}
function safeHttp(value) {
	try {
		const url = new URL(value.trim());
		if (url.protocol !== "http:" && url.protocol !== "https:") return null;
		return url.toString();
	} catch {
		return null;
	}
}
function sourceLabel(source) {
	if (source === "sample") return "Sample painted";
	if (source === "grok") return "AI recap";
	return "Fetched chapter";
}
async function copyText(value) {
	try {
		await navigator.clipboard.writeText(value);
		return true;
	} catch {
		try {
			const area = document.createElement("textarea");
			area.value = value;
			area.setAttribute("readonly", "");
			area.style.position = "fixed";
			area.style.top = "0";
			area.style.left = "0";
			area.style.opacity = "0";
			document.body.appendChild(area);
			area.focus();
			area.select();
			const ok = document.execCommand("copy");
			area.remove();
			return ok;
		} catch {
			return false;
		}
	}
}
function panelsProject(title, panels) {
	const scenes = panels.map((panel, index) => {
		const bubble = panel.bubble?.trim() || "";
		const aside = panel.aside?.trim() || "";
		const line = [bubble, aside].filter(Boolean).join(" ").trim() || panel.text.trim() || `Panel ${index + 1}`;
		const caption = aside || line;
		const dialogue = bubble && aside ? bubble : "";
		return {
			id: `s${index + 1}`,
			caption,
			dialogue,
			speaker: "",
			sfx: "",
			state: "Source panel",
			imagePrompt: "Source panel. Do not redraw.",
			imageUrl: panel.src,
			locked: true,
			promptLocked: true,
			lineEn: line,
			captionEn: caption,
			dialogueEn: dialogue
		};
	});
	return {
		...SAMPLE,
		title: title || "Source panels",
		source: "local",
		text: scenes.map((scene) => scene.caption).join("\n\n"),
		logline: scenes[0]?.caption || title,
		characters: [],
		timeline: scenes.map((scene, index) => `Panel ${index + 1}`),
		scenes,
		narration: scenes.map((scene) => scene.caption).join(" "),
		seo: {
			...SAMPLE.seo,
			title: `${title || "Manhua"} — explanation`,
			description: (scenes[0]?.caption || title).slice(0, 180)
		}
	};
}
function keepPrivacy(next, previous) {
	if (!previous.seo.privacy) return next;
	return {
		...next,
		seo: {
			...next.seo,
			privacy: previous.seo.privacy
		}
	};
}
function parseTags(value) {
	const seen = /* @__PURE__ */ new Set();
	const tags = [];
	for (const part of value.split(",")) {
		const tag = part.replace(/\s+/g, " ").trim().slice(0, 30);
		if (!tag) continue;
		const key = tag.toLowerCase();
		if (seen.has(key)) continue;
		seen.add(key);
		tags.push(tag);
		if (tags.length >= 15) break;
	}
	return tags;
}
function wipeLegacySecrets() {
	const sweep = (storage) => {
		const doomed = [];
		for (let index = 0; index < storage.length; index += 1) {
			const key = storage.key(index);
			if (key && key.startsWith("aether-")) doomed.push(key);
		}
		for (const key of doomed) storage.removeItem(key);
	};
	try {
		sweep(localStorage);
	} catch {}
	try {
		sweep(sessionStorage);
	} catch {}
}
function googleAccounts() {
	return window.google;
}
function loadGis() {
	if (googleAccounts()?.accounts?.oauth2) return Promise.resolve();
	return new Promise((resolve, reject) => {
		const previous = document.querySelector("script[data-aether-gis]");
		if (previous) {
			previous.addEventListener("load", () => resolve(), { once: true });
			previous.addEventListener("error", () => reject(/* @__PURE__ */ new Error("Google sign-in did not load.")), { once: true });
			return;
		}
		const script = document.createElement("script");
		script.src = "https://accounts.google.com/gsi/client";
		script.async = true;
		script.dataset.aetherGis = "1";
		script.onload = () => resolve();
		script.onerror = () => reject(/* @__PURE__ */ new Error("Google sign-in did not load."));
		document.head.appendChild(script);
	});
}
function PanelArt({ scene, wide }) {
	const line = dialogueWithoutSpeaker(scene);
	const art = scene.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: scene.imageUrl,
		alt: scene.caption || line || "Panel",
		className: wide ? "h-full w-full object-cover" : "aspect-[2/3] w-full object-cover"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `flex items-end justify-center bg-panel pb-4 ${wide ? "h-full w-full" : "aspect-[2/3] w-full"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-widest text-muted uppercase",
			children: "Not painted"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl bg-ink-2 hairline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `relative overflow-hidden rounded-t-2xl bg-ink ${wide ? "aspect-video" : ""}`,
				children: [art, scene.sfx ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `sfx-hit pointer-events-none absolute top-3 left-3 z-10 font-display text-cinnabar italic ${wide ? "text-3xl" : "text-5xl"}`,
					children: scene.sfx
				}) : null]
			}),
			line ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-3 rounded-2xl bg-paper px-4 py-3 text-ink",
				children: [scene.speaker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-xs font-semibold tracking-widest text-seal uppercase",
					children: scene.speaker
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg leading-snug break-words text-ink",
					children: line
				})]
			}) : null,
			scene.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pt-3 pb-4 text-sm leading-relaxed break-words text-paper",
				children: scene.caption
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3" })
		]
	});
}
function StudioApp() {
	const [tab, setTab] = (0, import_react.useState)("story");
	const [project, setProject] = (0, import_react.useState)(SAMPLE);
	const [draft, setDraft] = (0, import_react.useState)(SAMPLE_TEXT);
	const [url, setUrl] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [showCell, setShowCell] = (0, import_react.useState)(false);
	const [track, setTrack] = (0, import_react.useState)(null);
	const [showSettings, setShowSettings] = (0, import_react.useState)(false);
	const [workerUrl, setWorkerUrl] = (0, import_react.useState)("");
	const [workerToken, setWorkerToken] = (0, import_react.useState)("");
	const [provider, setProvider] = (0, import_react.useState)("zai");
	const [modelId, setModelId] = (0, import_react.useState)(defaultModel("zai"));
	const [customModel, setCustomModel] = (0, import_react.useState)("");
	const [customBase, setCustomBase] = (0, import_react.useState)("");
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [revealKey, setRevealKey] = (0, import_react.useState)(false);
	const [apiBadge, setApiBadge] = (0, import_react.useState)(null);
	const [workerBadge, setWorkerBadge] = (0, import_react.useState)(null);
	const [localModel, setLocalModel] = (0, import_react.useState)("gguf");
	const [duty, setDuty] = (0, import_react.useState)("split");
	const [imageRepo, setImageRepo] = (0, import_react.useState)("");
	const [language, setLanguage] = (0, import_react.useState)("en");
	const [voiceEn, setVoiceEn] = (0, import_react.useState)("en-US-ChristopherNeural");
	const [voiceHi, setVoiceHi] = (0, import_react.useState)("hi-IN-MadhurNeural");
	const [masters, setMasters] = (0, import_react.useState)({
		en: false,
		hi: false
	});
	const [previewSeen, setPreviewSeen] = (0, import_react.useState)(false);
	const [previewBroken, setPreviewBroken] = (0, import_react.useState)(false);
	const [aspect, setAspect] = (0, import_react.useState)("9:16");
	const [retries, setRetries] = (0, import_react.useState)("3");
	const [colabUrl, setColabUrl] = (0, import_react.useState)("");
	const [kaggleUrl, setKaggleUrl] = (0, import_react.useState)("");
	const [rangeStart, setRangeStart] = (0, import_react.useState)("");
	const [rangeEnd, setRangeEnd] = (0, import_react.useState)("");
	const [sourceMode, setSourceMode] = (0, import_react.useState)("text");
	const [sourceCookie, setSourceCookie] = (0, import_react.useState)("");
	const [bibleBefore, setBibleBefore] = (0, import_react.useState)("40");
	const [bibleAfter, setBibleAfter] = (0, import_react.useState)("20");
	const [bible, setBible] = (0, import_react.useState)("");
	const [channels, setChannels] = (0, import_react.useState)({
		en: EMPTY_SLOT,
		hi: EMPTY_SLOT
	});
	const [chatLog, setChatLog] = (0, import_react.useState)([{
		role: "studio",
		text: "Ask about a look, a line, or the two channels. Changing English or Hindi only re-voices. Pictures stay."
	}]);
	const [chatDraft, setChatDraft] = (0, import_react.useState)("");
	const [playAt, setPlayAt] = (0, import_react.useState)(0);
	const [job, setJob] = (0, import_react.useState)(null);
	const [ytClientId, setYtClientId] = (0, import_react.useState)("");
	const [ytToken, setYtToken] = (0, import_react.useState)("");
	const [ytEmail, setYtEmail] = (0, import_react.useState)("");
	const [ytChannel, setYtChannel] = (0, import_react.useState)("");
	const [previewUrl, setPreviewUrl] = (0, import_react.useState)(null);
	const [watchUrl, setWatchUrl] = (0, import_react.useState)(null);
	const [tagDraft, setTagDraft] = (0, import_react.useState)(SAMPLE.seo.tags.join(", "));
	const seenTags = (0, import_react.useRef)(SAMPLE.seo.tags.join("|"));
	const [voiced, setVoiced] = (0, import_react.useState)({});
	const voiceRun = (0, import_react.useRef)(0);
	const jobPass = (0, import_react.useRef)("assemble");
	const jobLanguage = (0, import_react.useRef)("en");
	const hydrated = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		wipeLegacySecrets();
		const saved = loadProject();
		if (saved) {
			setProject(saved);
			setDraft(saved.text || SAMPLE_TEXT);
			if (saved.language === "hi" || saved.language === "en") setLanguage(saved.language);
			if (saved.bible) setBible(saved.bible);
			if (saved.aspect === "16:9" || saved.aspect === "9:16") setAspect(saved.aspect);
			if (saved.imageRepo) setImageRepo(saved.imageRepo);
			const flags = {};
			for (const scene of saved.scenes) {
				if (scene.voiceEn) flags[`${scene.id}:en`] = true;
				if (scene.voiceHi) flags[`${scene.id}:hi`] = true;
			}
			setVoiced(flags);
			setTagDraft((saved.seo?.tags || []).join(", "));
		}
		hydrated.current = true;
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated.current) return;
		saveProject({
			...project,
			imageRepo: imageRepo.trim() || project.imageRepo
		});
	}, [project, imageRepo]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (previewUrl) URL.revokeObjectURL(previewUrl);
		};
	}, [previewUrl]);
	const preset = PROVIDER_PRESETS[provider];
	function voiceFor(next) {
		return next === "hi" ? voiceHi : voiceEn;
	}
	const voice = voiceFor(language);
	const filmSrc = masterSrc(workerUrl, workerToken, language);
	function session() {
		return {
			provider,
			model: customModel.trim() || modelId,
			apiKey: apiKey.trim(),
			customBaseUrl: customBase.trim(),
			workerUrl: workerUrl.trim(),
			workerToken: workerToken.trim(),
			localModel,
			language,
			duty
		};
	}
	async function readBubbles(panels) {
		const next = panels.map((panel) => ({ ...panel }));
		if (!workerUrl.trim()) return next;
		const indexed = next.map((panel, index) => ({
			panel,
			index
		})).filter((row) => /^https?:\/\//i.test(row.panel.src));
		if (!indexed.length) return next;
		for (let start = 0; start < indexed.length; start += 8) {
			const batch = indexed.slice(start, start + 8);
			setBusy(`Reading bubbles ${start + 1}–${start + batch.length} of ${indexed.length}`);
			try {
				const result = await readPanelText({ data: {
					images: batch.map((row) => ({
						id: `p${row.index}`,
						url: row.panel.src
					})),
					...session()
				} });
				if (!result.ok) {
					setNotice(`${result.error} Nearby page text is kept.`);
					break;
				}
				for (const row of result.panels) {
					const index = Number(row.id.slice(1));
					const target = next[index];
					if (!target || !Number.isInteger(index)) continue;
					if (row.bubble.trim()) target.bubble = row.bubble.trim();
					if (row.aside.trim()) target.aside = row.aside.trim();
					const spoken = [target.bubble, target.aside].filter(Boolean).join(" ").trim();
					if (spoken) target.text = spoken;
				}
			} catch {
				setNotice("Bubble reading stopped. Nearby page text is kept.");
				break;
			}
		}
		return next;
	}
	async function writeMissingPrompts(source) {
		const pendingIds = new Set(beatsNeedingPrompt(source.scenes));
		const pending = source.scenes.filter((scene) => pendingIds.has(scene.id) && !scene.imagePrompt.trim());
		if (!pending.length) return source;
		let current = source;
		for (let index = 0; index < pending.length; index += 1) {
			const scene = pending[index];
			if (!scene) continue;
			setBusy(`Writing prompt ${index + 1} of ${pending.length}. One beat, then the next. No picture yet.`);
			try {
				const result = await writeBeatPrompt({ data: {
					caption: scene.caption,
					dialogue: scene.dialogue,
					speaker: scene.speaker,
					state: scene.state,
					chapter: scene.chapter || 0,
					lock: lookLockForScene(scene, current.characters),
					...session()
				} });
				if (!result.ok) {
					setError(result.error);
					setBusy(null);
					return null;
				}
				current = {
					...current,
					scenes: current.scenes.map((item) => item.id === scene.id ? {
						...item,
						imagePrompt: result.prompt,
						promptLocked: true
					} : item)
				};
				setProject(current);
			} catch (err) {
				setError(err instanceof Error ? err.message : "The prompt writer stopped. No picture was drawn.");
				setBusy(null);
				return null;
			}
		}
		return current;
	}
	function patchCast(id, patch, recompose) {
		setProject((current) => {
			const characters = current.characters.map((item) => {
				if (item.id !== id) return item;
				const next = {
					...item,
					...patch,
					outfits: patch.outfits ?? item.outfits
				};
				if (recompose) {
					next.look = composeLook(next);
					next.vessel = next.outfit || next.look;
				}
				return next;
			});
			const structured = characters.some((item) => [
				item.face,
				item.hair,
				item.age,
				item.scars,
				item.eyes,
				item.body,
				item.outfit,
				...(item.outfits ?? []).map((row) => row.outfit)
			].some((value) => value?.trim()));
			return {
				...current,
				characters,
				...structured ? { bible: bibleDocument(characters) } : {}
			};
		});
	}
	function absVoice(path) {
		if (!path) return "";
		if (path.startsWith("data:") || /^https?:\/\//i.test(path)) return path;
		try {
			const target = workerEndpoint(workerUrl, path.startsWith("/api/v1/") ? path : `/api/v1/voices/${path}`);
			if (workerToken.trim()) target.searchParams.set("token", workerToken.trim());
			return target.toString();
		} catch {
			return "";
		}
	}
	function applyLanguage(next, source = project) {
		const shown = {
			...withLanguage(rememberScript(source, language), next),
			voice: voiceFor(next)
		};
		setLanguage(next);
		setProject(shown);
		setTagDraft(shown.seo.tags.join(", "));
		setNotice("Language change = audio, captions, and SEO only. Pictures stay.");
		return shown;
	}
	function rememberVoice(sceneId, next, src, workerPath) {
		if (src) voiceCache.set(`${sceneId}:${next}`, src);
		setVoiced((current) => ({
			...current,
			[`${sceneId}:${next}`]: true
		}));
		if (!workerPath) return;
		setProject((current) => ({
			...current,
			scenes: current.scenes.map((scene) => scene.id === sceneId ? {
				...scene,
				...next === "hi" ? { voiceHi: workerPath } : { voiceEn: workerPath }
			} : scene)
		}));
	}
	async function fillVoices(source, next, force = false) {
		const pending = source.scenes.filter((scene) => {
			if (!voiceLine(scene, next)) return false;
			return !(next === "hi" ? scene.voiceHi : scene.voiceEn) && !voiceCache.has(`${scene.id}:${next}`);
		});
		if (!pending.length) {
			if (force) setNotice("Both voice tracks that exist stay. Nothing was redrawn.");
			return;
		}
		if (!force && pending.length > 8) {
			setNotice("Language change = audio, captions, and SEO only. Pictures stay. Re-voice makes the rest of the male track.");
			return;
		}
		const run = voiceRun.current + 1;
		voiceRun.current = run;
		for (let index = 0; index < pending.length; index += 1) {
			if (voiceRun.current !== run) return;
			const scene = pending[index];
			setBusy(`Re-voicing panel ${index + 1} of ${pending.length}. Pictures stay locked.`);
			try {
				const result = await speakLine({ data: {
					text: voiceLine(scene, next),
					voice: voiceFor(next),
					sceneId: scene.id,
					...session(),
					language: next
				} });
				if (voiceRun.current !== run) return;
				if (result.ok) {
					const src = result.audioBase64 ? `data:${result.mimeType || "audio/mpeg"};base64,${result.audioBase64}` : absVoice(result.audioUrl || "");
					rememberVoice(scene.id, next, src, result.audioUrl);
				}
			} catch {
				if (voiceRun.current !== run) return;
				setNotice("Language change = audio, captions, and SEO only. Pictures stay. One voice line did not start.");
				break;
			}
		}
		if (voiceRun.current === run) {
			setBusy(null);
			setNotice("Language change = audio, captions, and SEO only. Pictures stay.");
		}
	}
	async function onPickLanguage(next) {
		if (next === language || busy) return;
		setError(null);
		voiceRun.current += 1;
		const remembered = rememberScript(project, language);
		const missing = missingScript(remembered, next);
		if (missing.length === 0) {
			const shown = applyLanguage(next, remembered);
			setPreviewSeen(false);
			setPreviewBroken(false);
			if (masters[next]) {
				setNotice("Language change = audio, captions, and SEO only. Pictures stay.");
				return;
			}
			if (workerUrl.trim()) onSendJob("revoice", shown);
			else fillVoices(shown, next);
			return;
		}
		setPreviewSeen(false);
		setPreviewBroken(false);
		setBusy("Re-voicing. Pictures stay locked.");
		try {
			let current = remembered;
			const pending = current.scenes.filter((scene) => missing.includes(scene.id));
			let narration = "";
			let seoTitle = "";
			let seo = null;
			for (let index = 0; index < pending.length; index += 30) {
				const batch = pending.slice(index, index + 30);
				setBusy(`Re-voicing lines ${index + 1}–${Math.min(index + 30, pending.length)}. Pictures stay locked.`);
				const result = await translateLines({ data: {
					target: next,
					lines: batch.map((scene) => ({
						id: scene.id,
						caption: scene.caption,
						dialogue: scene.dialogue
					})),
					...session(),
					language: next
				} });
				if (!result.ok) {
					setError(result.error);
					setBusy(null);
					return;
				}
				current = writeTranslated(current, next, result.lines);
				if (result.narration) narration = result.narration;
				if (result.seo.title) {
					seoTitle = result.seo.title;
					seo = {
						...result.seo,
						privacy: void 0
					};
				}
			}
			const shown = applyLanguage(next, next === "hi" ? {
				...current,
				narrationHi: narration || current.narrationHi,
				seoHi: seoTitle && seo ? seo : current.seoHi
			} : {
				...current,
				narrationEn: narration || current.narrationEn,
				seoEn: seoTitle && seo ? seo : current.seoEn
			});
			if (workerUrl.trim()) onSendJob("revoice", shown);
			else fillVoices(shown, next);
		} catch (err) {
			setError(err instanceof Error ? `${err.message} Pictures were not touched.` : "Re-voice stopped. Pictures were not touched.");
			setBusy(null);
		}
	}
	function chooseProvider(next) {
		setProvider(next);
		setModelId(defaultModel(next));
		setCustomModel("");
		setApiBadge(null);
	}
	function stamp(next, hook) {
		return {
			...next,
			source: "grok",
			language,
			voice,
			hook: hook || next.hook || "",
			aspect,
			localModel,
			text: draft
		};
	}
	async function directText(cleaned, lock = bible) {
		const chunks = chunkChapterText(cleaned);
		if (!chunks.length) {
			setError("Paste at least a short chapter.");
			return false;
		}
		const parts = [];
		const call = session();
		for (let index = 0; index < chunks.length; index += 1) {
			setBusy(chunks.length > 1 ? `Directing part ${index + 1} of ${chunks.length}` : "Directing the manhua explanation");
			const result = await directChapter({ data: {
				text: chunks[index],
				lock,
				...call
			} });
			if (!result.ok) {
				setError(chunks.length > 1 ? `Part ${index + 1}: ${result.error}` : result.error);
				return false;
			}
			parts.push({
				...result.direction,
				source: "grok",
				text: chunks[index],
				hook: result.direction.hook
			});
			if (result.via === "local") setNotice("Cloud missed. Shifted to the connected Colab/Kaggle model.");
		}
		const merged = rememberScript(keepPrivacy(mergeCuts(parts), project), language);
		const cast = mergeCast(merged.characters, gleanCast(cleaned, merged.characters));
		const doc = (lock || bible).trim() || bibleDocument(cast);
		if (doc) setBible(doc);
		setProject(stamp({
			...merged,
			characters: cast,
			bible: doc || merged.bible
		}, parts.find((part) => part.hook)?.hook));
		setDraft(cleaned);
		setNotice(chunks.length > 1 ? `Explanation written in ${chunks.length} parts. ${merged.scenes.length} panels, no four-panel cap.` : `AI Manhua Recap Director wrote ${merged.scenes.length} panels in ${language === "hi" ? "Hindi" : "English"}.`);
		setTab("forge");
		return true;
	}
	async function onDirect() {
		const cleaned = sanitizeNovelText(draft);
		if (cleaned !== draft) setDraft(cleaned);
		setError(null);
		try {
			await directText(cleaned);
		} catch (err) {
			setError(err instanceof Error ? err.message : "The director did not answer.");
		} finally {
			setBusy(null);
		}
	}
	async function onFetch() {
		setError(null);
		const wantsRange = rangeStart.trim() !== "" || rangeEnd.trim() !== "";
		const cookie = sourceCookie.trim();
		if (wantsRange) {
			if (rangeStart.trim() === "" || rangeEnd.trim() === "") {
				setError("Set both a start and an end chapter.");
				return;
			}
			const start = Number(rangeStart);
			const end = Number(rangeEnd);
			let urls = [];
			try {
				urls = expandChapterUrls(url, start, end);
			} catch (err) {
				setError(err instanceof Error ? err.message : "That chapter range is not valid.");
				return;
			}
			const before = Math.min(100, Math.max(0, Number(bibleBefore) || 0));
			const after = Math.min(50, Math.max(0, Number(bibleAfter) || 0));
			const contextUrls = [];
			try {
				if (before > 0 && start - before >= 1) contextUrls.push(...expandChapterUrls(url, start - before, start - 1));
				else if (before > 0 && start > 1) contextUrls.push(...expandChapterUrls(url, 1, start - 1));
				if (after > 0) contextUrls.push(...expandChapterUrls(url, end + 1, end + after));
			} catch {}
			const fetched = [];
			try {
				const allUrls = [...contextUrls, ...urls];
				const pulled = /* @__PURE__ */ new Map();
				if (workerUrl.trim() && allUrls.length > 2) {
					setBusy("Sending the chapter range to the worker. This phone is not opening every page.");
					const started = await startWorkerFetch({ data: {
						urls: allUrls,
						cookie,
						...session()
					} });
					if (started.ok) {
						for (let attempt = 0; attempt < 90; attempt += 1) {
							await new Promise((resolve) => window.setTimeout(resolve, 1500));
							const status = await workerFetchStatus({ data: {
								jobId: started.jobId,
								...session()
							} });
							if (!status.ok) break;
							setBusy(status.label || `Worker fetch ${status.progress}%`);
							if (status.status === "error") throw new Error(status.label || "The worker could not finish that fetch.");
							if (status.status === "done") {
								for (const page of status.pages) pulled.set(page.url, {
									title: page.title,
									text: page.text,
									error: page.error,
									ok: page.ok && !page.error,
									panels: page.panels
								});
								break;
							}
						}
						if (!pulled.size) setNotice("The worker fetch did not return pages. Reading from this phone instead.");
					}
				}
				const contextBits = [];
				for (let index = 0; index < contextUrls.length; index += 1) {
					const href = contextUrls[index];
					if (!href) continue;
					const cached = pulled.get(href);
					if (cached?.ok) {
						contextBits.push(cached.text);
						continue;
					}
					setBusy(`Reading look context ${index + 1} of ${contextUrls.length}. These pages do not become panels.`);
					const result = await fetchSource({ data: {
						url: href,
						cookie
					} });
					if (result.ok) contextBits.push(result.text);
				}
				const cast = mergeCast(project.characters, gleanCast(contextBits.join("\n"), project.characters));
				const useful = cast.some((character) => character.face || character.hair || character.outfit || character.scars || character.eyes);
				const lock = useful ? bibleDocument(cast) : gleanLooks(contextBits.join("\n"));
				if (lock) setBible(lock);
				if (useful) setProject((current) => ({
					...current,
					characters: cast,
					bible: lock
				}));
				if ((Number(bibleBefore) || 0) > 100 || (Number(bibleAfter) || 0) > 50) setNotice("Look lock was capped at 100 chapters before and 50 after. Those pages never become panels.");
				for (let index = 0; index < urls.length; index += 1) {
					const chapter = start + index;
					const href = urls[index];
					if (!href) continue;
					const cached = pulled.get(href);
					if (cached && !cached.ok) {
						setError(`Chapter ${chapter}: ${cached.error || "The worker could not open that page."}`);
						return;
					}
					if (cached?.ok) {
						fetched.push({
							index: chapter,
							title: sanitizeNovelText(cached.title) || `Chapter ${chapter}`,
							sourceUrl: href,
							text: sanitizeNovelText(cached.text),
							panels: cached.panels
						});
						continue;
					}
					setBusy(`Reading chapter ${chapter} (${index + 1} of ${urls.length})`);
					const result = await fetchSource({ data: {
						url: href,
						cookie
					} });
					if (!result.ok) {
						setError(`Chapter ${chapter}: ${result.error}`);
						return;
					}
					fetched.push({
						index: chapter,
						title: sanitizeNovelText(result.title) || `Chapter ${chapter}`,
						sourceUrl: href,
						text: sanitizeNovelText(result.text),
						panels: result.panels
					});
				}
				if (sourceMode === "panels") {
					let panels = fetched.flatMap((chapter) => chapter.panels);
					panels = await readBubbles(panels);
					if (!panels.length) {
						setError("No panel images on those pages. Switch to text mode, or paste the chapter.");
						return;
					}
					const next = rememberScript(panelsProject(fetched[0]?.title || project.title, panels), "en");
					setProject({
						...keepPrivacy(next, project),
						language,
						voice,
						aspect,
						localModel,
						bible: lock,
						characters: useful ? cast : project.characters
					});
					setNotice(`${panels.length} source panels locked. Bubbles and nearby lines are separate. They will not be redrawn.`);
					setTab("strip");
					return;
				}
				const combined = fetched.map((chapter) => `${chapter.title}\n\n${chapter.text}`).join("\n\n");
				if (containsHan(combined) || lock) {
					setDraft(combined);
					setBible(lock);
					setNotice(lock ? "Look lock saved from nearby chapters. Directing the selected range only." : "Chinese text pulled. Translating into the explanation script.");
					await directText(combined, lock);
					return;
				}
				const next = keepPrivacy(projectFromChapters(fetched), project);
				setProject({ ...rememberScript({
					...next,
					language,
					voice,
					aspect,
					localModel,
					bible: lock,
					characters: useful ? mergeCast(next.characters, cast) : next.characters
				}, language) });
				setDraft(next.text);
				setNotice(`${fetched.length} chapters fetched. Run the director to write the explanation. Pictures are not made yet.`);
				setTab("story");
			} catch (err) {
				setError(err instanceof Error ? err.message : "The chapter range did not load.");
			} finally {
				setBusy(null);
			}
			return;
		}
		setBusy("Reading the page");
		try {
			const result = await fetchSource({ data: {
				url,
				cookie
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			if (sourceMode === "panels") {
				if (!result.panels.length) {
					setError("No panel images on that page. Switch to text mode, or paste the chapter.");
					return;
				}
				const panels = await readBubbles(result.panels);
				const next = rememberScript(panelsProject(result.title || "Source panels", panels), "en");
				setProject({
					...keepPrivacy(next, project),
					language,
					voice,
					aspect,
					localModel
				});
				setNotice(`${panels.length} source panels locked. Bubble lines and text near the face stay separate. Nothing is redrawn.`);
				setTab("strip");
				return;
			}
			const text = sanitizeNovelText(result.title ? `${result.title}\n\n${result.text}` : result.text);
			setDraft(text);
			if (containsHan(text)) {
				setNotice("Chinese chapter pulled. Translating it into the explanation.");
				await directText(text);
				return;
			}
			setNotice("Page text is in the script. Ads and nav were stripped. Direct it when you want the explanation.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "The page did not load.");
		} finally {
			setBusy(null);
		}
	}
	async function onPaint(onlyId) {
		setError(null);
		const prepared = await writeMissingPrompts(project);
		if (!prepared) return;
		const targets = prepared.scenes.filter((scene) => {
			if (scene.locked) return false;
			if (onlyId) return scene.id === onlyId;
			return !scene.imageUrl;
		});
		if (!targets.length) {
			setNotice(prepared.scenes.some((scene) => scene.locked) ? "Source panels stay as they are. Nothing was redrawn." : "The open panels are already painted.");
			setBusy(null);
			return;
		}
		const call = session();
		let cursor = prepared;
		let usedFallback = false;
		for (let index = 0; index < targets.length; index += 1) {
			const scene = cursor.scenes.find((item) => item.id === targets[index]?.id) ?? targets[index];
			if (!scene) continue;
			let accepted = null;
			let note = "";
			const tries = Math.min(3, Math.max(1, Number(retries) || 3));
			for (let attempt = 1; attempt <= tries; attempt += 1) {
				setBusy(attempt === 1 ? `Painting panel ${index + 1} of ${targets.length}` : `Panel ${index + 1} did not match. Retry ${attempt} of ${tries}. Later panels are waiting.`);
				try {
					const lock = lookLockForScene(scene, cursor.characters);
					const result = await paintPanel({ data: {
						prompt: [scene.imagePrompt, lock].filter(Boolean).join("\n"),
						reference: faceReferenceFor(scene, cursor.characters),
						repo: imageRepo.trim(),
						...call
					} });
					if (!result.ok) {
						setError(result.error);
						setBusy(null);
						return;
					}
					if (result.fallback) usedFallback = true;
					const check = await checkPanel({ data: {
						prompt: scene.imagePrompt,
						imageUrl: result.url,
						...call
					} });
					if (check.ok && check.match === "no" && attempt < tries) {
						note = check.note || "Face or scene did not match.";
						continue;
					}
					accepted = result.url;
					note = check.ok ? check.note : "";
					if (check.ok && check.match === "no") note = note || `Still off after ${tries} tries.`;
					break;
				} catch (err) {
					setError(err instanceof Error ? err.message : "Painting stopped.");
					setBusy(null);
					return;
				}
			}
			if (!accepted) {
				setError("That panel failed three times. The queue is stopped. Pictures already accepted were kept.");
				setBusy(null);
				return;
			}
			const failed = note.startsWith("Still off");
			const mentioned = cursor.characters.filter((character) => [
				scene.caption,
				scene.dialogue,
				scene.speaker,
				scene.imagePrompt
			].join("\n").includes(character.name));
			const faceOwner = mentioned.length === 1 ? mentioned[0] : void 0;
			cursor = {
				...cursor,
				characters: cursor.characters.map((character) => {
					if (character.faceUrl || !faceOwner || character.id !== faceOwner.id) return character;
					return {
						...character,
						faceUrl: accepted
					};
				}),
				scenes: cursor.scenes.map((item) => item.id === scene.id ? {
					...item,
					imageUrl: accepted,
					checkNote: note,
					retries: failed ? tries : item.retries
				} : item)
			};
			setProject(cursor);
			if (failed) {
				setError(`${note} Fix the prompt or retry this panel. The queue is stopped so the next picture does not start on a bad face.`);
				setBusy(null);
				setTab("strip");
				return;
			}
		}
		setBusy(null);
		setNotice(usedFallback ? "Free fallback painter finished one panel at a time. Faces can drift. Your Colab checkpoint is the real one. Connect the worker so the vision check can run." : "Panels painted one at a time. The first accepted face is kept as a reference.");
		setTab("strip");
	}
	(0, import_react.useEffect)(() => {
		setTrack(voiceCache.get(`narration:${language}`) ?? null);
	}, [project.narration, language]);
	async function onSpeak() {
		setError(null);
		primeSpeechUnlock();
		if (track) {
			try {
				await new Audio(track).play();
				setNotice("Played the saved voice.");
			} catch {
				setError("The track is ready, but this phone blocked playback. Tap again.");
			}
			return;
		}
		const text = sanitizeNovelText(project.narration) || project.narration;
		const synth = typeof window !== "undefined" ? window.speechSynthesis : void 0;
		const speech = { state: "failed" };
		if (synth) {
			speech.state = "reading";
			speakOnDevice(text, chooseVoice(synth.getVoices(), text)).then(() => {
				speech.state = "done";
			}, () => {
				speech.state = "failed";
			});
		}
		setBusy("Reading the chapter");
		try {
			const result = await speakLine({ data: {
				text,
				voice,
				...session()
			} });
			if (result.ok) {
				synth?.cancel();
				const src = `data:${result.mimeType || "audio/mpeg"};base64,${result.audioBase64}`;
				voiceCache.set(`narration:${language}`, src);
				setVoiced((current) => ({
					...current,
					[`narration:${language}`]: true
				}));
				setTrack(src);
				try {
					await new Audio(src).play();
					setNotice(`Played ${voice}.`);
				} catch {
					setNotice("The voice track is ready. Tap Read again to play it.");
				}
				return;
			}
			if (speech.state !== "failed") {
				setNotice("Reading on this phone.");
				return;
			}
			const voices = await loadVoices(1200);
			try {
				await speakOnDevice(text, chooseVoice(voices, text));
				setNotice("Reading on this phone.");
			} catch {
				setError("Voice did not start. Tap Read again.");
			}
		} catch (err) {
			if (speech.state !== "failed") {
				setNotice("Reading on this phone.");
				return;
			}
			setError(err instanceof Error ? err.message : "The reading stopped.");
		} finally {
			setBusy(null);
		}
	}
	async function onCopy(value, label) {
		const ok = await copyText(value);
		setNotice(ok ? `${label} copied.` : `Could not copy ${label.toLowerCase()} on this phone.`);
	}
	async function onVerifyApi() {
		setBusy("Verifying the API");
		setError(null);
		setApiBadge(null);
		try {
			const result = await verifyCloud({ data: session() });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setApiBadge(result.badge);
		} catch (err) {
			setError(err instanceof Error ? err.message : "The API check failed.");
		} finally {
			setBusy(null);
		}
	}
	async function onTestConnection(target) {
		const href = (target || workerUrl).trim();
		setBusy("Testing the worker");
		setError(null);
		setWorkerBadge(null);
		try {
			const result = await testWorker({ data: {
				url: href,
				token: workerToken
			} });
			if (!result.ok) {
				setError(result.body ? `${result.error} ${result.body}` : result.error);
				return;
			}
			if (target && target !== workerUrl) setWorkerUrl(target);
			setWorkerBadge("Connection Done — Local AI & GPU Worker Active");
			setNotice("Worker health answered.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "The worker did not answer.");
		} finally {
			setBusy(null);
		}
	}
	function packetNow(pass = "assemble", source = project) {
		const origin = typeof window !== "undefined" ? window.location.origin : "";
		const active = source.language === "hi" || source.language === "en" ? source.language : language;
		return jobPacket(projectWithAbsoluteArt({
			...source,
			language: active,
			voice: source.voice || EXPLAIN_VOICES[active],
			aspect,
			localModel,
			imageRepo: imageRepo.trim() || source.imageRepo,
			hook: source.hook
		}, origin), pass);
	}
	async function onSendJob(pass = "assemble", source) {
		jobPass.current = pass;
		const active = source?.language === "hi" || source?.language === "en" ? source.language : language;
		jobLanguage.current = active;
		setBusy(pass === "revoice" ? "Re-voicing. Pictures stay locked." : "Rendering the explanation video");
		setError(null);
		setWatchUrl(null);
		try {
			const result = await submitJob({ data: {
				url: workerUrl,
				token: workerToken,
				packet: packetNow(pass, source)
			} });
			if (!result.ok) {
				setError(pass === "revoice" ? `${result.error} Pictures were not touched.` : result.error);
				return;
			}
			if (result.jobId) {
				setJob({
					id: result.jobId,
					status: "queued",
					progress: 0,
					label: pass === "revoice" ? "Re-voicing" : "Accepted",
					error: "",
					mp4Url: null,
					timing: {},
					voices: {}
				});
				setNotice(pass === "revoice" ? "Worker is re-voicing the same pictures. Audio and captions only." : `Worker accepted the film. Watching job ${result.jobId}.`);
				setTab("bay");
			} else {
				setJob(null);
				setNotice("Worker accepted the packet, but the reply had no job id.");
			}
		} catch (err) {
			setError(err instanceof Error ? err.message : "The worker did not take the job.");
		} finally {
			setBusy(null);
		}
	}
	const jobTerminal = !job || job.status === "done" || job.status === "error";
	(0, import_react.useEffect)(() => {
		if (!job?.id || jobTerminal || !workerUrl.trim()) return;
		const id = job.id;
		let stop = false;
		const tick = async () => {
			try {
				const result = await jobStatus({ data: {
					url: workerUrl,
					token: workerToken,
					jobId: id
				} });
				if (stop) return;
				if (!result.ok) {
					setJob((current) => current && current.id === id ? {
						...current,
						status: "error",
						error: result.error
					} : current);
					return;
				}
				const nextJob = {
					...result.job,
					label: shownLabel(result.job.label, jobPass.current)
				};
				setJob(nextJob);
				if (nextJob.status === "done") {
					const slot = jobLanguage.current;
					setMasters((current) => ({
						...current,
						[slot]: true
					}));
					if (Object.keys(nextJob.timing).length || Object.keys(nextJob.voices).length) {
						setProject((current) => applyWorkerAssets(current, nextJob.timing, nextJob.voices, slot));
						setVoiced((current) => {
							const marked = { ...current };
							for (const id of Object.keys(nextJob.voices)) marked[`${id}:${slot}`] = true;
							return marked;
						});
					}
				}
			} catch (err) {
				if (stop) return;
				setJob((current) => current && current.id === id ? {
					...current,
					status: "error",
					error: err instanceof Error ? err.message : "The status check stopped."
				} : current);
			}
		};
		tick();
		const timer = window.setInterval(() => void tick(), 2500);
		return () => {
			stop = true;
			window.clearInterval(timer);
		};
	}, [
		job?.id,
		jobTerminal,
		workerUrl,
		workerToken
	]);
	async function onPreview() {
		setBusy("Loading the 6 second preview");
		setError(null);
		try {
			const res = await fetch("/api/studio/mp4", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					kind: "preview",
					url: workerUrl,
					token: workerToken,
					jobId: job?.id
				})
			});
			if (!res.ok) {
				const data = await res.json().catch(() => null);
				setError(data?.error || "The preview did not load.");
				return;
			}
			const blob = await res.blob();
			if (previewUrl) URL.revokeObjectURL(previewUrl);
			setPreviewUrl(URL.createObjectURL(blob));
			setNotice("Six second preview is in the player. The full file stayed on the worker.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "The preview did not load.");
		} finally {
			setBusy(null);
		}
	}
	async function onConnectYoutube() {
		const clientId = ytClientId.trim();
		if (!clientId) {
			setError("Paste the Google OAuth client id first. It stays in this tab only.");
			return;
		}
		setError(null);
		setBusy("Opening Google");
		try {
			await loadGis();
			const google = googleAccounts();
			if (!google) throw new Error("Google sign-in did not load.");
			google.accounts.oauth2.initTokenClient({
				client_id: clientId,
				scope: "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly openid email",
				callback: (resp) => {
					if (!resp.access_token) {
						setError(resp.error || "Google did not return a token.");
						setBusy(null);
						return;
					}
					setYtToken(resp.access_token);
					const slot = language;
					setChannels((current) => ({
						...current,
						[slot]: {
							token: resp.access_token || "",
							email: current[slot].email,
							channel: current[slot].channel
						}
					}));
					(async () => {
						try {
							const [channelRes, userRes] = await Promise.all([fetch("https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true", { headers: { Authorization: `Bearer ${resp.access_token}` } }), fetch("https://www.googleapis.com/oauth2/v3/userinfo", { headers: { Authorization: `Bearer ${resp.access_token}` } })]);
							const channelJson = await channelRes.json();
							const userJson = await userRes.json();
							setYtChannel(channelJson.items?.[0]?.snippet?.title || "");
							setYtEmail(userJson.email || "");
							setChannels((current) => ({
								...current,
								[slot]: {
									token: resp.access_token || "",
									email: userJson.email || "",
									channel: channelJson.items?.[0]?.snippet?.title || ""
								}
							}));
							setNotice(slot === "hi" ? "Hindi channel connected. Upload sends the Hindi master. Pictures are not redrawn." : "English channel connected. Upload sends the English master.");
						} catch {
							setNotice("Token received. Channel details did not load.");
						} finally {
							setBusy(null);
						}
					})();
				}
			}).requestAccessToken({ prompt: "select_account" });
		} catch (err) {
			setError(err instanceof Error ? err.message : "Google did not open.");
			setBusy(null);
		}
	}
	async function onUpload() {
		if (!job || job.status !== "done") {
			setError("Render the video on the worker, then scrub the preview. The full film stays there.");
			return;
		}
		if (!previewSeen && !previewUrl) {
			setError("Scrub the preview first. Nothing uploads until you have watched it.");
			return;
		}
		const slotToken = channels[language].token || ytToken;
		if (!slotToken) {
			setError(language === "hi" ? "Connect the Hindi YouTube channel first." : "Connect the English YouTube channel first.");
			return;
		}
		setBusy("Uploading from the worker");
		setError(null);
		const tags = parseTags(tagDraft);
		try {
			const result = await uploadYoutube({ data: {
				url: workerUrl,
				token: workerToken,
				jobId: job.id,
				accessToken: slotToken,
				title: project.seo.title,
				description: [project.seo.description, project.seo.hashtags].filter(Boolean).join("\n\n"),
				tags,
				privacy: youtubePrivacy(project.seo.privacy),
				language
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setWatchUrl(result.watchUrl);
			setNotice("Uploaded. The watch link is below.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "The upload did not finish.");
		} finally {
			setBusy(null);
		}
	}
	async function onChat() {
		const message = chatDraft.trim();
		if (!message) return;
		setChatDraft("");
		setChatLog((current) => [...current, {
			role: "user",
			text: message
		}]);
		setBusy("Asking the studio AI");
		setError(null);
		try {
			const beats = project.scenes.slice(0, 40).map((scene) => `${scene.id}: ${voiceLine(scene, language).slice(0, 90)}`).join("\n");
			const names = project.characters.map((character) => character.name).filter(Boolean).join(", ");
			const context = `${project.title}. Language ${language}. ${project.scenes.length} panels. Pictures stay on a language switch. Cast: ${names || "none"}.\nBeats:\n${beats}\n${project.bible ? `Look lock: ${project.bible.slice(0, 500)}` : ""}`;
			const result = await chatTurn({ data: {
				message,
				context,
				...session()
			} });
			if (!result.ok) {
				setChatLog((current) => [...current, {
					role: "studio",
					text: result.error
				}]);
				return;
			}
			setChatLog((current) => [...current, {
				role: "studio",
				text: result.reply
			}]);
			if (result.action?.type === "line") {
				const action = result.action;
				if (!project.scenes.some((scene) => scene.id === action.id)) setNotice(`No beat ${action.id}. The line was not changed.`);
				else {
					setProject((current) => ({
						...current,
						scenes: current.scenes.map((scene) => {
							if (scene.id !== action.id) return scene;
							const next = {
								...scene,
								caption: action.text,
								dialogue: ""
							};
							if (language === "hi") return {
								...next,
								captionHi: action.text,
								dialogueHi: "",
								lineHi: action.text
							};
							return {
								...next,
								captionEn: action.text,
								dialogueEn: "",
								lineEn: action.text
							};
						})
					}));
					setNotice(`Beat ${action.id} updated. Pictures were not redrawn.`);
				}
			}
			if (result.action?.type === "look") {
				const action = result.action;
				if (!project.characters.some((character) => character.name.toLowerCase() === action.name.toLowerCase())) setNotice(`No character named ${action.name}. The look was not changed.`);
				else {
					setProject((current) => {
						const characters = current.characters.map((character) => character.name.toLowerCase() === action.name.toLowerCase() ? applyLookPatch(character, action) : character);
						return {
							...current,
							characters,
							bible: bibleDocument(characters)
						};
					});
					setNotice(`${action.name} look updated. Pictures were not redrawn.`);
				}
			}
		} catch (err) {
			setChatLog((current) => [...current, {
				role: "studio",
				text: err instanceof Error ? err.message : "The assistant did not answer."
			}]);
		} finally {
			setBusy(null);
		}
	}
	async function onPlayPanels() {
		setError(null);
		primeSpeechUnlock();
		const scenes = project.scenes;
		if (!scenes.length) return;
		for (let index = playAt; index < scenes.length; index += 1) {
			setPlayAt(index);
			const scene = scenes[index];
			if (!scene) break;
			const line = voiceLine(scene, language);
			const key = `${scene.id}:${language}`;
			const savedPath = language === "hi" ? scene.voiceHi : scene.voiceEn;
			const cached = voiceCache.get(key) || (savedPath ? absVoice(savedPath) : "");
			if (cached) {
				try {
					await new Audio(cached).play();
				} catch {
					setError("Playback was blocked. Tap Play again.");
					return;
				}
				await new Promise((resolve) => window.setTimeout(resolve, 400));
				continue;
			}
			setBusy(`Reading panel ${index + 1} of ${scenes.length}`);
			try {
				const result = await speakLine({ data: {
					text: line,
					voice,
					sceneId: scene.id,
					...session()
				} });
				if (result.ok) {
					const src = result.audioBase64 ? `data:${result.mimeType || "audio/mpeg"};base64,${result.audioBase64}` : absVoice(result.audioUrl || "");
					rememberVoice(scene.id, language, src, result.audioUrl);
					if (src) await new Audio(src).play();
				} else await speakOnDevice(line, null);
			} catch {
				try {
					await speakOnDevice(line, null);
				} catch {
					setError("Voice did not start. Pictures were not touched.");
					setBusy(null);
					return;
				}
			}
		}
		setBusy(null);
		setNotice("Preview played the saved pictures with this language only.");
	}
	function patchScene(id, patch) {
		setProject((current) => ({
			...current,
			scenes: current.scenes.map((scene) => {
				if (scene.id !== id) return scene;
				const nextScene = {
					...scene,
					...patch
				};
				const line = [nextScene.caption, nextScene.dialogue].filter(Boolean).join(" ").trim();
				if (language === "hi") return {
					...nextScene,
					captionHi: nextScene.caption,
					dialogueHi: nextScene.dialogue,
					lineHi: line
				};
				return {
					...nextScene,
					captionEn: nextScene.caption,
					dialogueEn: nextScene.dialogue,
					lineEn: line
				};
			})
		}));
	}
	const tabs = [
		{
			id: "story",
			label: "Source",
			icon: ScrollText
		},
		{
			id: "strip",
			label: "Beats",
			icon: Clapperboard
		},
		{
			id: "forge",
			label: "Cast",
			icon: Sparkles
		},
		{
			id: "chat",
			label: "Chat",
			icon: MessageCircle
		},
		{
			id: "bay",
			label: "Video",
			icon: Factory
		},
		{
			id: "youtube",
			label: "Upload",
			icon: Youtube
		}
	];
	const tagsKey = project.seo.tags.join("|");
	(0, import_react.useEffect)(() => {
		if (seenTags.current === tagsKey) return;
		seenTags.current = tagsKey;
		setTagDraft(project.seo.tags.join(", "));
	}, [tagsKey]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-dvh max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center gap-3 bg-ink/95 px-4 py-3 backdrop-blur",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/favicon.svg",
						alt: "",
						className: "size-9 shrink-0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-cinnabar",
							children: "AETHER STUDIO"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-xl text-paper",
							children: project.title
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ml-auto shrink-0 rounded-full bg-panel px-3 py-1 text-xs text-muted",
						children: sourceLabel(project.source)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Settings",
						"aria-pressed": showSettings,
						onClick: () => setShowSettings((open) => !open),
						className: `flex size-11 shrink-0 items-center justify-center rounded-full ${showSettings ? "bg-seal text-paper" : "bg-panel text-paper"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
							className: "size-5",
							"aria-hidden": true
						})
					})
				]
			}),
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-paper",
					children: busy
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-0.5 overflow-hidden bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grow-bar h-full bg-cinnabar" })
				})]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mx-4 mt-3 rounded-2xl bg-panel px-4 py-3 text-sm text-paper",
				children: error
			}) : null,
			notice && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-4 mt-3 text-sm text-muted",
				children: notice
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "screen-pad px-4 pt-4",
				children: [
					showSettings ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-paper",
								children: "Settings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Keys, tokens, notebook links, and the YouTube token live in this tab’s memory only. Refresh clears them. Nothing is written to storage."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "ai-provider",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium text-paper",
										children: "AI provider"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "ai-provider",
										value: provider,
										onChange: (event) => chooseProvider(event.target.value),
										className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base",
										children: PROVIDER_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: id,
											children: PROVIDER_PRESETS[id].label
										}, id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-xs text-muted",
										children: preset.hint
									})
								]
							}),
							preset.models.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "ai-model",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Model"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "ai-model",
									value: modelId,
									onChange: (event) => {
										setModelId(event.target.value);
										setApiBadge(null);
									},
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base",
									children: preset.models.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: model.id,
										children: model.label
									}, model.id))
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "custom-model",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium text-paper",
										children: "Model ID"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "custom-model",
										value: customModel,
										onChange: (event) => {
											setCustomModel(event.target.value);
											setApiBadge(null);
										},
										placeholder: modelId || "glm-5.2",
										autoComplete: "off",
										spellCheck: false,
										className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-xs text-muted",
										children: "Any id overrides the list. Leave this empty to use the selected model."
									})
								]
							}),
							provider === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "custom-base",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "OpenAI-compatible base URL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "custom-base",
									value: customBase,
									onChange: (event) => setCustomBase(event.target.value),
									placeholder: "https://host/v1",
									inputMode: "url",
									autoComplete: "off",
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "api-key",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center justify-between gap-3 text-sm font-medium text-paper",
									children: [
										"API key ",
										provider === "github" ? "(GitHub PAT)" : "",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setRevealKey((open) => !open),
											className: "text-xs font-semibold text-cinnabar",
											children: revealKey ? "Hide" : "Show"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "api-key",
									type: revealKey ? "text" : "password",
									value: apiKey,
									onChange: (event) => {
										setApiKey(event.target.value);
										setApiBadge(null);
									},
									placeholder: provider === "github" ? "ghp_… or github_pat_…" : "Paste a key. It is not saved.",
									autoComplete: "off",
									autoCapitalize: "off",
									autoCorrect: "off",
									spellCheck: false,
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onVerifyApi,
								disabled: !!busy || !apiKey.trim(),
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: "Verify & Connect API"
							}),
							apiBadge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "badge-ok rounded-xl px-3 py-2 text-sm font-semibold",
								children: apiBadge
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "local-mode",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Local model if the cloud key is missing or limited"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "local-mode",
									value: localModel,
									onChange: (event) => setLocalModel(event.target.value),
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base",
									children: LOCAL_MODES.map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: mode.id,
										children: mode.label
									}, mode.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium text-paper",
								children: "Explanation & voiceover language"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-1 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": language === "hi",
									onClick: () => void onPickLanguage("hi"),
									className: `min-h-12 rounded-xl px-3 text-left text-sm font-semibold ${language === "hi" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "Hindi re-voice · hi-IN-MadhurNeural"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": language === "en",
									onClick: () => void onPickLanguage("en"),
									className: `min-h-12 rounded-xl px-3 text-left text-sm font-semibold ${language === "en" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "English re-voice · en-US-ChristopherNeural"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "voice-en",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "English male voice"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "voice-en",
									value: voiceEn,
									onChange: (event) => {
										setVoiceEn(event.target.value);
										for (const key of [...voiceCache.keys()]) if (key.endsWith(":en") || key === "narration:en") voiceCache.delete(key);
										setVoiced((current) => {
											const next = { ...current };
											for (const key of Object.keys(next)) if (key.endsWith(":en")) delete next[key];
											return next;
										});
										setMasters((current) => ({
											...current,
											en: false
										}));
									},
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "en-US-ChristopherNeural",
										children: "Christopher"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "en-US-AndrewNeural",
										children: "Andrew"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "voice-hi",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Hindi male voice"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "voice-hi",
									value: voiceHi,
									onChange: (event) => {
										setVoiceHi(event.target.value);
										for (const key of [...voiceCache.keys()]) if (key.endsWith(":hi") || key === "narration:hi") voiceCache.delete(key);
										setVoiced((current) => {
											const next = { ...current };
											for (const key of Object.keys(next)) if (key.endsWith(":hi")) delete next[key];
											return next;
										});
										setMasters((current) => ({
											...current,
											hi: false
										}));
									},
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "hi-IN-MadhurNeural",
										children: "Madhur"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "retry-count",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Vision retries per panel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "retry-count",
									value: retries,
									onChange: (event) => setRetries(event.target.value),
									inputMode: "numeric",
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium text-paper",
								children: "Frame"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: ["9:16", "16:9"].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": aspect === option,
									onClick: () => setAspect(option),
									className: `min-h-12 rounded-xl text-sm font-semibold ${aspect === option ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: option === "9:16" ? "9:16 vertical" : "16:9 wide"
								}, option))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "text-sm font-medium text-paper",
									children: "Who writes, who draws"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 grid grid-cols-1 gap-2",
									children: [
										["split", "Split — key writes and checks. Worker draws, speaks, and cuts."],
										["worker", "Worker does the writing too."],
										["key", "Key only for text. Pictures use the free fallback if no worker draw is allowed."]
									].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": duty === id,
										onClick: () => setDuty(id),
										className: `min-h-12 rounded-xl px-3 text-left text-sm font-semibold ${duty === id ? "bg-seal text-paper" : "bg-panel text-paper"}`,
										children: label
									}, id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted",
									children: "Default is split. A language switch still does not redraw."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "image-repo",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium text-paper",
										children: "Image checkpoint"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "image-repo",
										value: imageRepo,
										onChange: (event) => setImageRepo(event.target.value),
										placeholder: "cagliostrolab/animagine-xl-3.1 or a Flux repo",
										autoComplete: "off",
										spellCheck: false,
										className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-xs text-muted",
										children: "Empty keeps the worker default. A repo name with “flux” loads Flux and can use the saved face. If that model cannot load, Pollinations runs, then a simple ink drawing. Faces can drift on the fallback."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "worker-url",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Live worker URL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "worker-url",
									value: workerUrl,
									onChange: (event) => {
										setWorkerUrl(event.target.value);
										setWorkerBadge(null);
									},
									placeholder: "https://….trycloudflare.com",
									inputMode: "url",
									autoComplete: "off",
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "worker-token",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Worker token"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "worker-token",
									type: "password",
									value: workerToken,
									onChange: (event) => setWorkerToken(event.target.value),
									autoComplete: "off",
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onTestConnection(),
								disabled: !!busy || !workerUrl.trim(),
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: "Test & Connect"
							}),
							workerBadge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "badge-ok rounded-xl px-3 py-2 text-sm font-semibold",
								children: workerBadge
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BenchLinks, {
								colabUrl,
								kaggleUrl,
								onColab: setColabUrl,
								onKaggle: setKaggleUrl,
								onTest: (value) => onTestConnection(/trycloudflare\.com|ngrok/i.test(value) ? value : workerUrl),
								busy: !!busy,
								badge: workerBadge
							})
						]
					}) : null,
					!showSettings && tab === "story" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-paper",
								children: "Explain the chapter"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Chinese from WTR-LAB is translated by the active model into a Hindi or English manhua explanation. Nothing is stored on this phone."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "text-sm font-medium text-paper",
									children: "Explanation & voiceover language"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": language === "hi",
										onClick: () => void onPickLanguage("hi"),
										className: `min-h-12 rounded-xl px-2 text-sm font-semibold ${language === "hi" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
										children: "Hindi"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": language === "en",
										onClick: () => void onPickLanguage("en"),
										className: `min-h-12 rounded-xl px-2 text-sm font-semibold ${language === "en" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
										children: "English"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted",
									children: "Language change = audio, captions, and SEO only. Pictures stay."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium text-paper",
								children: "Source"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": sourceMode === "text",
									onClick: () => setSourceMode("text"),
									className: `min-h-12 rounded-xl px-2 text-sm font-semibold ${sourceMode === "text" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "Text only"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": sourceMode === "panels",
									onClick: () => setSourceMode("panels"),
									className: `min-h-12 rounded-xl px-2 text-sm font-semibold ${sourceMode === "panels" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "Picture manhua"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Chapter script"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: draft,
									onChange: (event) => setDraft(event.target.value),
									onPaste: (event) => {
										const pasted = event.clipboardData.getData("text");
										if (!pasted) return;
										event.preventDefault();
										const start = event.currentTarget.selectionStart ?? draft.length;
										const end = event.currentTarget.selectionEnd ?? draft.length;
										setDraft(sanitizeNovelText(`${draft.slice(0, start)}${pasted}${draft.slice(end)}`));
									},
									className: "field mt-2 min-h-72 w-full rounded-2xl px-4 py-3 text-base outline-none",
									spellCheck: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onDirect,
								disabled: !!busy,
								className: "min-h-14 w-full rounded-2xl bg-seal px-3 text-sm font-semibold text-paper disabled:opacity-50",
								children: "AI Manhua Recap Director (GLM-5.2)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setProject(SAMPLE);
									setDraft(SAMPLE_TEXT);
									setNotice("Sample restored.");
								},
								className: "min-h-11 w-full text-sm font-semibold text-cinnabar",
								children: "Restore sample"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-ink-2 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-sm font-medium text-paper",
										htmlFor: "source-url",
										children: "Chapter link"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "source-url",
										value: url,
										onChange: (event) => setUrl(event.target.value),
										placeholder: "https://wtr-lab.com/…/chapter-1",
										inputMode: "url",
										className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-sm text-paper",
											htmlFor: "chapter-start",
											children: ["Start", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "chapter-start",
												value: rangeStart,
												onChange: (event) => setRangeStart(event.target.value),
												inputMode: "numeric",
												placeholder: "1",
												className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-sm text-paper",
											htmlFor: "chapter-end",
											children: ["End", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "chapter-end",
												value: rangeEnd,
												onChange: (event) => setRangeEnd(event.target.value),
												inputMode: "numeric",
												placeholder: "12",
												className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-sm text-paper",
											htmlFor: "bible-before",
											children: ["Chapters before (look only)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "bible-before",
												value: bibleBefore,
												onChange: (event) => setBibleBefore(event.target.value),
												inputMode: "numeric",
												className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-sm text-paper",
											htmlFor: "bible-after",
											children: ["Chapters after (look only)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "bible-after",
												value: bibleAfter,
												onChange: (event) => setBibleAfter(event.target.value),
												inputMode: "numeric",
												className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "mt-3 block text-sm text-paper",
										htmlFor: "source-cookie",
										children: ["Site cookie, only if the page is behind your login", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "source-cookie",
											value: sourceCookie,
											onChange: (event) => setSourceCookie(event.target.value),
											autoComplete: "off",
											spellCheck: false,
											placeholder: "Paste the cookie from a tab you are logged into",
											className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-muted",
										children: "Passwords are never asked. The cookie is sent only with that fetch and is not saved. Nearby chapters lock the character look and are not turned into panels."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: onFetch,
										disabled: !!busy || !url.trim(),
										className: "mt-3 min-h-12 w-full rounded-xl bg-panel text-sm font-semibold text-paper disabled:opacity-50",
										children: rangeStart.trim() || rangeEnd.trim() ? "Pull chapter range" : "Pull readable text"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-ink-2 p-4 text-xs leading-relaxed text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-paper",
										children: "Hard limits"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2",
										children: "This studio directs. Colab or Kaggle grows a long film and draws panels. A multi-hour file stays on the worker, not in the phone."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2",
										children: "Login walls work only with your cookie, and some sites still refuse. Paste the chapter when that happens."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2",
										children: "The picture check is a vision pass, not magic. After the retry count, you decide. Language change = audio, captions, and SEO only. Pictures stay. A longer line holds the same panel longer."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2",
										children: "Copyright stays with you. This is a production tool."
									})
								]
							})
						]
					}) : null,
					!showSettings && tab === "forge" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-paper",
								children: "Soul and vessel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: project.hook || project.logline
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "space-y-3",
								children: [project.characters.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-sm text-muted",
									children: "No named cast in this cut."
								}) : null, project.characters.map((character) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-2xl bg-ink-2 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-2xl text-paper",
											children: character.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "mt-3 block text-xs font-semibold tracking-widest text-cinnabar uppercase",
											htmlFor: `soul-${character.id}`,
											children: ["Soul", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												id: `soul-${character.id}`,
												value: character.soul,
												onChange: (event) => setProject((current) => ({
													...current,
													characters: current.characters.map((item) => item.id === character.id ? {
														...item,
														soul: event.target.value
													} : item)
												})),
												className: "field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm font-medium normal-case outline-none"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "mt-3 block text-xs font-semibold tracking-widest text-cinnabar uppercase",
											htmlFor: `look-${character.id}`,
											children: ["Locked look", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												id: `look-${character.id}`,
												value: character.look,
												onChange: (event) => patchCast(character.id, {
													look: event.target.value,
													vessel: event.target.value
												}, false),
												className: "field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm font-medium normal-case outline-none"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 grid grid-cols-2 gap-2",
											children: [
												["face", "Face"],
												["hair", "Hair"],
												["age", "Age"],
												["scars", "Scars"],
												["eyes", "Eyes"],
												["body", "Body"],
												["outfit", "Outfit"]
											].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "block text-xs font-semibold tracking-widest text-cinnabar uppercase",
												htmlFor: `${key}-${character.id}`,
												children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													id: `${key}-${character.id}`,
													value: character[key] || "",
													onChange: (event) => patchCast(character.id, { [key]: event.target.value }, true),
													className: "field mt-2 min-h-11 w-full rounded-xl px-3 text-sm font-medium normal-case outline-none"
												})]
											}, key))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "mt-3 block text-xs font-semibold tracking-widest text-cinnabar uppercase",
											htmlFor: `outfits-${character.id}`,
											children: ["Outfit changes, one chapter per line", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												id: `outfits-${character.id}`,
												value: outfitsToText(character.outfits),
												onChange: (event) => patchCast(character.id, { outfits: textToOutfits(event.target.value) }, true),
												placeholder: "420: black court robe\n460: travel cloak",
												className: "field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm font-medium normal-case outline-none"
											})]
										}),
										character.faceUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: character.faceUrl,
											alt: "",
											className: "mt-3 h-24 w-16 rounded-lg object-cover"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs text-muted",
											children: "The first accepted panel of this face is kept as a reference. A language switch does not replace it."
										})
									]
								}, character.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-paper",
								htmlFor: "bible-lock",
								children: ["Character bible", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "bible-lock",
									value: project.bible || bible,
									onChange: (event) => {
										setBible(event.target.value);
										setProject((current) => ({
											...current,
											bible: event.target.value
										}));
									},
									className: "field mt-2 min-h-28 w-full rounded-xl px-3 py-3 text-sm outline-none",
									placeholder: "Face, hair, scars, outfit, and the chapter an outfit changes. Written once. A language switch does not rebuild it."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void writeMissingPrompts(project),
								disabled: !!busy,
								className: "min-h-12 w-full rounded-2xl bg-panel text-sm font-semibold text-paper disabled:opacity-50",
								children: "Write prompts, one beat at a time"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void onPaint(),
								disabled: !!busy,
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: "Paint unpainted panels"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "One English prompt per beat, then one picture. The worker checkpoint draws it. If that model cannot load, the free fallback is used and faces can drift. A language switch does not come back here."
							})
						]
					}) : null,
					!showSettings && tab === "strip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-end justify-between gap-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl text-paper",
									children: "Explanation film"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2",
								role: "group",
								"aria-label": "Aspect ratio",
								children: ["16:9", "9:16"].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": aspect === option,
									onClick: () => setAspect(option),
									className: `min-h-12 rounded-xl text-sm font-semibold ${aspect === option ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: option === "16:9" ? "16:9 YouTube" : "9:16 Shorts"
								}, option))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [project.scenes.length, " panels. Play scrubs the pictures already made. A language switch does not send them back to the painter."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "overflow-hidden rounded-2xl bg-ink",
								children: [project.scenes[playAt]?.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: project.scenes[playAt]?.imageUrl || "",
									alt: "",
									className: aspect === "16:9" ? "aspect-video w-full object-cover" : "aspect-[9/16] max-h-[70vh] w-full object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-[9/16] items-end justify-center pb-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-widest text-muted uppercase",
										children: "Not painted"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-paper px-4 py-3 text-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-widest text-seal uppercase",
										children: language === "hi" ? "Hindi caption" : "English caption"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-lg leading-snug",
										children: project.scenes[playAt] ? voiceLine(project.scenes[playAt], language) : ""
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm text-paper",
								htmlFor: "panel-seek",
								children: [
									"Panel ",
									playAt + 1,
									" of ",
									Math.max(project.scenes.length, 1),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "panel-seek",
										type: "range",
										min: 0,
										max: Math.max(project.scenes.length - 1, 0),
										value: Math.min(playAt, Math.max(project.scenes.length - 1, 0)),
										onChange: (event) => setPlayAt(Number(event.target.value)),
										className: "mt-2 w-full"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void onPlayPanels(),
								disabled: !!busy || project.scenes.length === 0,
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: "Play from this panel"
							}),
							project.bible ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: ["Look lock: ", project.bible.slice(0, 220)]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: project.scenes.map((scene, index) => {
									const other = language === "hi" ? "en" : "hi";
									const otherLine = voiceLine(scene, other);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelArt, {
												scene,
												wide: aspect === "16:9"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted",
												children: [
													"Beat ",
													index + 1,
													scene.locked ? " · source panel, not redrawn" : "",
													" · ",
													"EN voice ",
													voiced[`${scene.id}:en`] ? "saved" : "missing",
													" · ",
													"HI voice ",
													voiced[`${scene.id}:hi`] ? "saved" : "missing",
													scene.checkNote ? ` · ${scene.checkNote}` : ""
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "block text-sm text-paper",
												htmlFor: `line-${scene.id}`,
												children: [language === "hi" ? "Hindi line" : "English line", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
													id: `line-${scene.id}`,
													value: [scene.caption, scene.dialogue].filter(Boolean).join("\n"),
													onChange: (event) => patchScene(scene.id, {
														caption: event.target.value,
														dialogue: ""
													}),
													className: "field mt-2 min-h-20 w-full rounded-xl px-3 py-2 text-sm outline-none"
												})]
											}),
											otherLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted",
												children: [
													other === "hi" ? "Hindi" : "English",
													" kept: ",
													otherLine
												]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-muted",
												children: [other === "hi" ? "Hindi" : "English", " line is not written yet. A language switch translates this beat only."]
											}),
											scene.locked ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "block text-sm text-paper",
												htmlFor: `prompt-${scene.id}`,
												children: ["Image prompt, English", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
													id: `prompt-${scene.id}`,
													value: scene.imagePrompt,
													onChange: (event) => setProject((current) => ({
														...current,
														scenes: current.scenes.map((item) => item.id === scene.id ? {
															...item,
															imagePrompt: event.target.value,
															promptLocked: event.target.value.trim().length > 0
														} : item)
													})),
													className: "field mt-2 min-h-24 w-full rounded-xl px-3 py-2 text-sm outline-none"
												})]
											}),
											scene.locked ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => void onPaint(scene.id),
												disabled: !!busy,
												className: "min-h-11 rounded-xl bg-panel px-4 text-sm font-semibold text-paper disabled:opacity-50",
												children: "Retry this panel"
											})
										]
									}, scene.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void onSendJob(),
								disabled: !!busy || !workerUrl.trim(),
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: "Render explanation video"
							})
						]
					}) : null,
					!showSettings && tab === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-paper",
								children: "Chat"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Same AI as the director. It can see this project. Correct a look or a line here. A language change does not redraw."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: chatLog.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: `rounded-2xl px-4 py-3 text-sm ${entry.role === "user" ? "bg-seal text-paper" : "bg-ink-2 text-paper"}`,
									children: entry.text
								}, `${entry.role}-${index}`))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "flex gap-2",
								onSubmit: (event) => {
									event.preventDefault();
									onChat();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "min-w-0 flex-1",
									htmlFor: "chat-draft",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Message"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "chat-draft",
										value: chatDraft,
										onChange: (event) => setChatDraft(event.target.value),
										placeholder: "The scar is on the left cheek",
										className: "field min-h-12 w-full rounded-xl px-3 text-base outline-none"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: !!busy || !chatDraft.trim(),
									className: "min-h-12 rounded-xl bg-seal px-4 text-sm font-semibold text-paper disabled:opacity-50",
									children: "Send"
								})]
							}),
							chatLog.some((entry) => entry.role === "studio") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									const last = [...chatLog].reverse().find((entry) => entry.role === "studio");
									if (!last) return;
									setBible((current) => [current, last.text].filter(Boolean).join("\n"));
									setProject((current) => ({
										...current,
										bible: [current.bible, last.text].filter(Boolean).join("\n")
									}));
									setNotice("Saved into the character bible. Pictures were not redrawn.");
								},
								className: "min-h-11 text-sm font-semibold text-cinnabar",
								children: "Lock the last reply into the character bible"
							}) : null
						]
					}) : null,
					!showSettings && tab === "bay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl text-paper",
								children: "Factory bay"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: workerUrl.trim() ? "The worker keeps the long file. Scrub the master here. Language change = audio, captions, and SEO only. Pictures stay." : "The worker is offline. Scrub the panels on Beats. This phone will not pretend a full film is ready."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": language === "en",
									onClick: () => void onPickLanguage("en"),
									className: `min-h-12 rounded-xl text-sm font-semibold ${language === "en" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "English audio"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": language === "hi",
									onClick: () => void onPickLanguage("hi"),
									className: `min-h-12 rounded-xl text-sm font-semibold ${language === "hi" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "Hindi audio"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-2xl bg-ink",
								children: filmSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									src: filmSrc,
									controls: true,
									playsInline: true,
									preload: "metadata",
									className: "aspect-[9/16] max-h-[70vh] w-full bg-ink",
									onLoadedData: () => {
										setPreviewSeen(true);
										setPreviewBroken(false);
									},
									onError: () => setPreviewBroken(true)
								}, filmSrc) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-[9/16] max-h-80 items-end justify-center pb-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-4 text-center text-xs font-semibold tracking-widest text-muted uppercase",
										children: "Worker offline"
									})
								})
							}),
							previewBroken ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-paper",
								children: [
									"The worker is offline, or the ",
									language === "hi" ? "Hindi" : "English",
									" master is not ready. Pictures were not redrawn."
								]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-ink-2 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
											className: "size-4 text-cinnabar",
											"aria-hidden": true
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-lg text-paper",
											children: ["Narration · ", voice]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-paper",
										children: project.narration
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: onSpeak,
										disabled: !!busy,
										className: "mt-3 min-h-12 w-full rounded-xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
										children: "Read it"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void fillVoices(project, language, true),
										disabled: !!busy,
										className: "mt-2 min-h-12 w-full rounded-xl bg-panel text-sm font-semibold text-paper disabled:opacity-50",
										children: "Re-voice missing lines"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-ink-2 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg text-paper",
										children: language === "hi" ? "Hindi captions" : "English captions"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "mt-2 max-h-40 overflow-auto text-xs text-paper",
										children: srtFor(project, language)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => onCopy(srtFor(project, language), language === "hi" ? "Hindi captions" : "English captions"),
										className: "mt-2 min-h-11 text-sm font-semibold text-cinnabar",
										children: "Copy this .srt"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-muted",
										children: "The other language keeps its own captions. Silence is trimmed on the worker after each voice, without cutting a breath inside a line."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void onSendJob(),
								disabled: !!busy || !workerUrl.trim(),
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: "Send film to worker"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-ink-2 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg text-paper",
									children: "Render status"
								}), job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3",
									"aria-live": "polite",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-paper",
											children: [
												job.id,
												" · ",
												job.status,
												job.label ? ` · ${job.label}` : ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-2 h-2 overflow-hidden rounded-full bg-line",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-cinnabar",
												style: { width: `${job.progress}%` }
											})
										}),
										job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-paper",
											children: job.error
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void onSendJob(),
											disabled: !!busy,
											className: "mt-3 min-h-12 w-full rounded-xl bg-panel text-sm font-semibold text-paper disabled:opacity-50",
											children: "Render again"
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: "No job yet. Connect the worker, then render."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowCell((value) => !value),
								className: "min-h-11 text-sm font-semibold text-cinnabar",
								children: showCell ? "Hide factory cell" : "Show factory cell"
							}),
							showCell ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "max-h-80 overflow-auto rounded-2xl bg-ink-2 p-3 text-xs text-paper",
								children: FACTORY_CELL
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onCopy(FACTORY_CELL, "Factory cell"),
								className: "mt-2 min-h-11 rounded-xl bg-panel px-4 text-sm text-paper",
								children: "Copy factory cell"
							})] }) : null
						]
					}) : null,
					!showSettings && tab === "youtube" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						"aria-labelledby": "youtube-heading",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "youtube-heading",
								className: "text-3xl text-paper",
								children: "YouTube"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-muted",
								children: [
									"Preview first. Upload uses the ",
									language === "hi" ? "Hindi" : "English",
									" channel and that language’s master. The phone does not hold the full file. Nothing uploads until you press Upload."
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-2xl bg-ink",
								children: filmSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									src: filmSrc,
									controls: true,
									playsInline: true,
									preload: "metadata",
									className: "aspect-[9/16] max-h-[70vh] w-full bg-ink",
									onLoadedData: () => {
										setPreviewSeen(true);
										setPreviewBroken(false);
									},
									onError: () => setPreviewBroken(true)
								}, `yt-${filmSrc}`) : previewUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									src: previewUrl,
									controls: true,
									playsInline: true,
									className: "aspect-video w-full bg-ink",
									onLoadedData: () => setPreviewSeen(true)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-[9/16] max-h-80 items-end justify-center pb-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-widest text-muted uppercase",
										children: "No preview yet"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": language === "en",
									onClick: () => void onPickLanguage("en"),
									className: `min-h-12 rounded-xl text-sm font-semibold ${language === "en" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "English master"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": language === "hi",
									onClick: () => void onPickLanguage("hi"),
									className: `min-h-12 rounded-xl text-sm font-semibold ${language === "hi" ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: "Hindi master"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onPreview,
								disabled: !!busy || !workerUrl.trim(),
								className: "min-h-12 w-full rounded-2xl bg-panel text-sm font-semibold text-paper disabled:opacity-50",
								children: "Load a short preview if the worker stream will not play"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "yt-client",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Google OAuth client id"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "yt-client",
									value: ytClientId,
									onChange: (event) => setYtClientId(event.target.value),
									autoComplete: "off",
									spellCheck: false,
									placeholder: "….apps.googleusercontent.com",
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: `rounded-xl px-3 py-3 ${channels.en.token ? "badge-ok" : "bg-panel text-paper"}`,
									children: ["English channel ", channels.en.channel || channels.en.email || (channels.en.token ? "connected" : "not connected")]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: `rounded-xl px-3 py-3 ${channels.hi.token ? "badge-ok" : "bg-panel text-paper"}`,
									children: ["Hindi channel ", channels.hi.channel || channels.hi.email || (channels.hi.token ? "connected" : "not connected")]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onConnectYoutube,
								disabled: !!busy,
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: language === "hi" ? "Connect Hindi channel" : "Connect English channel"
							}),
							channels[language].token || ytToken ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "badge-ok rounded-xl px-3 py-2 text-sm font-semibold",
								children: [(language === "hi" ? channels.hi.email : channels.en.email) || ytEmail || "Account connected", (language === "hi" ? channels.hi.channel : channels.en.channel) || ytChannel ? ` · ${(language === "hi" ? channels.hi.channel : channels.en.channel) || ytChannel}` : ""]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "yt-title",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Title"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "yt-title",
									value: project.seo.title,
									maxLength: 100,
									onChange: (event) => setProject((current) => ({
										...current,
										seo: {
											...current.seo,
											title: event.target.value
										}
									})),
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "yt-description",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "yt-description",
									value: project.seo.description,
									maxLength: 5e3,
									onChange: (event) => setProject((current) => ({
										...current,
										seo: {
											...current.seo,
											description: event.target.value
										}
									})),
									className: "field mt-2 min-h-32 w-full rounded-xl px-3 py-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "yt-tags",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Tags"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "yt-tags",
									value: tagDraft,
									onChange: (event) => setTagDraft(event.target.value),
									onBlur: () => setProject((current) => ({
										...current,
										seo: {
											...current.seo,
											tags: parseTags(tagDraft)
										}
									})),
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								htmlFor: "yt-hash",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-paper",
									children: "Hashtags"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "yt-hash",
									value: project.seo.hashtags || "",
									onChange: (event) => setProject((current) => ({
										...current,
										seo: {
											...current.seo,
											hashtags: event.target.value
										}
									})),
									className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									"private",
									"unlisted",
									"public"
								].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": youtubePrivacy(project.seo.privacy) === option,
									onClick: () => setProject((current) => ({
										...current,
										seo: {
											...current.seo,
											privacy: option
										}
									})),
									className: `min-h-11 rounded-xl px-2 text-sm font-semibold capitalize ${youtubePrivacy(project.seo.privacy) === option ? "bg-seal text-paper" : "bg-panel text-paper"}`,
									children: option
								}, option))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: onUpload,
								disabled: !!busy || !(channels[language].token || ytToken) || !previewSeen && !previewUrl,
								className: "min-h-12 w-full rounded-2xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
								children: [
									"Upload to the ",
									language === "hi" ? "Hindi" : "English",
									" channel"
								]
							}),
							watchUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: watchUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "block text-sm font-semibold text-cinnabar",
								children: watchUrl
							}) : null
						]
					}) : null
				]
			}),
			!showSettings && tab !== "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setShowSettings(false);
					setTab("chat");
				},
				className: "fixed right-4 bottom-20 z-30 flex min-h-12 items-center gap-2 rounded-full bg-seal px-4 text-sm font-semibold text-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
					className: "size-4",
					"aria-hidden": true
				}), "Chat"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock-safe fixed inset-x-0 bottom-0 z-20 border-t border-line bg-ink/95 backdrop-blur",
				"aria-label": "Studio",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-6",
					children: tabs.map((item) => {
						const Icon = item.icon;
						const active = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setShowSettings(false);
								setTab(item.id);
							},
							"aria-current": active ? "page" : void 0,
							className: `flex min-h-14 min-w-0 flex-col items-center justify-center gap-1 px-0.5 text-[10px] leading-none whitespace-nowrap ${active ? "text-cinnabar" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": true
							}), item.label]
						}, item.id);
					})
				})
			})
		]
	});
}
function BenchLinks({ colabUrl, kaggleUrl, onColab, onKaggle, onTest, busy, badge }) {
	const colab = safeHttp(colabUrl);
	const kaggle = safeHttp(kaggleUrl);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl bg-ink-2 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg text-paper",
				children: "Colab and Kaggle"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Notebook links are not saved. Test hits the live worker health check."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				htmlFor: "colab-url",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium text-paper",
					children: "Colab URL"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "colab-url",
					value: colabUrl,
					onChange: (event) => onColab(event.target.value),
					placeholder: "https://colab.research.google.com/…",
					inputMode: "url",
					autoComplete: "off",
					className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: colab ?? void 0,
					target: "_blank",
					rel: "noreferrer",
					"aria-disabled": !colab,
					className: `flex min-h-11 items-center justify-center rounded-xl bg-panel text-sm font-semibold text-paper ${colab ? "" : "pointer-events-none opacity-50"}`,
					children: "Open Colab"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onTest(colabUrl),
					disabled: busy,
					className: "min-h-11 rounded-xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
					children: "Test & Connect"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				htmlFor: "kaggle-url",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium text-paper",
					children: "Kaggle URL"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "kaggle-url",
					value: kaggleUrl,
					onChange: (event) => onKaggle(event.target.value),
					placeholder: "https://www.kaggle.com/code/…",
					inputMode: "url",
					autoComplete: "off",
					className: "field mt-2 min-h-12 w-full rounded-xl px-3 text-base outline-none placeholder:text-muted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: kaggle ?? void 0,
					target: "_blank",
					rel: "noreferrer",
					"aria-disabled": !kaggle,
					className: `flex min-h-11 items-center justify-center rounded-xl bg-panel text-sm font-semibold text-paper ${kaggle ? "" : "pointer-events-none opacity-50"}`,
					children: "Open Kaggle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onTest(kaggleUrl),
					disabled: busy,
					className: "min-h-11 rounded-xl bg-seal text-sm font-semibold text-paper disabled:opacity-50",
					children: "Test & Connect"
				})]
			}),
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "badge-ok rounded-xl px-3 py-2 text-sm font-semibold",
				children: badge
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { Home as component };

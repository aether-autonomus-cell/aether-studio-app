//#region node_modules/.nitro/vite/services/ssr/assets/bible-BCfVgxxi.js
function decodeEntities(value) {
	const named = {
		amp: "&",
		lt: "<",
		gt: ">",
		quot: String.fromCharCode(34),
		apos: "'",
		nbsp: " "
	};
	return value.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (match, body) => {
		const key = body.toLowerCase();
		if (key.startsWith("#x")) {
			const code = Number.parseInt(key.slice(2), 16);
			return Number.isFinite(code) && code > 0 && code < 1114112 ? String.fromCodePoint(code) : match;
		}
		if (key.startsWith("#")) {
			const code = Number.parseInt(key.slice(1), 10);
			return Number.isFinite(code) && code > 0 && code < 1114112 ? String.fromCodePoint(code) : match;
		}
		return Object.prototype.hasOwnProperty.call(named, key) ? named[key] : match;
	});
}
function stripChrome(value) {
	return value.replace(/wtr-?lab/gi, " ").replace(/ch\.\s*\d+\s*\/\s*\d+/gi, " ").replace(/\d+(?:\.\d+)?%\s*web/gi, " ").replace(/#\d+\s*chapter/gi, " ").replace(/\b(?:next|previous)\s+chapter\b/gi, " ").replace(/\bhome\s*\|\s*novels\s*\|\s*library\s*\|\s*ranking\b/gi, " ").replace(/\s+/g, " ").trim();
}
var LONE_LABEL = /^(novel|novels|web|mtl|machine translation|next chapter|previous chapter|library|ranking|home|comments?|login|sign in)$/i;
/** Drop ads, nav, chapter chrome, and site names. Keep the story, including a long ending. */
function sanitizeNovelText(raw) {
	return decodeEntities(raw).split(/\n+/).map((line) => stripChrome(line)).filter((line) => line.length > 0 && !LONE_LABEL.test(line) && !/^[\d.%\s/#+-]+$/.test(line)).join("\n").trim();
}
function region(html) {
	const article = html.match(/<article\b[\s\S]*?<\/article>/i);
	if (article) return article[0];
	const main = html.match(/<main\b[\s\S]*?<\/main>/i);
	if (main) return main[0];
	return html.match(/<body\b[\s\S]*?<\/body>/i)?.[0] ?? html;
}
function visibleText(html) {
	return decodeEntities(html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<nav[\s\S]*?<\/nav>/gi, " ").replace(/<footer[\s\S]*?<\/footer>/gi, " ").replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, " ").replace(/[ \t]+\n/g, "\n").replace(/[ \t]{2,}/g, " ").trim());
}
function htmlToText(html) {
	return {
		title: sanitizeNovelText(visibleText(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "")).replace(/\s+-\s*$/, "").trim(),
		text: sanitizeNovelText(visibleText(region(html)))
	};
}
function absUrl(src, pageUrl) {
	try {
		const url = new URL(src, pageUrl);
		if (url.protocol !== "http:" && url.protocol !== "https:") return null;
		return url.toString();
	} catch {
		return null;
	}
}
function junkImage(src) {
	return /logo|icon|sprite|avatar|emoji|banner|ads?\/|advert|pixel|thumb_small|loading|favicon|badge/i.test(src);
}
function isSpokenBubble(line) {
	if (/^["“「『']/.test(line) || /["”」』']$/.test(line)) return true;
	return /^[A-Z][\p{L}'’.-]{0,24}:\s+\S/u.test(line) && line.length <= 160;
}
function splitNearby(alt, nearby) {
	const bubbleLines = [];
	const asideLines = [];
	const altLine = alt.replace(/\s+/g, " ").trim();
	if (altLine) bubbleLines.push(altLine.slice(0, 180));
	for (const line of nearby.split(/\n+/).map((part) => part.trim()).filter(Boolean)) if (isSpokenBubble(line)) bubbleLines.push(line);
	else asideLines.push(line);
	const bubble = bubbleLines.join(" ").replace(/\s+/g, " ").trim().slice(0, 400);
	const aside = asideLines.join(" ").replace(/\s+/g, " ").trim().slice(0, 400);
	return {
		bubble,
		aside,
		text: [bubble, aside].filter(Boolean).join(" ").trim()
	};
}
/** Panel images in reading order. Alt and quoted speech stay in the bubble. Prose beside the panel stays near the face. */
function extractPanels(html, pageUrl) {
	const body = region(html).replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<nav[\s\S]*?<\/nav>/gi, " ").replace(/<footer[\s\S]*?<\/footer>/gi, " ");
	const tags = [...body.matchAll(/<img\b[^>]*>/gi)];
	const panels = [];
	for (let index = 0; index < tags.length; index += 1) {
		const tag = tags[index];
		if (!tag?.[0] || tag.index === void 0) continue;
		const raw = tag[0].match(/\b(?:data-src|data-original|data-lazy-src|src)=["']([^"']+)["']/i)?.[1]?.trim() ?? "";
		if (!raw || raw.startsWith("data:") || junkImage(raw)) continue;
		const src = absUrl(raw, pageUrl);
		if (!src) continue;
		const alt = tag[0].match(/\balt=["']([^"']*)["']/i)?.[1] ?? "";
		const from = tag.index + tag[0].length;
		const to = tags[index + 1]?.index ?? Math.min(body.length, from + 800);
		const nearby = sanitizeNovelText(visibleText(body.slice(from, to))).slice(0, 500);
		panels.push({
			src,
			...splitNearby(alt, nearby)
		});
		if (panels.length >= 400) break;
	}
	return panels;
}
/** WTR-LAB serves chapter text from a JSON API, not the Cloudflare HTML shell. */
var KEY_TEXT = "IJAFUUxjM25hyzL2AZrn0wl7cESED6Ru";
function b64(value) {
	const binary = atob(value);
	const bytes = new Uint8Array(binary.length);
	for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
	return bytes;
}
function concatBytes(parts) {
	const total = parts.reduce((sum, part) => sum + part.byteLength, 0);
	const out = new Uint8Array(total);
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.byteLength;
	}
	return out;
}
/** Chapter bodies are `arr:` / `str:` plus AES-GCM (`iv : tag : ciphertext`, all base64). */
async function decryptWtrBody(encrypted) {
	let payload = encrypted.trim();
	let asArray = false;
	if (payload.startsWith("arr:")) {
		asArray = true;
		payload = payload.slice(4);
	} else if (payload.startsWith("str:")) payload = payload.slice(4);
	else throw new Error("Unknown chapter format.");
	const parts = payload.split(":");
	if (parts.length !== 3) throw new Error("Invalid chapter payload.");
	const [ivPart, tagPart, dataPart] = parts;
	const iv = b64(ivPart);
	const tag = b64(tagPart);
	const data = b64(dataPart);
	const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(KEY_TEXT), "AES-GCM", false, ["decrypt"]);
	const plain = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv
	}, key, concatBytes([data, tag]));
	const decoded = new TextDecoder().decode(plain);
	if (!asArray) return decoded;
	const parsed = JSON.parse(decoded);
	if (Array.isArray(parsed)) return parsed.filter((line) => typeof line === "string").join("\n\n");
	return typeof parsed === "string" ? parsed : "";
}
function parseWtrChapterUrl(raw) {
	let url;
	try {
		url = new URL(raw);
	} catch {
		return null;
	}
	if (url.hostname.toLowerCase().replace(/^www\./, "") !== "wtr-lab.com") return null;
	const parts = url.pathname.split("/").filter(Boolean);
	const chapter = [...parts].reverse().find((part) => /^chapter-\d+$/i.test(part));
	if (!chapter) return null;
	const chapterNo = chapter.replace(/^chapter-/i, "");
	const novelAt = parts.findIndex((part) => part.toLowerCase() === "novel");
	let language = "en";
	let rawId = "";
	if (novelAt >= 0 && /^\d+$/.test(parts[novelAt + 1] ?? "")) {
		rawId = parts[novelAt + 1];
		if (novelAt > 0 && /^[a-z]{2}$/i.test(parts[novelAt - 1])) language = parts[novelAt - 1].toLowerCase();
	} else {
		const serie = parts.find((part) => /^serie-\d+$/i.test(part));
		if (!serie) return null;
		rawId = serie.replace(/^serie-/i, "");
		const serieAt = parts.indexOf(serie);
		if (serieAt > 0 && /^[a-z]{2}$/i.test(parts[serieAt - 1])) language = parts[serieAt - 1].toLowerCase();
	}
	return {
		origin: url.origin,
		language,
		rawId,
		chapterNo,
		referer: url.toString()
	};
}
function browserHeaders(referer, json) {
	const headers = new Headers({
		Accept: json ? "application/json, text/plain, */*" : "text/html,application/xhtml+xml",
		"Accept-Language": "en-US,en;q=0.9",
		"User-Agent": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
		Referer: referer,
		Origin: new URL(referer).origin
	});
	if (json) headers.set("Content-Type", "application/json");
	return headers;
}
async function readJson(url, init) {
	let res;
	try {
		res = await fetch(url, {
			...init,
			redirect: "follow",
			signal: AbortSignal.timeout(2e4)
		});
	} catch {
		return null;
	}
	if (!res.ok) return null;
	try {
		return await res.json();
	} catch {
		return null;
	}
}
function chapterMeta(json, chapterNo) {
	const stack = [json];
	while (stack.length) {
		const current = stack.pop();
		if (!current || typeof current !== "object") continue;
		if (Array.isArray(current)) {
			for (const item of current) stack.push(item);
			continue;
		}
		const row = current;
		const order = row.order ?? row.chapter_no ?? row.chapterNo;
		if (String(order ?? "") === chapterNo && (typeof row.id === "number" || typeof row.chapter_id === "number")) return {
			id: typeof row.id === "number" ? row.id : row.chapter_id,
			serie_id: typeof row.serie_id === "number" ? row.serie_id : void 0,
			title: typeof row.title === "string" ? row.title : typeof row.name === "string" ? row.name : void 0
		};
		for (const value of Object.values(row)) if (value && typeof value === "object") stack.push(value);
	}
	return null;
}
function contentUrlOf(json) {
	const stack = [json];
	let depth = 0;
	while (stack.length && depth < 400) {
		depth += 1;
		const current = stack.pop();
		if (!current || typeof current !== "object") continue;
		if (Array.isArray(current)) {
			for (const item of current) stack.push(item);
			continue;
		}
		const row = current;
		if (typeof row.content_url === "string" && row.content_url) return row.content_url;
		for (const value of Object.values(row)) if (value && typeof value === "object") stack.push(value);
	}
	return null;
}
async function stringsFromBody(body) {
	if (Array.isArray(body)) return body.filter((line) => typeof line === "string" && line.trim().length > 0);
	if (typeof body !== "string") return [];
	const trimmed = body.trim();
	if (!trimmed) return [];
	if (trimmed.startsWith("arr:") || trimmed.startsWith("str:")) try {
		return (await decryptWtrBody(trimmed)).split(/\n+/).map((line) => line.trim()).filter(Boolean);
	} catch {
		return [];
	}
	if (trimmed.startsWith("<")) return [trimmed];
	if (trimmed.length > 40) return [trimmed];
	return [];
}
async function collectChapterText(json) {
	let title = "";
	const lines = [];
	const stack = [json];
	let depth = 0;
	while (stack.length && depth < 800) {
		depth += 1;
		const current = stack.pop();
		if (!current || typeof current !== "object") continue;
		if (Array.isArray(current)) {
			const asLines = await stringsFromBody(current);
			if (asLines.length > 1 && asLines.join("").length > 80) lines.push(...asLines);
			else for (const item of current) stack.push(item);
			continue;
		}
		const row = current;
		if (!title && typeof row.title === "string" && row.title.trim()) title = row.title.trim();
		for (const key of [
			"body",
			"content",
			"text",
			"html",
			"paragraphs"
		]) {
			if (!(key in row)) continue;
			const pulled = await stringsFromBody(row[key]);
			if (pulled.length) lines.push(...pulled);
		}
		for (const value of Object.values(row)) if (value && typeof value === "object") stack.push(value);
	}
	return {
		title,
		lines
	};
}
function containsHan(text) {
	return /\p{Script=Han}/u.test(text);
}
async function fetchWtrChapter(target) {
	const headers = browserHeaders(target.referer, true);
	const list = await readJson(`${target.origin}/api/chapters/${target.rawId}?start=${target.chapterNo}&end=${target.chapterNo}`, {
		method: "GET",
		headers
	});
	const meta = list ? chapterMeta(list, target.chapterNo) : null;
	const payloads = [{
		translate: "web",
		language: target.language,
		raw_id: Number(target.rawId),
		chapter_no: Number(target.chapterNo),
		retry: false,
		force_retry: false
	}];
	if (meta?.id) payloads.unshift({
		translate: "web",
		language: target.language,
		raw_id: meta.serie_id ?? Number(target.rawId),
		chapter_no: Number(target.chapterNo),
		chapter_id: meta.id,
		retry: false,
		force_retry: false
	});
	for (const payload of payloads) {
		let json = await readJson(`${target.origin}/api/reader/get`, {
			method: "POST",
			headers,
			body: JSON.stringify(payload)
		});
		if (!json || typeof json !== "object") continue;
		if (json.success === false) continue;
		const remote = contentUrlOf(json);
		if (remote) {
			const followed = await readJson(new URL(remote, target.origin).toString(), {
				method: "GET",
				headers
			});
			if (followed) json = followed;
		}
		const collected = await collectChapterText(json);
		const text = collected.lines.join("\n\n").trim();
		if (text.length < 80) continue;
		return {
			title: (meta?.title || collected.title || `Chapter ${target.chapterNo}`).trim(),
			text
		};
	}
	return null;
}
function outfitAt(changes, fallback, chapter) {
	if (!chapter || !changes?.length) return fallback.trim();
	let current = fallback.trim();
	const rows = [...changes].filter((row) => row.chapter > 0 && row.outfit.trim()).sort((a, b) => a.chapter - b.chapter);
	for (const row of rows) if (row.chapter <= chapter) current = row.outfit.trim();
	return current;
}
function composeLook(character, chapter) {
	const outfit = outfitAt(character.outfits, character.outfit || "", chapter);
	const parts = [
		character.age?.trim(),
		character.body?.trim(),
		character.face?.trim() ? `face: ${character.face.trim()}` : "",
		character.hair?.trim() ? `hair: ${character.hair.trim()}` : "",
		character.eyes?.trim() ? `eyes: ${character.eyes.trim()}` : "",
		character.scars?.trim() ? `scars: ${character.scars.trim()}` : "",
		outfit ? `outfit: ${outfit}` : ""
	].filter(Boolean);
	if (!parts.length) return character.look.trim();
	const lead = parts.join(", ");
	if (character.look.trim() && !lead.includes(character.look.trim())) return `${lead}. ${character.look.trim()}`;
	return lead;
}
function bibleDocument(characters) {
	return characters.map((character) => {
		const changes = (character.outfits ?? []).filter((row) => row.chapter > 0 && row.outfit.trim()).map((row) => `chapter ${row.chapter}: ${row.outfit.trim()}`).join("; ");
		return [
			`${character.name}`,
			`face: ${character.face?.trim() || "—"}`,
			`hair: ${character.hair?.trim() || "—"}`,
			`age: ${character.age?.trim() || "—"}`,
			`scars: ${character.scars?.trim() || "—"}`,
			`eyes: ${character.eyes?.trim() || "—"}`,
			`body: ${character.body?.trim() || "—"}`,
			`outfit: ${character.outfit?.trim() || character.look.trim() || "—"}`,
			changes ? `outfit changes: ${changes}` : ""
		].filter(Boolean).join("; ");
	}).join("\n");
}
function textToOutfits(value) {
	const rows = [];
	for (const line of value.split(/\n+/)) {
		const match = line.trim().match(/^(?:chapter\s*)?(\d+)\s*[:\-]\s*(.+)$/i);
		if (!match?.[1] || !match[2]) continue;
		const chapter = Number(match[1]);
		const outfit = match[2].trim();
		if (chapter > 0 && chapter < 1e5 && outfit) rows.push({
			chapter,
			outfit: outfit.slice(0, 180)
		});
	}
	return rows;
}
function outfitsToText(rows) {
	return (rows ?? []).map((row) => `${row.chapter}: ${row.outfit}`).join("\n");
}
function beatsNeedingPrompt(scenes) {
	return scenes.filter((scene) => !scene.locked && !scene.promptLocked).map((scene) => scene.id);
}
function lookLockForScene(scene, characters) {
	const blob = [
		scene.caption,
		scene.dialogue,
		scene.speaker,
		scene.imagePrompt
	].join("\n");
	const named = characters.filter((character) => character.name && blob.includes(character.name));
	return (named.length ? named : characters.slice(0, 4)).map((character) => `${character.name}: ${composeLook(character, scene.chapter)}`).filter((row) => !row.endsWith(": ")).join("\n");
}
function faceReferenceFor(scene, characters) {
	const blob = [
		scene.caption,
		scene.dialogue,
		scene.speaker,
		scene.imagePrompt
	].join("\n");
	const named = characters.find((character) => character.faceUrl && character.name && blob.includes(character.name));
	if (named?.faceUrl) return named.faceUrl;
	if (characters.length === 1 && characters[0]?.faceUrl) return characters[0].faceUrl;
	return "";
}
var LOOK_KEYS = [
	"face",
	"hair",
	"age",
	"scars",
	"eyes",
	"body",
	"outfit"
];
function applyLookPatch(character, patch) {
	const next = {
		...character,
		outfits: character.outfits ? [...character.outfits] : []
	};
	for (const key of LOOK_KEYS) {
		const value = patch[key]?.trim();
		if (value) next[key] = value.slice(0, 180);
	}
	if (patch.chapter && patch.chapter > 0 && patch.outfit?.trim()) {
		const outfit = patch.outfit.trim().slice(0, 180);
		const outfits = (next.outfits ?? []).filter((row) => row.chapter !== patch.chapter);
		outfits.push({
			chapter: patch.chapter,
			outfit
		});
		next.outfits = outfits;
		next.outfit = outfit;
	}
	next.look = composeLook(next);
	next.vessel = next.outfit || next.vessel;
	return next;
}
function parseStudioAction(raw) {
	const match = raw.match(/\n?ACTION\s+(\{[\s\S]*\})\s*$/);
	if (!match?.[1]) return {
		reply: raw.trim(),
		action: null
	};
	const reply = raw.slice(0, match.index).trim();
	let data;
	try {
		data = JSON.parse(match[1]);
	} catch {
		return {
			reply: raw.trim(),
			action: null
		};
	}
	if (!data || typeof data !== "object") return {
		reply: raw.trim(),
		action: null
	};
	const row = data;
	if (row.type === "line") {
		const id = typeof row.id === "string" ? row.id.trim().slice(0, 40) : "";
		const text = typeof row.text === "string" ? row.text.trim().slice(0, 400) : "";
		if (!id || !text) return {
			reply: reply || raw.trim(),
			action: null
		};
		return {
			reply,
			action: {
				type: "line",
				id,
				text
			}
		};
	}
	if (row.type !== "look") return {
		reply: reply || raw.trim(),
		action: null
	};
	const name = typeof row.name === "string" ? row.name.trim().slice(0, 40) : "";
	if (!name) return {
		reply: reply || raw.trim(),
		action: null
	};
	const action = {
		type: "look",
		name
	};
	for (const key of LOOK_KEYS) if (typeof row[key] === "string" && row[key].trim()) action[key] = row[key].trim().slice(0, 180);
	const chapter = typeof row.chapter === "number" ? Math.floor(row.chapter) : Number(row.chapter);
	if (Number.isFinite(chapter) && chapter > 0 && chapter < 1e5) action.chapter = chapter;
	return {
		reply,
		action
	};
}
function grab(sentence, rule) {
	return rule.test(sentence) ? sentence.replace(/\s+/g, " ").trim().slice(0, 180) : "";
}
/** Best-effort look lock when the writer is offline. One pass. A language switch must not call this again. */
function gleanCast(text, known = []) {
	const sentences = text.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/).map((sentence) => sentence.trim()).filter((sentence) => sentence.length > 20 && sentence.length < 280);
	const names = /* @__PURE__ */ new Map();
	for (const character of known) names.set(character.name.toLowerCase(), {
		...character,
		outfits: character.outfits ? [...character.outfits] : []
	});
	const found = text.match(/\b[A-Z][a-z]{2,}(?:\s[A-Z][a-z]+)?\b/g) ?? [];
	for (const name of found) {
		if ([
			"The",
			"Rain",
			"Across",
			"Between",
			"Lightning",
			"Your",
			"Chapter"
		].includes(name)) continue;
		if (!names.has(name.toLowerCase())) names.set(name.toLowerCase(), {
			id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-") || "figure",
			name,
			soul: "Named in the source. Identity stays on this name.",
			vessel: "",
			look: "",
			outfits: []
		});
	}
	for (const sentence of sentences) {
		const chapter = Number(sentence.match(/chapter\s+(\d+)/i)?.[1] ?? "");
		for (const character of names.values()) {
			if (!sentence.includes(character.name)) continue;
			character.face = character.face || grab(sentence, /face|jaw|brow/i);
			character.hair = character.hair || grab(sentence, /hair/i);
			character.eyes = character.eyes || grab(sentence, /eyes?/i);
			character.scars = character.scars || grab(sentence, /scar/i);
			character.age = character.age || grab(sentence, /\bage\b|young|old|teen/i);
			character.body = character.body || grab(sentence, /tall|slim|body|broad/i);
			const clothes = grab(sentence, /robe|armor|dress|cloak|outfit|sleeve|uniform|boots/i);
			if (clothes && chapter > 0) {
				const outfits = character.outfits ?? [];
				if (!outfits.some((row) => row.chapter === chapter)) outfits.push({
					chapter,
					outfit: clothes
				});
				character.outfits = outfits;
			} else if (clothes && !character.outfit) character.outfit = clothes;
		}
	}
	return [...names.values()].map((character) => {
		character.look = composeLook(character) || character.look || "Body not described yet.";
		character.vessel = character.outfit || character.look;
		return character;
	});
}
function mergeCast(base, extra) {
	const rows = base.map((character) => ({ ...character }));
	for (const character of extra) {
		const key = character.name.trim().toLowerCase();
		const index = rows.findIndex((row) => row.name.trim().toLowerCase() === key);
		if (index < 0) {
			rows.push(character);
			continue;
		}
		const current = rows[index];
		rows[index] = {
			...current,
			face: character.face || current.face,
			hair: character.hair || current.hair,
			age: character.age || current.age,
			scars: character.scars || current.scars,
			eyes: character.eyes || current.eyes,
			body: character.body || current.body,
			outfit: character.outfit || current.outfit,
			outfits: character.outfits?.length ? character.outfits : current.outfits,
			look: character.look || current.look,
			soul: current.soul || character.soul,
			vessel: character.vessel || current.vessel,
			faceUrl: current.faceUrl || character.faceUrl
		};
	}
	return rows;
}
//#endregion
export { textToOutfits as _, containsHan as a, fetchWtrChapter as c, lookLockForScene as d, mergeCast as f, sanitizeNovelText as g, parseWtrChapterUrl as h, composeLook as i, gleanCast as l, parseStudioAction as m, beatsNeedingPrompt as n, extractPanels as o, outfitsToText as p, bibleDocument as r, faceReferenceFor as s, applyLookPatch as t, htmlToText as u };
